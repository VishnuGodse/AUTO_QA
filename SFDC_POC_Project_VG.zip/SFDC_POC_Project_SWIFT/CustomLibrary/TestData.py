from xlrd import open_workbook

def readTestData(excelFileName,rowId):
    
    path = 'G:\\TestFramework\\TestUI_SWIFT_SFDC_Apttus\\TestData\\'
    
    wb = open_workbook(path+excelFileName)
    excel = []
    global testData
    testData = {}
    for s in wb.sheets():
        for row in range(1, s.nrows):
            temp = {}
            col_names = s.row(0)
            col_value = []
            for name, col in zip(col_names, range(s.ncols)):
                value  = (s.cell(row,col).value)
                try : value = str(int(value))
                except : pass
                temp[name.value] = value
            excel.append(temp)
            if temp[next(iter(temp))] == rowId:
                testData = temp
                return temp
    return -1
    
def getTestData(columnName):
    if testData == -1:
        return -1
    try:
        return testData[columnName]
    except:
        return -1

#print(ReadTestData('data.xlsx','2'))
#print(getTestData('CustomerType'))