package com.testFramework.page.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.testFramework.base.AbstractBasePage;

public class MainLoginPage extends AbstractBasePage {

	public MainLoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	private WebElement element = null;
	

	
	public static String USER_NAME ="username";
	public static String PASSWORD ="password";
	public static String LOGIN_BUTTON = "Login";
	
	public WebElement UserName = getWebElemenetByID(USER_NAME);
	public WebElement Password = getWebElemenetByID(PASSWORD);
	public WebElement LoginButton = getWebElemenetByID(LOGIN_BUTTON);
	
	
}
