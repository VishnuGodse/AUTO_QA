package com.testFramework.regression.module;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.testFramework.base.AbstractBaseTestCase;



//@Listeners(com.testFramework.log.Listener.class)
@Test(groups = {"Login"})
public class VerifyLaunchApplicationURLtest extends AbstractBaseTestCase {

	//public TestData testData  = TestData.getInstance();

	public static String testCaseId = "12121";
     
	public void testBankLaunchApplicationURL() throws IOException
	{
		
		
				login();
		
		
		     testData.readTestData("TestDataExcel.xlsx", "12125");
			
			String applicationuserName	= testData.getTestData("CustomerLName");
			
			String applicationuserPassword	= testData.getTestData("CustomerNumber");
		
				
			
			/*testData.readTestDataFromCSV("TestDataCsv.csv","VishnuG");
			
			String inputValueCsv =	testData.getDataFromCSV("TestDataCsv.csv","Pablo");
			testLog.logResult(LogStatus.PASS, "passed but failed" + inputValueCsv);*/
		
		
		 
		
		
	}

	@Override
	protected String getTestCaseId() {
		// TODO Auto-generated method stub
		return testCaseId;
	}
	
	
	
	
	
}
