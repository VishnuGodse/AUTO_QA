package com.testFramework.base;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.testFramework.config.ConfigServices;

import com.testFramework.log.TestLog;
import com.testFramework.page.login.MainLoginPage;
import com.testFramework.testData.TestData;
import com.testFramework.testStep.TestStep;




public abstract class AbstractBaseTestCase {

	
	EventFiringWebDriver edriver;
	WebEventListener eListener;
	protected TestData testData  = TestData.getInstance();
	protected TestLog testLog = TestLog.getInstance();
	public String testCaseId;
	public String testCaseName;
	protected TestStep testStep;
	protected WebDriver driver = TestWebDriverBase.getInstance();
	protected ConfigServices configService =  ConfigServices.getInstance();
	String queryString ;
	protected abstract String getTestCaseId();
	
	public String fsName[] = {"Bank","Insurance","Finance"};
	public String accountNumber;
	public String customerName;
	
	
	
	@BeforeTest
	public void sample()
	{
		
	}
	
	@BeforeClass
	public void sample1()
	{}
	
	
	public String formTestCaseName(String testCaseName)
	{
		String testCaseId1 = testCaseId;
		
		if(testCaseId!=null&& testCaseId.contains("_"))
			
		{
		String testCaseIdSplit[] = testCaseId.split("_");
		   testCaseId1 = testCaseIdSplit[0];
		}
		
		
		if(!(testCaseId==null && testCaseName.contains("test")))
		{
			
			for(int i=0;i<=fsName.length;i++)
				
			{
				
				int fsNameValue =fsName[i].length();
				
				if((testCaseName.substring(4,fsNameValue + 4)).toLowerCase().equalsIgnoreCase(fsName[i].toLowerCase()))
				{
					testCaseName = testCaseId1 +"_" + testCaseName.substring(4,fsNameValue+4)+ "_" + testCaseName;;
					break;
					
				}
				
			}
			
			
			
		}
		
			
		
		return testCaseName;
		
		
		
	}
	
	@BeforeMethod
	public void setTestBed(Method methodName) throws MalformedURLException
	{
		
		System.out.println("[Test Case Name]");
		
		testCaseName = methodName.getName(); 
		testCaseId = getTestCaseId();
		
		String testCaseName1 = formTestCaseName(testCaseName);
		
		//testCaseName1  = testCaseId + testCaseName1;
		System.out.println(testCaseName1);
		String logPath = configService.getLogDir();
		
		testLog.setupLog(testCaseName1,logPath);
		
		testLog.logMessage(" [Test Case Name] "+ "\n" + testCaseName);
		
		LoadWebDriver(configService.getDriverPath());
		
		testStep = new TestStep(driver);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Application URL has been passed to driver : :"+configService.getStartPage());
		driver.get(configService.getStartPage());
		
		if(!testCaseId.contains("_"))
		{
			getDBData();
		}
		
		else if(testCaseId.contains("_InternalQuery"))
		{
			getDBData();
		}
		
		
	}
	
	
	public void LoadWebDriver(String driverPath) throws MalformedURLException {
		// TODO Auto-generated method stub
		
		if( driverPath == null)
		{
			// end test case
			
			testLog.logResult(LogStatus.ERROR, "Driver path is NULL :");
		}		
		else if(driverPath.contains(".exe"))
		{
			try
			{
			
			if(driverPath.contains("chromedriver"))
			{
				System.out.println("Launching Chrome Browser Shortly : :");
				System.setProperty("webdriver.chrome.driver",driverPath);
				driver = new ChromeDriver();
				edriver = new EventFiringWebDriver(driver);
				eListener = new WebEventListener();
				edriver.register(eListener);
				driver= edriver;
				
			}
			else if(driverPath.contains("geckodriver"))
			{
				System.out.println("Launching Firefox Browser Shortly : :");
				System.setProperty("webdriver.chrome.driver",driverPath);
				driver = new FirefoxDriver();
				edriver = new EventFiringWebDriver(driver);
				eListener = new WebEventListener();
				edriver.register(eListener);
				driver= edriver;
			}
			else if(driverPath.contains("MicrosoftWebDriver"))
			{

				System.out.println("Launching MS Edge Browser Shortly : :");
				System.setProperty("webdriver.edge.driver",driverPath);
				driver = new EdgeDriver();
				edriver = new EventFiringWebDriver(driver);
				eListener = new WebEventListener();
				edriver.register(eListener);
				driver= edriver;
			}
			
			else if(driverPath.contains("IEDriverServer"))
			{
				
				System.out.println("Launching IE Browser Shortly : :");
				System.setProperty("webdriver.ie.driver",driverPath);
				driver = new InternetExplorerDriver();
				edriver = new EventFiringWebDriver(driver);
				eListener = new WebEventListener();
				edriver.register(eListener);
				driver= edriver;
			}			
			
			else
			{
				//Please specify the driver path to launch the application.
			}

			
			}
			
			catch(Exception ex)
			{
				
				testLog.logResult(LogStatus.ERROR, "Driver Setup Failed");
			}
			
			
				
		}
		
		else if(driverPath.contains("hub"))
		{
			try
			{
			DesiredCapabilities  dc = new DesiredCapabilities();
			dc.setBrowserName("chorme");
			dc.setPlatform(Platform.ANY);
			driver = new RemoteWebDriver(new URL(driverPath),dc);
			edriver = new EventFiringWebDriver(driver);
			eListener = new WebEventListener();
			edriver.register(eListener);
			driver= edriver;
		}
			
			catch(Exception ex)
			
			{
				testLog.logResult(LogStatus.ERROR, "Remote Driver Setup Failed");
			}
		}
		
	}

	@AfterTest
	public void sample4()
	{}
	
	@AfterClass
	public void sample5()
	{}
	
	
	
	public void login() throws IOException
	{
		
		//testStep.debug();
		
		String UserRowId = configService.getapplicationUser();
		
		 testData.readTestData("UserTestData.xlsx", UserRowId);
		
		String applicationuserName	= testData.getTestData("UserName");
		
		String applicationuserPassword	= testData.getTestData("Password");
		
		MainLoginPage loginPage = new MainLoginPage(driver);
		//testStep.debug();
		loginPage.UserName.sendKeys(applicationuserName);
		
		loginPage.Password.sendKeys(applicationuserPassword);
		loginPage.LoginButton.click();
		
		
		
	}
	
	
	public void getDBData() {
		// TODO Auto-generated method stub
		
	boolean conResult =	testData.connectDatabase(configService.getdbURL(), configService.getdbUser(), configService.getdbPassword());
		
	if(conResult)
	{
		DateTimeFormatter dateFormat1 =  DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");
		LocalDateTime date1 =  LocalDateTime.now();
		String timeStamp = dateFormat1.format(date1);
		
		//List<String> ignoreList = testData.getDBDataFromExcel();
		List<String> ignoreList = testData.getDBDataFromCSVForDBDataIgnoredList();
		String ignorelist = "'0000";
		try
		{
		  for(int i=0;i<ignoreList.size();i++)
		  {
			  String item = ignoreList.get(i);
			  
			  if(item!=null || !item.contains(""))
			  {
			  ignorelist = ignorelist + "'" + "," + "'"+ ignoreList.get(i);
			  }
			 
			  
		  }
		  
		  ignorelist =  ignorelist +"'";
		}
		
		catch(Exception ex)
		{
			ex.printStackTrace();
			testLog.logResult(LogStatus.ERROR, " Error - While Preparing the Accounts to be ignored list.");
		}
		
		try
		{
			
		testData.readTestData("DatabaseQuerySheet.xlsx", testCaseId);
		 queryString = testData.getTestData("Query");
		System.out.print("This is the Executable database Query : " + queryString +"\n");
		
		 queryString =  queryString.replace("AccountsToBeIgnored", ignorelist) ;
		
		 System.out.print("This is the Replaced Executable database Query : " + queryString +"\n");
		 
		 testLog.logMessage("This is the database Query for this Test Case: " + queryString);
		 
		testData.readDatabase(queryString);
		
		String alias[] = queryString.split(testCaseId);
		
		for(int i=0;i<alias.length-1;i++)
			
		{
			if(alias[i].contains("ACCOUNTNUMBER"))
			{
			accountNumber = testData.getVariable("ACCOUNTNUMBER_"+testCaseId);
			if(accountNumber!=null)
			{
				testLog.logMessage( "The account Number is : " + accountNumber);
			testData.setDBDataInCSV("ACCOUNTNUMBER_"+testCaseId +"_"+timeStamp, accountNumber);
		//	testData.setDBDataInExcel("ACCOUNTNUMBER_"+testCaseId +"_"+timeStamp, accountNumber);
			}
			System.out.println("This is the account number : " + accountNumber);
			}
			
			else if(alias[i].contains("CUSTOMERNAME"))
			{
			customerName = testData.getVariable("CUSTOMERNAME_"+testCaseId);
			
			if(customerName!=null)
			{
				testLog.logMessage( "The customer Name is : " + customerName);
			//testData.setDBDataInExcel("CUSTOMERNAME_"+testCaseId +"_"+timeStamp, accountNumber);
			//testData.setDBDataInCSV("CUSTOMERNAME_"+testCaseId +"_"+timeStamp, customerName);
			}
			System.out.println("This is the customer name : " + customerName);
			}
			
			
			
		}
		
		
		
		testData.closeConnectDatabase();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			
			testLog.logResult(LogStatus.ERROR, " Error -Query Not Defined Properly OR DATA Unavailable OR Check DB Creds ..");
		}
		
		
	}
		
		
	}

	public void logout()
	{
		
		
	}
	public  String captureSnapshots(String SnapshotName) throws IOException
	{
		try{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh-mm-ss");
		 Date date = new Date();
		String dateSRC = dateFormat.format(date);
		
		
		TakesScreenshot ts = (TakesScreenshot) driver;
		File Sourcefile = ts.getScreenshotAs(OutputType.FILE)	;
		
		
		//System.out.println("Snapshot Taken");
		String Destination= configService.getScreenShotPath() +SnapshotName+"_"+dateSRC+".png";
		File DestFile = new File (Destination);
		FileUtils.copyFile(Sourcefile, DestFile);
		return Destination;
		}
		
		catch (Exception e)
		{
			
			System.out.println("Something went wrong while taking snapshots : " +e.getMessage());
			testLog.logResult(LogStatus.ERROR, " Error -Something went wrong while taking snapshots ");
			return e.getMessage();
		}
		
	}
	
	@AfterMethod
	public void endOfExecution(ITestResult result) throws IOException, InterruptedException
	{
		
		logout();
		
		String logStatus = null;

		Thread.sleep(5000);
	
			LogStatus finalStatus = testLog.logger.getRunStatus();
		if(finalStatus.toString().equalsIgnoreCase("FAIL"))
		{
			logStatus = "FAIL";
			String SnapshotPath = captureSnapshots(result.getName());
			String ImagePath = testLog.addScreenShotinReport(SnapshotPath);
			testLog.logResultWithScreenshot(LogStatus.FAIL,result.getName(), ImagePath);
			testLog.logResult(LogStatus.FAIL,result.getName()+ " Functionality has been Failed");
		}
		
		if(finalStatus.toString().equalsIgnoreCase("ERROR"))
		{
			logStatus = "ERROR";
			String SnapshotPath = captureSnapshots(result.getName());
			String ImagePath = testLog.addScreenShotinReport(SnapshotPath);
			testLog.logResultWithScreenshot(LogStatus.ERROR,result.getName(), ImagePath);
			testLog.logResult(LogStatus.ERROR,result.getName()+ " Functionality has been Failed");
		}
		
		
		if(finalStatus.toString().equalsIgnoreCase("PASS"))
		{
			logStatus = "PASS";
			String SnapshotPath = captureSnapshots(result.getName());
			String ImagePath = testLog.addScreenShotinReport(SnapshotPath);
			testLog.logResultWithScreenshot(LogStatus.PASS,result.getName(), ImagePath);
			testLog.logResult(LogStatus.PASS,result.getName()+"  Functionality has been verified and tested successfully");
		}
		
		if(finalStatus.toString().equalsIgnoreCase("SKIP"))
		{
			//String SnapshotPath = Common_Actions.captureSnapshots(result.getName());
			//String ImagePath = logger.addScreenCapture(SnapshotPath);
			logStatus = "SKIP";
			testLog.logResult(LogStatus.SKIP,result.getName()+"  Functionality has been SKIPPED");
		}
		
		testLog.endTestCase();
		
		driver.quit();
		
	
		
		String logPath = testLog.getLogPath();
		testLog.renameLogFolder(logPath,logStatus);
		
	}
	
	
	
	}
		
		
	

