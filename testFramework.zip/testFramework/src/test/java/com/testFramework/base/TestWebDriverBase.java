package com.testFramework.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;







	public class TestWebDriverBase {
	
	protected static WebElement element = null;
	public static WebDriver driver;
	
	public TestWebDriverBase(WebDriver driver)
	{
		
		TestWebDriverBase.driver = driver;
	}
	
	public static WebDriver getInstance()
	{
		if(driver== null)
		{
			TestWebDriverBase.driver =  driver;
		}
		return driver;
	}
	
}
