package com.testFramework.base;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.LogStatus;
import com.testFramework.log.TestLog;
import com.testFramework.log.TestLog.Status;

public abstract class AbstractBasePage extends TestWebDriverBase{

	public AbstractBasePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	private WebElement element = null;
	public TestLog testLog = TestLog.getInstance();
	
	public  WebElement getWebElemenetByID(String idAtrribute)
	
	{
		try{
			
			element =driver.findElement(By.id(idAtrribute));
			
		}
		catch( NoSuchElementException ex)
		{
			testLog.logResult(LogStatus.PASS, "WebElement is not present with Given ID");
		}
		return element;
		
	}
	
	

}
