package com.testFramework.testStep;

import java.util.Scanner;
import java.util.StringTokenizer;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.testFramework.base.AbstractBasePage;
import com.testFramework.base.TestWebDriverBase;
import com.testFramework.log.TestLog;

public class TestStep extends AbstractBasePage {

	public TestStep(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	/*public TestStep() {
		// TODO Auto-generated constructor stub
	}
*/
	
	public TestLog testLog = TestLog.getInstance();
	

/*private static TestStep testStep;
	

	public static TestStep getInstance()
	{
		if(testStep== null)
		{
			 testStep = new TestStep(driver) ;
		}
		return testStep;
	}
	*/
	public void highLightElement(WebElement element) 
	{
		try 
		{
			JavascriptExecutor js=(JavascriptExecutor)driver; 
			js.executeScript("arguments[0].setAttribute('style', 'background: green; border: 2px solid red;');", element);
			Thread.sleep(500);
			js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element); 
		} 
		catch (NoSuchElementException e) 
		{
			testLog.logMessage("ERROR: CONTROL NOT FOUND "+element );
			System.out.println("ERROR: CONTROL NOT FOUND"+element);			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			testLog.logMessage("ERROR: CONTROL NOT FOUND "+element );
			System.out.println("ERROR: CONTROL NOT FOUND"+element);	
		} 
		
	}

	public void debug()
	{
		Scanner in = new Scanner(System.in); 
		String Command = "";
		boolean done=false;
		while(!done)
		{
			try
			{
				System.out.print("Command: ");    
				Command = in.next(); 
				if(Command.toLowerCase().equalsIgnoreCase("done"))
				{
					
						done=true;

				}
				else if(Command.startsWith("name"))
				{ 
					StringTokenizer st2 = 
							new StringTokenizer(Command, "=");
					st2.nextToken();
					String ele=st2.nextToken();
					WebElement element=driver.findElement(By.name(ele));
					highLightElement(element);
				}
				else if(Command.startsWith("id"))
				{
					StringTokenizer st2 = 
							new StringTokenizer(Command, "=");
					st2.nextToken();
					String ele=st2.nextToken();
					WebElement element=driver.findElement(By.id(ele));
					highLightElement(element);
				}
				else if(Command.startsWith("xpath"))
				{
					StringTokenizer st2 = 
							new StringTokenizer(Command, "=");
					st2.nextToken();
					String ele=st2.nextToken();
					WebElement element=driver.findElement(By.xpath(ele));
					highLightElement(element);
				}
			}
			catch (NoSuchElementException e) {
				testLog.logMessage("ERROR: CONTROL NOT FOUND "+ Command );
				System.out.println("ERROR: CONTROL NOT FOUND "+Command);
			}
		}		
		in.close();
	}


}
