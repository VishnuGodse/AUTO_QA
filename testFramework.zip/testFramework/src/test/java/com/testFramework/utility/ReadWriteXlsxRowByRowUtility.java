package com.testFramework.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadWriteXlsxRowByRowUtility {

	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String file = "G:\\Files\\TestDataExcel.xlsx";
		
		XSSFWorkbook wb = null;
		XSSFSheet sheet;
		Row row = null;
		int rows=0;
	
		File files = new File (file);
			FileInputStream fis = new FileInputStream (files);


			wb = new XSSFWorkbook(fis) ;
			
			sheet =  wb.getSheet("ok");
			row = sheet.createRow(0);
			for (int i =0; i<=3;i++)
			{
			row.createCell(0).setCellValue("vishnu godse");
			row.createCell(1).setCellValue("TCS");
			row.createCell(2).setCellValue("Trade");
			row.createCell(3).setCellValue("0310");
			
			}
			
			
			for (int j=1;j<=20;j++)
				
			{
				
				row = sheet.createRow(j);
				if (j <= 5)
				{
				row.createCell(0).setCellValue("******");
				row.createCell(1).setCellValue("******");
				row.createCell(2).setCellValue("******");
				row.createCell(3).setCellValue("******");
				}
				
				
				if (j > 5 && j <= 10)
				{
				row.createCell(0).setCellValue("12345");
				row.createCell(1).setCellValue("12345");
				row.createCell(2).setCellValue("12345");
				row.createCell(3).setCellValue("12345");
				}
				
				if (j > 10 && j <= 15)
				{
				row.createCell(0).setCellValue("sdghash");
				row.createCell(1).setCellValue("sjghdjsj");
				row.createCell(2).setCellValue("sjgdjasajh");
				row.createCell(3).setCellValue("ksjahdkasjdh");
				}
				
				if (j > 15 && j <= 20)
				{
				row.createCell(0).setCellValue("55555");
				row.createCell(1).setCellValue("55555");
				row.createCell(2).setCellValue("55555");
				row.createCell(3).setCellValue("55555");
				}
				
							
				
				
			}
			
			
			FileOutputStream fos = new FileOutputStream (files);
			
			wb.write(fos);
			fos.close();
	}

}
