package com.testFramework.config;

import java.io.FileInputStream;
import java.util.Properties;

import com.testFramework.log.TestLog;


public class ConfigServices{

	Properties configFile;
	FileInputStream fis;
	
	

	private static ConfigServices configServices;
	

	
	public static ConfigServices getInstance()
	{
		if(configServices== null)
		{
			configServices = new ConfigServices();
		}
		return configServices;
	}
	
	
	public ConfigServices (){
		
		configFile = new Properties();
		try {
			fis = new FileInputStream("application.properties");
			configFile.load(fis);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		}
		

//	private String  startPage;
	
	public String getdbUser() {
		// TODO Auto-generated method stub
		String	dbUser =  configFile.getProperty("dbUser");
		return dbUser;
	}
	
	
	public String getdbPassword() {
		// TODO Auto-generated method stub
		String	dbPassword =  configFile.getProperty("dbPassword");
		return dbPassword;
	}
	
	public String getdbURL() {
		// TODO Auto-generated method stub
		String	dbURL =  configFile.getProperty("dbURL");
		return dbURL;
	}
	
	
	public String getapplicationUser() {
		// TODO Auto-generated method stub
		String	applicationUser =  configFile.getProperty("applicationUser");
		return applicationUser;
	}
	public String getStartPage() {
		// TODO Auto-generated method stub
		String	startPage =  configFile.getProperty("startPage");
		return startPage;
	}
	
	public String getLogDir() {
		// TODO Auto-generated method stub
		String	startPage =  configFile.getProperty("logPath");
		return startPage;
	}

	public String getDriverPath() {
		// TODO Auto-generated method stub
		String	driverPath =  configFile.getProperty("driverPath");
		return driverPath;
	}

	public String getScreenShotPath() {
	// TODO Auto-generated method stub
	String	screenShotsPath =  configFile.getProperty("screenShots");
	return screenShotsPath;
}

	
}
