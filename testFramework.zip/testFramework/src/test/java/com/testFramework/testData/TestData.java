package com.testFramework.testData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

import com.relevantcodes.extentreports.LogStatus;
import com.testFramework.log.TestLog;

public class TestData {
	
	

	XSSFWorkbook wb;
	XSSFSheet sheet;
	XSSFRow row;
	XSSFCell cell;
	int rowNum =0;
	int rowIdCsv=0;
	int columnIdCsv=0;
	public Connection connection =null;
	public PreparedStatement statement=null ;
	public ResultSet rset =null;
	boolean dbConnectresult= false;
	public  String csvtestDataFileName;
	public String basePathTestData = "G:\\TestFramework\\testFramework\\src\\test\\java\\Resources\\";
	public TestLog testLog = TestLog.getInstance();
	FileReader fr;
	BufferedReader br ;
	FileInputStream fis;
	private static TestData testdata;
	
	private TestData()
	{
		
	}
	
	
	 
	public static TestData getInstance()
	{
		if(testdata== null)
		{
			testdata = new TestData();
		}
		return testdata;
	}
	
	
	public void readTestData(String fileName,String rowID) throws IOException {
		
		 fis = new FileInputStream(basePathTestData+fileName);
		wb = new XSSFWorkbook(fis);
		sheet = wb.getSheetAt(0);
		row = sheet.getRow(0);
		
		try
		{
		for(int myRow =1 ; myRow <= sheet.getLastRowNum();myRow++)
			
		{
			String checkpoint = sheet.getRow(myRow).getCell(0).getStringCellValue();
			
			if(checkpoint.equalsIgnoreCase(rowID))
			{
				rowNum = myRow;
				//System.out.println(rowNum);
				break;
			}
			
			
		else
			{
				
				continue;
			}
			
		}
		}
		
		catch(Exception ex)
		{
			ex.getMessage();
			System.out.println("Row Id not Found..!!");
			testLog.logResult(LogStatus.ERROR, "Row Id not Found..!!");
		}
		
	//	return rowNum;
		}
	
	
	public String getTestData (String ColName)
	{
	
		int col = 0;
		
		try {
			
			row = sheet.getRow(rowNum);
			
			//int me = row.getLastCellNum();
			
		for (int mycol =1; mycol <= row.getLastCellNum(); mycol++)
			
		{   
			
			String columnName = sheet.getRow(1).getCell(mycol).getStringCellValue();
			
			
			if (columnName.equalsIgnoreCase(ColName))
			{
								
				col =mycol;
				//System.out.println(columnName);
				break;
			}
			
			/*else {
				
				continue;
				
			}
				*/
		}
		
}
		
		catch(Exception ex)
		{
			ex.getMessage();
			System.out.println("Row Id not Found..!!");
			testLog.logResult(LogStatus.ERROR, "Row Id not Found..!!");
		}
		
		String inputValue = sheet.getRow(rowNum).getCell(col).getStringCellValue();
		//System.out.println(inputValue);
		return  inputValue;
		
		
	}
	
	
public void readTestDataFromCSV(String fileName,String rowID) {
		
	try
	{
	
		csvtestDataFileName= basePathTestData+fileName;
		
		fr = new FileReader(csvtestDataFileName);
		br= new BufferedReader(fr);
		
		String nextLine ;
		
		
		try
		{     
			while ((nextLine = br.readLine())!= null)
			{
			String[] fff =	nextLine.split(",",0);
				if (fff[0].equals(rowID))
				{
					//System.out.println(rowID);
					//System.out.println(rowIdCsv);
					break;
					
				}
				
				rowIdCsv = rowIdCsv+1;
				
			}
			
		}
		
		catch(Exception ex)
		{
			ex.getMessage();
			System.out.println("Row Id not Found..!!");
			testLog.logResult(LogStatus.ERROR, "Row Id not Found..!!");
		}
		
	}
	
	catch(IOException ex)
	{
		ex.printStackTrace();
	}
	//	return rowNum;
		}
	


public String getDataFromCSV(String fileName,String columnName)

{
	String csvColumnName = null;
	String value = null;
	String nextLine;
	int id =0;
	try
	{
		fr = new FileReader(csvtestDataFileName);
		br= new BufferedReader(fr);
		
		
		
		
		while((nextLine = br.readLine())!=null)
		{
			if(nextLine.contains(columnName))
			{
				
				String temp[] = nextLine.split(",");
				
				for(int j=0;j<=temp.length;j++)
				{
					
					if(temp[j].equals(columnName))
					{
						
						columnIdCsv =j;
						break;
					}
				}
			}
			
			if(rowIdCsv==id)
			{
				
				value = nextLine.split(",")[0];
			}
			
			if(nextLine.split(",")[0].equals(value))
			{
				csvColumnName = nextLine.split(",")[columnIdCsv];
				break;
			}
		id=id+1;	
		}
		
	}
	catch(IOException ex)
	{
		ex.printStackTrace();
		testLog.logResult(LogStatus.ERROR, "Column Id not Found..!!");
	}
	
	//System.out.println("CSV get Data Returned column Value : "+ csvColumnName);
	
	return csvColumnName;
	
}
public synchronized boolean connectDatabase(String dbURL,String dbUserName,String dbPassword)

{  
	dbConnectresult =false;
	
	
		try {
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Oracle JDBC Driver Registered....!");
		
		
		}
		catch(ClassNotFoundException ex)
		{
			ex.printStackTrace();
			dbConnectresult = false;
			testLog.logResult(LogStatus.ERROR, "Oracle JDBC Driver Registeration Failed");
		}
		
		try
		{
		connection = DriverManager.getConnection(dbURL,dbUserName, dbPassword);
		
		if(connection !=null)
		{
			dbConnectresult = true;
			System.out.println("Oracle Database Connection Established....!");
		}
		}
	
		
	catch (SQLException ex)
	{
		ex.printStackTrace();
		dbConnectresult = false;
		testLog.logResult(LogStatus.ERROR, "Oracle Database Connection  Failed..!!");
	}

	return dbConnectresult;

}

public  void closeConnectDatabase()

{  try
{
	if(connection !=null)
	{
		connection.close();
		System.out.println("Oracle Database Connection Closed....!");
	}
}

catch(Exception ex)
{
	ex.printStackTrace();
	testLog.logResult(LogStatus.ERROR, "Oracle Connection Close Failed..");
	}
}


HashMap<String,String> data = new HashMap<String,String>();



public synchronized void readDatabase(String queryString) throws SQLException 

{ 
	try
	{
		if(connection!=null)
		{
		
			statement = connection.prepareStatement(queryString);
	 
			//statement.setString(arg0, arg1);
			rset = statement.executeQuery();
			rset = statement.getResultSet();
			
			boolean resultSetBoolean = rset.next();
			
			
			if(resultSetBoolean) {
				
				ResultSetMetaData metaData = rset.getMetaData();
				int count = metaData.getColumnCount();
				
				for (int i =1;i<=count;i++)
				{
					String coulumnName = metaData.getColumnName(i);
														
					setVariable(coulumnName,rset.getString(coulumnName));
					
							
					/*
					int type = metaData.getColumnType(i);
					if(type==Types.VARCHAR || type==Types.CHAR )
					{
					
						setVariable(coulumnName,rset.getString(coulumnName));
					//System.out.println(" Customer Name is.......  : " + CustomerName  );
					}
						
					
					
					if(type==Types.INTEGER || type==Types.NCHAR || type==Types.NVARCHAR || type==Types.NUMERIC)
					{
						setVariable(coulumnName,rset.getString(coulumnName));
						System.out.println("INT  vishnu narayan godse.......  : " + rset.getString(coulumnName)  );
					}*/
					
			}
	
			}
	
}
else
{

	System.out.println("NO DATABASE RECORD FOUND..!!!");
}
	
	
	
	
	}
	catch(SQLException ex)
	{
		ex.printStackTrace();
		testLog.logResult(LogStatus.ERROR, " Error -Query Not Defined Properly OR DATA Unavailable OR Check DB Creds ..");
	}
	
	finally
	{
		if (rset!=null)
		{
			rset.close();
		}
	}
}

public String getVariable (String key)

{
	String value= null;
			
			try
	{
				
				
			Set<String> keys =data.keySet();
			
			Iterator<String> itr = keys.iterator();
			boolean resultSetBoolean = itr.hasNext();
			Collection<String> count = data.values();
			
			if(resultSetBoolean)
			{
				for (int i =1;i<=count.size();i++)
			{
				String key1 =(String)itr.next();
				if(key.equalsIgnoreCase(key1))
				{
				value=(String)data.get(key);
				break;
				}
			
			}
			
			
			}
				
	}
	catch (Exception ex)
	{
		ex.printStackTrace();
		testLog.logResult(LogStatus.ERROR, "Aliase NAME not found in HASHMAP");
	}
	
	return value;
}


public void setDBDataInExcel(String key,String value)
{
	
	
	String fileName ="DBData.xlsx";
	
	try
	{
	FileInputStream fis = new FileInputStream(basePathTestData+fileName);
	XSSFWorkbook	wb = new XSSFWorkbook(fis);
	XSSFSheet	sheet = wb.getSheetAt(0);
	XSSFRow	row = sheet.getRow(0);
	int rowID = sheet.getLastRowNum();
				
		
		row = sheet.createRow(rowID+1);
		
		row.createCell(0).setCellValue(key);
		row.createCell(1).setCellValue(value);
		
		FileOutputStream fos = new  FileOutputStream(basePathTestData+fileName);
		wb.write(fos);
		fos.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			
			testLog.logResult(LogStatus.ERROR, "DB DATA write Failed");
		}
			
			
	
	
	
	
}


public List<String> getDBDataFromExcel()
{
	String fileName ="DBData.xlsx";
	 
	List<String>ls = null;
	
	try
	{
		FileInputStream fis = new FileInputStream(basePathTestData+fileName);
		XSSFWorkbook	wb = new XSSFWorkbook(fis);
		XSSFSheet	sheet = wb.getSheetAt(0);
		XSSFRow	row = sheet.getRow(0);
		
		ls = new ArrayList<String>();
		
		for (int rowIndex=2;rowIndex<=sheet.getLastRowNum();rowIndex++)
		{
			row = sheet.getRow(rowIndex);
			if(row!=null)
			{
				XSSFCell cell = row.getCell(1);
				if(cell!=null && !(cell.getCellType() == Cell.CELL_TYPE_BLANK))
				{
					String cellValues = cell.getStringCellValue();
					if(!cellValues.contains("") || cellValues != null || !cellValues.contains(" "))
					{
					ls.add(cellValues);
					}
				}
			}
		}
	}
	catch (Exception ex)
	{
		ex.printStackTrace();
		testLog.logResult(LogStatus.ERROR, "Alias Name Not Found in DB Data ");
	}
	
	return ls;
	
}





//(dataProvider="DbDataCsv")
/*public List<String> getDBDataFromCSV()
{
	
}

@DataProvider(name="DbDataCsv")
public Object[][] provider()
{
	
		
		List<String> list = readDataFromCSVForDBDataIgnoredList();
		
		return new Object[][] {{"Value",list}};
	
	
	}

*/



public List<String> getDBDataFromCSVForDBDataIgnoredList() {
	// TODO Auto-generated method stub
	List<String> list = null;
	
	String data;
	String fileName = "DBData.csv";
	int columnNumber = 1;
	String nextLine;
	try
	{
		fr = new FileReader(basePathTestData+fileName);
		br= new BufferedReader(fr);
		list = new ArrayList<String>();
		
		br.readLine();
		br.readLine();
		
		while((nextLine=br.readLine())!=null)
		{
			
			String dataLength[] = nextLine.split(",");
			
			
					data = dataLength[columnNumber];
					
					list.add(data);
					
				
			}
			
		
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
		testLog.logResult(LogStatus.ERROR, "Alias Name Not Found in DB Data ");
	}
	return list;
}



public void setDBDataInCSV(String key,String value)
{
	
	
	 String fileName = "DBData.csv";
	
	

	 //basePathTestData+fileName;
	 try
		{ 
		 
		
	 		FileWriter fw  = new FileWriter(basePathTestData+fileName,true);
	 		 BufferedWriter writer = new BufferedWriter(fw);
	 		 
	 	
	    	//writer.newLine();
	    	
	 		String records = (key + "," + value);
	
	 		
	 			writer.write(records);
	 			writer.newLine();
	 		
	 		writer.flush();
	 		writer.close();
		
		}
		catch (Exception ex)
		{
			
			ex.printStackTrace();
			testLog.logResult(LogStatus.ERROR, "Set DB Data Failed ");
		}
}


private void setVariable(String coulumnName, String value) {
	// TODO Auto-generated method stub
	try
	{
	      data.put(coulumnName, value);
	
	}
	
	catch(Exception ex)
	{
		ex.printStackTrace();
		testLog.logResult(LogStatus.ERROR, "Set Variable Failed in HASMAP ");
	}
	
}



}
