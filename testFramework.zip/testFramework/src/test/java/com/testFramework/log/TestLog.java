package com.testFramework.log;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;





public class TestLog{

	
	
	private static TestLog testLog;
	
	private TestLog()
	{
		
	}
	
	public String logPath;
	
	public void setLogPath(String logPath)
	{
		this.logPath = logPath;
	}
	 
	public String getLogPath ()
	{
		return logPath;
	}
	public static TestLog getInstance()
	{
		if(testLog== null)
		{
			testLog = new TestLog();
		}
		return testLog;
	}
	
	
	public static ExtentReports report;
	//= new ExtentReports(Constants.TestExitreport,true);
	public static ExtentTest logger;
	

	public void setupLog(String testCaseName,String logPath) 
	{
		String path;
	try
	{
		DateTimeFormatter dateFormat =  DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDateTime date =  LocalDateTime.now();
		String dateSRC = dateFormat.format(date);
		
		File file = new File( logPath + "\\"+ dateSRC);
		
		if(!file.exists())
		{
			file.mkdir();
		   
		}
		
		 path =file.getAbsolutePath();
		
		 DateTimeFormatter dateFormat1 =  DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
			LocalDateTime date1 =  LocalDateTime.now();
			String dateSRC1 = dateFormat1.format(date1);
			
		File file2 = new File( path + "\\"+testCaseName +"_"+ dateSRC1);
						
		file2.mkdir();
			
		path =file2.getAbsolutePath();
		
		setLogPath(path);
		
		//File file = new File( logPath + "\\"+testCaseName +"_"+ dateSRC);
		 report =  new ExtentReports(path+"\\"+testCaseName+ "_" +dateSRC1+".html",true);
		 
	     logger = report.startTest(testCaseName);
	     //logger.log(LogStatus.INFO, "0000000000000000000000000000000000000000");
	
	}
	
	catch(Exception ex)
	{
		testLog.logResult(LogStatus.ERROR, "Log Start Setup Failed : - Something went wrong while setting the LogPath,LogFolder");
	}
	}
	
	public void renameLogFolder(String path,String logStatus)
	{
	
		try {
			
		File oldFolderName = new File(path);
		File newFolderName = new File(path+"_"+logStatus);
		
		oldFolderName.renameTo(newFolderName);
		}
		
		catch(Exception ex)
		{
			testLog.logResult(LogStatus.ERROR, "Log End Setup Failed : - Something went wrong while rename the LogFolder");
		}
		
	}
	
	public enum Status { PASS,FAIL,SKIP,INCOMPLETE,INFO };
	
	
	public void logMessage(String note)
	{
		logger.log(LogStatus.INFO,note);
		
	}
	
	public void logResult (LogStatus status,String note)
	{
		logger.log(status, note);
		
	}
	
	public void logResultWithScreenshot (LogStatus status,String note ,String imagePath)
	{
		logger.log(status, note,imagePath);
		
	}
	
	
	public void endTestCase() 
	{
		report.endTest(logger);
		report.flush();
		
	}
	
	
	

	
	public String addScreenShotinReport(String SnapshotPath) {
		
		String imagePath = null;
		try
		{
		
		 imagePath  =logger.addScreenCapture(SnapshotPath);
		
		}
		
		catch(Exception ex)
		{
			testLog.logResult(LogStatus.ERROR, "Screenshot Insertation in Report is  Failed :");
		}
		return imagePath ;
	}
	
	
	}


