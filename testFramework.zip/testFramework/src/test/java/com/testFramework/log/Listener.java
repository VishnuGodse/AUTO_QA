package com.testFramework.log;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;


public class Listener implements ITestListener,IInvokedMethodListener  {
	
	static final Logger Log = Logger.getLogger(Listener.class);

	public void onFinish(ITestContext arg0) {
		
		PropertyConfigurator.configure("log4j.properties");
		Reporter.log("Completed executing test Case  " + arg0.getName(), true);
		Log.info("Completed executing test " + arg0.getName());
	}

	public void onStart(ITestContext arg0) {
		PropertyConfigurator.configure("log4j.properties");
		Reporter.log("About to begin executing test " + arg0.getName(), true);
		Log.info("About to begin executing test " + arg0.getName());
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		PropertyConfigurator.configure("log4j.properties");
		Reporter.log("|| +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ||");
		Log.info("|| ================================================================ ||");
		
	}

	public void onTestFailure(ITestResult arg0) {
		//PropertyConfigurator.configure("log4j.properties");
		printTestResults(arg0);
	}

	private void printTestResults(ITestResult result) {
		PropertyConfigurator.configure("log4j.properties");
		Reporter.log("TestName = " + result.getTestName(), true);
		Log.info("TestName = " + result.getTestName());
		
		Reporter.log("Test Method resides in " + result.getTestClass().getName(), true);
		Log.info("Test Method resides in " + result.getTestClass().getName());
		if (result.getParameters().length != 0) {
			String params = null;
			for (Object parameter : result.getParameters()) {
				params += parameter.toString() + ",";
			}
			Reporter.log("Test Method had the following parameters : " + params, true);
			Log.info("Test Method had the following parameters : " + params);
			
		}
		String status = null;
		switch (result.getStatus()) {
		case ITestResult.SUCCESS:
			status = "Pass";
			break;
		case ITestResult.FAILURE:
			status = "Failed";
			break;
		case ITestResult.SKIP:
			status = "Skipped";
		}
		Reporter.log("Test Status: " + status, true);
		Log.info("Test Status: " + status);
		
	}

	public void onTestSkipped(ITestResult arg0) {
		PropertyConfigurator.configure("log4j.properties");
		
		printTestResults(arg0);
		Log.info("These Tests are Skipped : " + arg0.getName());
	}

	public void onTestStart(ITestResult arg0) {
		PropertyConfigurator.configure("log4j.properties");
		Log.info("********************************************************************************");
	}

	public void onTestSuccess(ITestResult arg0) {
		//PropertyConfigurator.configure("log4j.properties");
		printTestResults(arg0);
	}

	public void afterInvocation(IInvokedMethod arg0, ITestResult arg1) {
		PropertyConfigurator.configure("log4j.properties");
		String textMsg = "Completed executing " + returnMethodName(arg0.getTestMethod());
		Reporter.log(textMsg, true);
		Log.info(textMsg);
		

	}

	public void beforeInvocation(IInvokedMethod arg0, ITestResult arg1) {
		PropertyConfigurator.configure("log4j.properties");
		String textMsg = "About to begin executing " + returnMethodName(arg0.getTestMethod());
		Reporter.log(textMsg, true);
		Log.info(textMsg);
	}

	private String returnMethodName(ITestNGMethod method) {
		//PropertyConfigurator.configure("log4j.properties");
		return method.getRealClass().getSimpleName() + "." + method.getMethodName();
	}

	
}