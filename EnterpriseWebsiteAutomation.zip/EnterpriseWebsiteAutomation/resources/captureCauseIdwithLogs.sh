PASSWORD='rahul@1002'
USERNAME='rahul.jain'
accountId=$1
message=$2
propertyFilepath=$3
os=$4
#echo $os
while
	read  mach
do
if [ "$os" = "WINDOWS" ]
then
logs=`echo y |plink -ssh "${USERNAME}"@"${mach}" -pw $PASSWORD "cat /var/tmp/RequestLog.log |grep '$extra' | grep 'userid=$accountId'|grep 'msg=$message'| tail -1"`
else
logs=`sshpass -p "$PASSWORD" ssh -oStrictHostKeyChecking=no -nq  "${USERNAME}"@"${mach}" "cat /var/tmp/RequestLog.log |grep '$extra' | grep "userid=$accountId"|grep "msg=$message"| tail -1"`
fi
echo $logs 
done<$propertyFilepath 
