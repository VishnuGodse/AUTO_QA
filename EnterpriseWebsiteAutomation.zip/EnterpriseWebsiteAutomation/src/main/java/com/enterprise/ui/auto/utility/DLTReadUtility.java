package com.enterprise.ui.auto.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.draw.geom.Path;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.aventstack.extentreports.utils.Reader;
import com.itextpdf.text.pdf.parser.clipper.Paths;
import com.opencsv.CSVReader;

public class DLTReadUtility {
	String sheetName;
	List<String> arrName;

	public List<String> readData(String filePath, String fileName, int sheetname) throws Exception {
		File file = new File(filePath + "\\" + fileName);

		try {

			if (fileName.contains(".xls") || fileName.contains(".xlsx")) {
				// Create an object of FileInputStream class to read excel file

				DataFormatter formatter = new DataFormatter(); // creating formatter using the default locale

				FileInputStream inputStream = new FileInputStream(file);

				Workbook rWorkbook = null;

				// Find the file extension by splitting file name in substring and getting only
				// extension name

				String fileExtensionName = fileName.substring(fileName.indexOf("."));

				arrName = new ArrayList<String>();

				// Check condition if the file is xlsx file

				if (fileExtensionName.equals(".xlsx")) {

					// If it is xlsx file then create object of XSSFWorkbook class

					rWorkbook = new XSSFWorkbook(inputStream);
					sheetName = rWorkbook.getSheetName(0);

				}

				// Check condition if the file is xls file

				else if (fileExtensionName.equals(".xls")) {

					// If it is xls file then create object of HSSFWorkbook class

					rWorkbook = new HSSFWorkbook(inputStream);
					sheetName = rWorkbook.getSheetName(0);
				}

				// Read sheet inside the workbook by its name

				Sheet guru99Sheet = rWorkbook.getSheet(sheetName);
				System.out.println("sheet" + guru99Sheet);

				// Find number of rows in excel file
				int col = guru99Sheet.getTopRow();
				System.out.println("col no " + col);

				int rowCount = guru99Sheet.getLastRowNum() - guru99Sheet.getFirstRowNum();

				// Create a loop over all the rows of excel file to read it

				for (int i = 1; i < rowCount + 1; i++) {

					Row row = guru99Sheet.getRow(i);

					// Create a loop to print cell values in a row

					for (int j = 0; j < row.getLastCellNum(); j++) {

						// Print Excel data in console

						Cell t = row.getCell(j);

						String j_username = formatter.formatCellValue(t);
						// System.out.println("Test "+j_username);
						// arrName.add(t.getStringCellValue());
						arrName.add(j_username);

					}

					System.out.println(arrName);
					System.out.println("Size of the arrayList: " + arrName.size());
					// Create an iterator to iterate through the arrayList- 'arrName'
					Iterator<String> itr = arrName.iterator();
					while (itr.hasNext()) {
						System.out.println("arrayList values: " + itr.next());
						// System.out.println();
					}

				}

			} else if (fileName.contains(".csv")) {
				System.out.println("In CSV");
				CSVReader reader = new CSVReader(new FileReader(file));

				List<String[]> li = reader.readAll();
				System.out.println("Total rows which we have is " + li.size());

				Iterator<String[]> i1 = li.iterator();
				while (i1.hasNext()) {

					String[] str = i1.next();

					System.out.print(" Values are ");

					for (int i = 0; i < str.length; i++) {

						System.out.print(" " + str[i]);

					}
					System.out.println("   ");
				}

			}

			else if (fileName.contains(".txt")) {

				BufferedReader br = null;

				try {

					String sCurrentLine;

					br = new BufferedReader(new FileReader(file));
					int len = 1;
					int i = 0;
					String CurLine = br.readLine();
					len = wordCount(CurLine);
					System.out.println("Words" + len);
					while ((sCurrentLine = br.readLine()) != null) {

						System.out.println("1 st line " + sCurrentLine);

						String splitData[] = sCurrentLine.split("\\s", 2);

						System.out.println("1 " + splitData[0]);
						System.out.println("2 " + splitData[1]);

					}

				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						if (br != null)
							br.close();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}

			}

		} catch (Exception e) {
			System.out.println("Exception caught" + e);
		}
		return arrName;

	}

	
	  public static void main(String args[]) throws Exception { // 
			/*
			 * String filename = System.getProperty("user.dir") + "\\DLT_SMS_Upload\\" //
			 * +"File_Msg_Mask.xlsx";
			 */
		  String filename = "File_Msg.csv";
	  
	  String path =
	  "C:/Gupshup-Git/gupshup-automations/EnterpriseWebsiteAutomation/EnterpriseWebsiteAutomation/DLT_SMS_Upload";
	  DLTReadUtility dru = new DLTReadUtility();
	  
	  dru.readData(path, filename, 0);
	  
	  List<String> arr = new ArrayList<String>(); arr = dru.readData(path,
	  filename, 0);
	  
	  int tc=0; for (int i = 0; i < arr.size(); i++) {
	  
	  System.out.println(arr.get(i).toString()); String s=arr.get(i).toString();
	  int c=dru.charCount(s); if(c==10) { System.out.println("Phone"); }
	  if(s.contains(" ")&&(c>10)) { System.out.println("Msg"); } if(c<5) {
	  System.out.println("Mask"); } if(c==19) { if(tc==0) {
	  System.out.println("template id"); }
	  
	  if(tc==1) { System.out.println("mask id"); } tc++;
	  
	  }
	  
	  }
	  
	  }
	 
///
	public int wordCount(String string) {

		int count = 0;

		char ch[] = new char[string.length()];
		for (int i = 0; i < string.length(); i++) {
			ch[i] = string.charAt(i);
			if (((i > 0) && (ch[i] != ' ') && (ch[i - 1] == ' ')) || ((ch[0] != ' ') && (i == 0)))
				count++;
		}
		System.out.println("Count" + count);
		return count;

	}

	public int charCount(String s) {
		int count = 0;

		// Counts each character except space
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) != ' ')
				count++;
		}
		return count;

	}
}
