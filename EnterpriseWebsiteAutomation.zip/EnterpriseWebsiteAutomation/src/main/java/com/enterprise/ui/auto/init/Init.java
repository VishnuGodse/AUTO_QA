package com.enterprise.ui.auto.init;
import java.io.IOException;

import com.enterprise.ui.auto.Bo.EnvBO;


//import com.enterprise.moderate.testsuitebo.EnvBO;

public class Init {

	public static void main(String[] args) throws IOException {
		
		EnvBO env = new EnvBO();

	}

}
