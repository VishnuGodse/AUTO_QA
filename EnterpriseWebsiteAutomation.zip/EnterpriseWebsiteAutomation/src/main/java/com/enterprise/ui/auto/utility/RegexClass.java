package com.enterprise.ui.auto.utility;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.enterprise.ui.auto.Bo.EnvBO;


public class RegexClass {
	public EnvBO eb;
	Logger log;

	public RegexClass() throws IOException {
		eb = new EnvBO();
		log =Logger.getLogger(this.getClass());
	}
	//for moderate automation
/*	public String getRequestId(String requestType, String response) {
		String result = "";
		String reqId = "";
		if (requestType.equalsIgnoreCase("UploadandPost")) {
			String[] res = response.split(": ");
			if (response.contains("test")) {
				reqId = res[1].replaceAll("is getting processed as test sample.", "")
						.trim();
				result=reqId;
				return result;
			}else {
			String checker = eb.getChecker_account();
			reqId = res[1].replaceAll("sent to " + checker + ". An eMail notification has been sent for the same.", "")
					.trim();
			result=reqId;
			return result;
			}
		} else if (requestType.equalsIgnoreCase("PreviewTab")) {
//			success | Request id: 57866
			String [] res = response.split(": ");
			System.out.println(reqId);
			reqId = res[1].trim();
			result=reqId;
			return result;
		} else
			log.debug("Give proper Request Type");
		return result;
	}*/

	public String queryVariableReplace(String query, String toBeReplacedString) {
		String finalQuery = "";
		if (query.contains("#####")){
			finalQuery = query.replaceAll("#####", toBeReplacedString);

		} else
			log.info("Pattern Not found");
		return finalQuery;
	}
	public String queryVariableReplace(String query, String toBeReplacedString1,String toBeReplacedString2) {
		String finalQuery = "";
		String executingQuery= "";
		if (query.contains("#####")) {
			finalQuery = query.replaceAll("#####", toBeReplacedString1);

		}
		if (finalQuery.contains("?????")) {
			executingQuery = finalQuery.replaceAll("\\?\\?\\?\\?\\?", toBeReplacedString2);
		}
		else
			log.info("Pattern Not found");
		return executingQuery;
	}



}