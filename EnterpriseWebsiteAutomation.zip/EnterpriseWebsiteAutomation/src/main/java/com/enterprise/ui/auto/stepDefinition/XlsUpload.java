package com.enterprise.ui.auto.stepDefinition;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.DbConnectionUtility;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.sun.mail.iap.Response;

import cucumber.api.DataTable;
//import io.cucumber.java.cs.Ale;
import cucumber.api.java.en.Then;
//import io.cucumber.java.it.Date;

public class XlsUpload {
//	String balance;

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;

	public XlsUpload() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
	}

	/*
	 * @Then("^Check the initial account Balance$") public void
	 * check_the_initial_account_Balance() { String balancetmp =
	 * driver.findElement(By.xpath("(//span[@class='strong'])[1]")).getText();
	 * balance = balancetmp.replaceAll("[^0-9]", "").trim();
	 * log.logging("Initial Balance is : " + balance, "info");
	 * 
	 * }
	 */
	@Then("^XlsPosting Flow Started$")
	public void xlsposting_Flow_Started() {
		log.logging("XlsUpload Flow Started", "info");
	}

	@Then("^Enable the preview Attributes$")
	public void enable_the_preview_Attribute() throws IOException, InterruptedException {
		aggrAccId = env.getEnterpriseUsername();
		Object userId = query.getDBResponse(aggrAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("settingPreviewOn", userId.toString());

		if (result == false) {
			log.logging("History Tab Attribute not present so inserting in userId" + userId + " setting value as true",
					"info");

			query.setDBResponse("insertpreviewTrue", userId.toString());
		}

		Thread.sleep(5000);
		su.refreshPage();
	}

	@Then("^Upload the File$")
	public void upload_the_File(DataTable files) throws InterruptedException, IOException {

		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			if (otherLang == true) {

				log.logging("Selecting Unicode Tab  Tab", "info");
				driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
				Thread.sleep(5000);
			} else if (flash == true) {
				log.logging("Setting  Flash Flag : " + flash, "info");

				driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
				Thread.sleep(5000);
			} else if (unicodeFlash == true) {
				log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

				driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

			} else {
				log.logging("Selecting Text Tab final", "info");
//				Thread.sleep(20000);
//				WebDriverWait wait = new WebDriverWait(driver, 10);
				// WebElement
				// elementTextTab=wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[id=postTypeHeaderEnglishSmsSpan]")));
				WebElement element = driver.findElement(
						By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//			JavascriptExecutor executor = (JavascriptExecutor)driver;
//			executor.executeScript("arguments[0].click();", element);
//			Thread.sleep(5000);
				Actions action = new Actions(driver);

				action.moveToElement(element).click().perform();

//				WebElement Button1 =driver.findElement(By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//				Button1.submit();
//				Thread.sleep(5000);

				log.logging("Selecting Text Tab final", "info");

				// elementTextTab.sendKeys(Keys.ENTER);
				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}

			driver.findElement(By.id("defaultMsg")).clear();
			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFiles/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			boolean hisTabPresent;
			try {
				hisTabPresent = driver.findElement(By.linkText("History")).isDisplayed();
			} catch (Exception e) {
				hisTabPresent = false;
			}
			Thread.sleep(5000);
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();

			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}
			log.logging("Clicked on Upload Button", "info");
			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {
				log.logging("We have history tab so validation is according to History tab", "info");

				/*
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");

				log.logging("Now Checking Preview", "info"); // commted because it is unstable
				Thread.sleep(5000);
				driver.findElement(By.xpath("//img[@title='Preview']")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				Thread.sleep(3000);
				log.logging("Now Closing the Preview POP UP!!", "info");
				driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
				// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				Thread.sleep(3000);
				log.logging("Now Actually Posting the Campaign!", "info");
				Thread.sleep(3000);

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Thread.sleep(3000);
				// driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				Thread.sleep(3000);

				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				/*
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG'][1]//td//a)[1]"))
						.getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the causeId in table  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2]//td)[1]"))
						.getText();
				System.out.println(forTheTransaction);
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
			}
			Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			if (webarooNo.toString() == null) {
				log.logging("MsgTupple did not found in DB", "info");
				System.out.println("MsgTupple did not found in DB");
				break;
			}
			try {
				String[] wNo = webarooNo.toString().split(",");
				if (otherLang == true) {
					log.logging("Checking Webaroo No as 3 for unicode", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "3");
				} else if (flash == true) {
					log.logging("Checking Webaroo No as 5 for flash", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "5");
				} else if (unicodeFlash == true) {
					log.logging("Checking Webaroo No as 20 for unicode_flash", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "20");
				} else {
					log.logging("Checking Webaroo No as 0 for text Message", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "0");
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			
			
		}
//		sa.assertAll();
	}

	@Then("^Disable the preview Attributes$")
	public void disable_the_preview_Attribute() throws IOException, InterruptedException {
		aggrAccId = env.getEnterpriseAccountId();

		Object userId = query.getDBResponse(aggrAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("settingPreviewOff", userId.toString());

		if (result == false) {
			log.logging("History Tab Attribute not present so inserting in userId" + userId + " setting value as false",
					"info");

			boolean queryResult = query.setDBResponse("insertpreviewFalse", userId.toString());

			log.logging(queryResult + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "info");

		}
	}

	/*
	 * @Then("^Choose MsgType,message,phoneNo and post  the message  and check balance$"
	 * ) public void
	 * choose_MsgType_message_phoneNo_and_post_the_message_and_check_balance(
	 * DataTable msgtypemsg) throws Throwable {
	 * 
	 * for (Map<String, String> mappingMsg : msgtypemsg.asMaps(String.class,
	 * String.class)) { int phoneNocnt; String response = null; String responseExp =
	 * null;
	 * 
	 * log.logging("Passing the Phone No : " + phoneNo, "info"); if
	 * (mappingMsg.get("MessageType").equalsIgnoreCase("Text")) {
	 * driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click(); } if
	 * (mappingMsg.get("MessageType").equalsIgnoreCase("Unicode_Text")) {
	 * driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click(); } if
	 * (mappingMsg.get("MessageType").equalsIgnoreCase("Flash")) {
	 * driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click(); } if
	 * (mappingMsg.get("MessageType").equalsIgnoreCase("Unicode_Flash")) {
	 * driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click(); }
	 * Thread.sleep(5000);
	 * driver.findElement(By.xpath("(//textarea[@id='quickPostNumberBox'])[1]")).
	 * sendKeys(phoneNo); String msg = mappingMsg.get("Message");
	 * log.logging("Cleaning the Message Box", "info");
	 * driver.findElement(By.xpath("(//textarea[@id='quickPostTextArea'])[1]")).
	 * clear(); log.logging("Passing the Message : " + msg, "info");
	 * driver.findElement(By.xpath("(//textarea[@id='quickPostTextArea'])[1]")).
	 * sendKeys(msg);
	 * driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[1]")).
	 * click(); log.logging("Submitting the Message ", "info"); Thread.sleep(2000);
	 * response = driver.findElement(By.
	 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
	 * .getText(); log.logging("Checking response after submitting ", "info"); if
	 * (phoneNo.contains(",")) { String[] phoneArr = phoneNo.split(","); phoneNocnt
	 * = phoneArr.length; responseExp =
	 * "Your messages will be sent shortly subject to Current Status of your account.Messages sent to "
	 * + phoneNocnt + " phone numbers."; } else { phoneNocnt = 1; responseExp =
	 * "Your messages will be sent shortly subject to Current Status of your account."
	 * ;
	 * 
	 * } Assert.assertEquals(response, responseExp); su.refreshPage(); String
	 * balancetmp =
	 * driver.findElement(By.xpath("(//span[@class='strong'])[1]")).getText();
	 * String newbalance = balancetmp.replaceAll("[^0-9]", "").trim();
	 * log.logging("Checking new  balance : " + balance + " and old balance : " +
	 * newbalance, "info"); int newbalanceint = Integer.parseInt(newbalance);
	 * newbalanceint = (Integer.parseInt(balance) - newbalanceint);
	 * Assert.assertEquals(newbalanceint, 6); balance = newbalance;
	 * 
	 * } }
	 */

	/*
	 * @Then("^Click on create Group$") public void click_on_create_Group() {
	 * log.logging("Clicking on Create Group", "info");
	 * driver.findElement(By.xpath("(//input[@class='tbButton'])[3]")).click(); }
	 */

	/*
	 * @Then("^Pass unique Group Name$") public void pass_unique_Group_Name() {
	 * groupName = "Auto" + gu.genRandomName(6);
	 * log.logging("Creating Group with Name : " + groupName, "info");
	 * driver.findElement(By.id("grpName")).sendKeys(groupName);
	 * 
	 * }
	 * 
	 * @Then("^Create the Mask$") public void create_the_Mask() {
	 * log.logging("Selecting Mask with Index 0", "info");
	 * 
	 * WebElement defaultMaskId = driver.findElement(By.name("defaultMaskId")); new
	 * Select(defaultMaskId).selectByIndex(0);
	 * 
	 * }
	 */
	/*
	 * @Then("^check the group has been created or not$") public void
	 * check_the_group_has_been_created_or_not() throws InterruptedException {
	 * log.logging("Creating Group", "info");
	 * 
	 * driver.findElement(By.xpath("(//input[@class='tbButton'])[1]")).click();
	 * su.refreshPage(); boolean groupCreated = su.elemCheck(groupName);
	 * 
	 * Assert.assertEquals(groupCreated, true, "Group Not Created");
	 * log.logging(groupName + " Group Created", "info"); }
	 */

	/*
	 * @Then("^Add Members$") public void add_Members(DataTable memAdd) throws
	 * IOException, InterruptedException {
	 * 
	 * for (Map<String, String> memAddition : memAdd.asMaps(String.class,
	 * String.class)) { String response = null; String responseExp = null;
	 * log.logging("Clicking on Manage Member", "info");
	 * driver.findElement(By.xpath("(//div[@classname='inactiveQuickActionTab'])[2]"
	 * )).click(); Thread.sleep(2000);
	 * driver.findElement(By.xpath("(//div[@class='activeQuickActionInnerTab'])[2]")
	 * ).click(); if (memAddition.get("Mode").equalsIgnoreCase("TextBox")) {
	 * log.logging("Adding Members from TextBox", "info");
	 * 
	 * driver.findElement(By.xpath("(//textarea[@name='memberNumbersTextBox'])[1]"))
	 * .sendKeys(phoneNo); ; } if (memAddition.get("Mode").equalsIgnoreCase("File"))
	 * { log.logging("Adding Members from File", "info");
	 * 
	 * String filePath = gu.CreatefileFromString(phoneNo, "csv");
	 * driver.findElement(By.xpath("(//input[@name='fileUploadCheckBox'])[1]")).
	 * click();
	 * driver.findElement(By.xpath("(//input[@name='subscriberNumbersFile'])[1]")).
	 * sendKeys(filePath); Thread.sleep(10000); }
	 * log.logging("Clicking on Add Button", "info");
	 * 
	 * driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[2]")).
	 * click(); if (phoneNo.contains(",")) { String[] phoneArr = phoneNo.split(",");
	 * phoneNocnt = phoneArr.length; } else { phoneNocnt = 1;
	 * 
	 * } log.logging("Matching The response after adding", "info"); if
	 * (memAddition.get("id").equalsIgnoreCase("1")) { responseExp =
	 * "Successfully added " + phoneNocnt + " members."; response =
	 * driver.findElement(By.
	 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
	 * .getText();
	 * 
	 * } else { response = driver.findElement(By.
	 * xpath("//div[@classname='notification notificationRed']//div[1]"))
	 * .getText(); responseExp = phoneNocnt +
	 * " numbers are already members of group and have not been processed.";
	 * 
	 * } Assert.assertEquals(response, responseExp); log.logging("Got Response : " +
	 * response, "info"); // su.refreshPage();
	 * 
	 * }
	 * 
	 * }
	 */

	/*
	 * @Then("^Click on Make a Post with message \"([^\"]*)\"$") public void
	 * click_on_Make_a_Post_with_message(String msg) throws InterruptedException {
	 * log.logging("Posting wih Message " + msg, "info"); su.refreshPage();
	 * 
	 * driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[1]")).
	 * click(); Thread.sleep(2000);
	 * driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).clear();
	 * Thread.sleep(2000);
	 * 
	 * driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).sendKeys(msg);
	 * 
	 * Thread.sleep(2000);
	 * 
	 * }
	 * 
	 * @Then("^Click on Make a Post$") public void click_on_Make_a_Post() {
	 * log.logging("Clicking on Post Button", "info");
	 * 
	 * driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[1]")).
	 * click(); }
	 * 
	 * @Then("^Check the DB Response$") public void check_the_DB_Response() throws
	 * IOException, InterruptedException { String response = driver.findElement(By.
	 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
	 * .getText(); String causeId = response.replaceAll("[^0-9]", "").trim();
	 * log.logging("Got CauseId : " + causeId, "info"); Object status =
	 * query.getDBResponse(causeId, "status", "gettingMsgLogGroupPost");
	 * log.logging("Got Group Post Status   : " + status, "info");
	 * Assert.assertEquals(status.toString(), "PROCESSED");
	 * 
	 * }
	 * 
	 * @Then("^Check the Post and MemberCount of the Group$") public void
	 * check_the_Post_and_MemberCount_of_the_Group() { String groupDetails =
	 * driver.findElement(By.xpath("(//table[@class='groupList']//td)[3]")).getText(
	 * ); Assert.assertEquals(groupDetails, groupName + "   0 posts, " + phoneNocnt
	 * + " members"); log.logging("Verified Group Details : " + groupDetails,
	 * "info"); }
	 * 
	 * @Then("^Check Disabling the Group$") public void check_Disabling_the_Group()
	 * throws InterruptedException { log.logging("Disabling the Group : " +
	 * groupName, "info"); su.refreshPage();
	 * driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[4]")).
	 * click(); Alert alert = driver.switchTo().alert(); String disableAlert =
	 * driver.switchTo().alert().getText(); Assert.assertEquals(disableAlert,
	 * "Are you sure you want to disable the group?"); alert.accept();
	 * 
	 * String response = driver.findElement(By.
	 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
	 * .getText(); log.logging("Checking Response of Disabled Group : " + response,
	 * "info"); Assert.assertEquals(response,
	 * "Selected groups have been disabled.");
	 * 
	 * }
	 * 
	 * @Then("^Enabling  the Group$") public void enabling_the_Group() throws
	 * InterruptedException { log.logging("Now Clicking on Show Disabled Groups",
	 * "info"); su.refreshPage();
	 * 
	 * driver.findElement(By.id("enableDisableLinkTextSpan")).click();
	 * Thread.sleep(2000); log.logging("Checking that group is Present or Not",
	 * "info"); String groupLocator = "//input[@value='" + groupName + "']";
	 * driver.findElement(By.xpath(groupLocator)).click(); String grpName =
	 * driver.findElement(By.xpath("//div[@class='select-1by1']//span[1]")).getText(
	 * ); Assert.assertEquals(grpName.trim(), groupName, "Group Name Not Matched");
	 * log.logging("Enabling the group : " + grpName.trim(), "info");
	 * 
	 * driver.findElement(By.xpath("(//input[@value='Enable'])[1]")).click(); String
	 * response = driver.findElement(By.
	 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
	 * .getText(); log.logging("Checking Response of Enabled  Group : " + response,
	 * "info"); Assert.assertEquals(response, "Selected groups have been enabled.");
	 * log.logging("Now Clicking on Show Active Groups", "info");
	 * driver.findElement(By.id("enableDisableLinkTextSpan")).click();
	 * 
	 * }
	 * 
	 * @Then("^delete the group and check if deleted or not$") public void
	 * delete_the_group_and_check_if_deleted_or_not() throws InterruptedException {
	 * log.logging("Deleting the Group : " + groupName, "info"); su.refreshPage();
	 * 
	 * driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[5]")).
	 * click(); Alert alert = driver.switchTo().alert(); String alertMessage =
	 * driver.switchTo().alert().getText(); Assert.assertEquals(alertMessage,
	 * "Are you sure you want to delete the selected group?"); alert.accept();
	 * Thread.sleep(5000); String response = driver.findElement(By.
	 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
	 * .getText(); Assert.assertEquals(response,
	 * "Selected groups have been deleted."); log.logging("After deleting : " +
	 * groupName + " Verifying Response : " + response, "info");
	 * log.logging("Checking group Present or not on UI " + groupName, "info");
	 * su.refreshPage(); boolean groupLink = su.elemCheck(groupName);
	 * assertEquals(groupLink, false, "Group : " + groupName + " Still present!!");
	 * 
	 * }
	 * 
	 * @Then("^Select Differnt Message type Post it and check the webarooNo on MsgLog Table in Logging DB$"
	 * ) public void
	 * select_Differnt_Message_type_Post_it_and_check_the_webarooNo_on_MsgLog_Table_in_Logging_DB(
	 * DataTable msgNmsgType) throws InterruptedException, IOException {
	 * 
	 * for (Map<String, String> msgTypeMapping : msgNmsgType.asMaps(String.class,
	 * String.class)) { log.logging("Clicking on Making a Post", "info");
	 * driver.findElement(By.linkText("Group")).click();
	 * click_on_Make_a_Post_with_message(msgTypeMapping.get("Message")); //
	 * driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[1]")).
	 * click(); if (msgTypeMapping.get("MsgType").equalsIgnoreCase("English")) {
	 * log.logging("Clicking on English", "info");
	 * 
	 * driver.findElement(By.xpath("(//div[@class='activeQuickActionInnerTab'])[1]")
	 * ).click(); } if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Unicode")) {
	 * log.logging("Clicking on Other Languages", "info");
	 * 
	 * driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[5]")).
	 * click(); } if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Flash")) {
	 * log.logging("Clicking on Flash SMS", "info");
	 * 
	 * driver.findElement(By.xpath("(//div[@classname='inactiveQuickActionTab'])[4]"
	 * )).click(); } if
	 * (msgTypeMapping.get("MsgType").equalsIgnoreCase("Unicode_Flash")) {
	 * log.logging("Clicking on Unicode Flash SMS", "info");
	 * 
	 * driver.findElement(By.xpath("(//div[@classname='inactiveQuickActionTab'])[5]"
	 * )).click(); } click_on_Make_a_Post();
	 * 
	 * String response = driver.findElement(By.
	 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
	 * .getText(); ; String causeId = response.replaceAll("[^0-9]", "").trim();
	 * log.logging("Got CauseId : " + causeId, "info"); //Thread.sleep(10000);
	 * Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
	 * "gettingMsgLogGroupPostForTransactionTuples"); String[] wNo =
	 * webarooNo.toString().split(",");
	 * 
	 * log.logging("Got Group Post WebarooNo   : " + wNo[1].trim(), "info");
	 * Assert.assertEquals(wNo[1].trim(), msgTypeMapping.get("WebarooNo")); }
	 * 
	 * }
	 * 
	 * @Then("^Check Group Name Post count will be \"([^\"]*)\" as four transaction is done from this group$"
	 * ) public void
	 * check_Group_Name_Post_count_will_be_as_four_transaction_is_done_from_this_group
	 * (String postCount) { String groupDetails =
	 * driver.findElement(By.xpath("(//table[@class='groupList']//td)[3]")).getText(
	 * ); Assert.assertEquals(groupDetails, groupName + "   " + postCount +
	 * " posts, " + phoneNocnt + " members");
	 * log.logging("Verified Group Details : " + groupDetails, "info");
	 * 
	 * }
	 */

	@Then("^click on Other Langauge Tab$")
	public void click_on_Other_Langauge_Tab() throws InterruptedException {
		otherLang = true;
		log.logging("Setting Unicode Flag : " + otherLang, "info");

		driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
		Thread.sleep(5000);
	}

	@Then("^click on Flash Tab$")
	public void click_on_Flash_Tab() throws InterruptedException {
		flash = true;
		log.logging("Setting  Flash Flag : " + flash, "info");

		driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
		Thread.sleep(5000);

	}

	@Then("^click on Unicode_Flash Tab$")
	public void click_on_Unicode_Flash_Tab() throws InterruptedException {
		unicodeFlash = true;
		log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

		driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();
		Thread.sleep(5000);

	}

	@Then("^Upload the File only Numbers$")
	public void upload_the_File_only_Numbers(DataTable data) throws InterruptedException, IOException {
		for (Map<String, String> dataMap : data.asMaps(String.class, String.class)) {
			String fileName = dataMap.get("FileName");
			String msgType = dataMap.get("MsgType");
			String wbNo = dataMap.get("WebarooNo");
			String msg = dataMap.get("Message");
			if (msgType.equalsIgnoreCase("Unicode_Text")) {
				click_on_Other_Langauge_Tab();
			} else if (msgType.equalsIgnoreCase("Flash")) {
				click_on_Flash_Tab();
			} else if (msgType.equalsIgnoreCase("Unicode_Flash")) {
				click_on_Unicode_Flash_Tab();
			} else {
				log.logging("Selecting Text Tab", "info");

				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}
			driver.findElement(By.id("defaultMsg")).clear();
			driver.findElement(By.id("defaultMsg")).sendKeys(msg);

			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;

			log.logging("Passing the file: " + fileName, "info");
			fileName = System.getProperty("user.dir") + "/BulkUploadFilesDLT/" + fileName;
			driver.findElement(By.id("xlsFile")).sendKeys(fileName);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			boolean hisTabPresent = su.elemCheck("History");
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();
			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}

			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {

				log.logging("We have history tab so validation is according to History tab", "info");

				/*
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");
				log.logging("Now Checking Preview", "info"); // commted because it is unstable
				Thread.sleep(5000);
				driver.findElement(By.xpath("//img[@title='Preview']")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				Thread.sleep(3000);
				log.logging("Now Closing the Preview POP UP!!", "info");
				driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
				// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				Thread.sleep(3000);
				log.logging("Now Actually Posting the Campaign!", "info");
				Thread.sleep(3000);

				/*
				 * log.logging("Now Checking Preview", "info");
				 * 
				 * driver.findElement(By.xpath("(//img[@alt='Preview'])[1]")).click();
				 * Thread.sleep(10000);
				 * log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp",
				 * "info"); String preview =
				 * driver.findElement(By.xpath("//div[text()='Preview']")).getText(); String
				 * pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				 * String mESSAGE =
				 * driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();
				 * 
				 * sa.assertEquals(preview.trim(), "Preview"); sa.assertEquals(pHONE.trim(),
				 * "PHONE"); sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				 * log.logging("Now Closing the Preview POP UP!!", "info");
				 * 
				 * driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				 * log.logging("Now Actually Posting the Campaign!", "info");
				 */

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				/*
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG']//td//a)[1]")).getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the campign for causeId  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2])")).getText();
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
			}
			Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			String[] wNo = webarooNo.toString().split(",");
			log.logging("Checking Webaroo No as : " + wbNo, "info");
			log.logging("Got Webaroo No " + wNo[1].trim(), "info");

			sa.assertEquals(wNo[1].trim(), wbNo);
		}
		sa.assertAll();
	}

}
