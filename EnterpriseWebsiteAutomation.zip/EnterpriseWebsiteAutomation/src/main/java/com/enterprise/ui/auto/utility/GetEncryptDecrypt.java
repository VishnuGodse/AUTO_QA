/**
 * 
 */
package com.enterprise.ui.auto.utility;

import java.io.IOException;

import com.enterprise.ui.auto.Bo.ConfigServerBO;

/**
 * @author Rahul Jain
 *
 */
public class GetEncryptDecrypt {
	/**
	 * 
	 */
	ConfigServerBO configserver;
	JmxReader prop;
	String host;
	String port;
	String username;
	String password;
	GeneralUtlities gu;

	public GetEncryptDecrypt() throws IOException {
		prop = new JmxReader();
		configserver = new ConfigServerBO();
		host = configserver.getHost();
		port = configserver.getPort();
		username = configserver.getUsername();
		password = configserver.getPass();
		gu = new GeneralUtlities();
	}

	public String getEncryptText(String text) throws Exception {
		String result;
		String encryptionPropFileName = "enterprise.encryption.properties";
		String keyAlias = String
				.valueOf(prop.getValueFromConfig(host, port, username, password, encryptionPropFileName, "key.alias"));
		String keystorePass = String.valueOf(
				prop.getValueFromConfig(host, port, username, password, encryptionPropFileName, "key.store.password"));
		String keyPass = String.valueOf(
				prop.getValueFromConfig(host, port, username, password, encryptionPropFileName, "key.password"));
		EncryptionDecryption encrypt;
		if (gu.getSysDetail("OS").contains("Windows")) {
			encrypt = new EncryptionDecryption(keyAlias, keystorePass, keyPass, "C:\\Keys\\keystore-AES256.jks");
		} else {
			encrypt = new EncryptionDecryption(keyAlias, keystorePass, keyPass, "/sms/keys/keystore-AES256.jks");
		}
		result = encrypt.encrypt(text);

		return result;
	}

}
