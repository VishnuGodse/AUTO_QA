/**
 * 
 */
package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Then;

/**
 * @author Rahul Jain
 *
 */
public class Encryption {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	ExecuteQuery query;
	String prePaidUser = null;
	String prePaidPass = null;
	Object userId;

	/**
	 * @throws IOException
	 * @throws InterruptedException 
	 * 
	 */
	public Encryption() throws IOException, InterruptedException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		query = new ExecuteQuery();
		prePaidUser = env.getEnterprisePrePaidAccUserId();
		prePaidPass = env.getEnterprisePrePaidAccPass();
		userId = query.getDBResponse(prePaidUser, "id", "getiingUserId");
	}
	@Then("^Encryption flag on for the account$")
	public void encryption_flag_on_for_the_account() throws IOException {
		log.logging("Enable Encyption for Users", "info");
		log.logging("Deleting the Attibute for Encyption ", "info");
		query.setDBResponse("DeleteEncryptionFlag", userId.toString());
		log.logging("Enable the Attibute for Encyption ", "info");
		query.setDBResponse("EnableEncyptionFlag", userId.toString());
	}
	@Then("^Disable Encyption Flag for the account$")
	public void disable_Encyption_Flag_for_the_account() throws IOException{
		log.logging("Disable Encyption for Users", "info");
		log.logging("Deleting the Attibute for Encyption ", "info");
		query.setDBResponse("DeleteEncryptionFlag", userId.toString());
		log.logging("Disabling  the Attibute for Encyption ", "info");
		query.setDBResponse("DisableEncyptionFlag", userId.toString());

	}
}
