package com.enterprise.ui.auto.utility;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.internal.TestResult;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SeleniumUtility {
	private static final TimeUnit SECONDS = null;
	public static WebDriver driver;
	// String driverPath = "resources/";
	String url;
	protected static Logger log;

	// public ExtentReports extent;
	// public ExtentTest extentTest;
	public SeleniumUtility() {
		String log4jConfPath = System.getProperty("user.dir") + "/resources/log4j.properties";
		PropertyConfigurator.configure(log4jConfPath);
		log = Logger.getLogger(this.getClass());
	}

	public WebDriver getDriver() {
		return driver;

	}

	public void initDriver(String Browser) throws MalformedURLException {
		if (Browser.equalsIgnoreCase("Chrome")) {
			log.info("Loading Chrome Browser");

			File file = new File(System.getProperty("user.dir") + "/resources/Buster.crx"); // zip files are also
																							// accepted
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addExtensions(file);
			driver = new ChromeDriver(options);

			//driver = new ChromeDriver();
			System.setProperty("ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY", "true");
		} else if (Browser.equalsIgnoreCase("Firefox")) {
			log.info("Loading Firefox Browser");
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else if (Browser.equalsIgnoreCase("Opera")) {
			log.info("Loading Opera Browser");
			WebDriverManager.operadriver().setup();
			driver = new OperaDriver();
		} else if (Browser.equalsIgnoreCase("Edge")) {
			log.info("Loading Edge Browser");
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();

		} else if (Browser.equalsIgnoreCase("remote-chrome")) {
			log.info("Loading Remote Chrome Browser");
			try {
				DesiredCapabilities capsChrome = new DesiredCapabilities();
				capsChrome.setBrowserName("chrome");
				capsChrome.setPlatform(Platform.LINUX);
				ChromeOptions options = new ChromeOptions();
				options.merge(capsChrome);
				String urlhub = "http://172.30.1.41:4444/wd/hub";
				driver = new RemoteWebDriver(new URL(urlhub), options);
			} catch (Exception e) {
				log.info("Unable to load the Browser " + e);
				System.exit(1);
			}

		} else if (Browser.equalsIgnoreCase("remote-firfox")) {
			log.info("Loading Remote Firefox Browser");
			try {
				DesiredCapabilities capsFirefox = new DesiredCapabilities();
				capsFirefox.setBrowserName("firefox");
				capsFirefox.setPlatform(Platform.LINUX);

				String urlhub = "http://172.30.1.41:4444/wd/hub";
				driver = new RemoteWebDriver(new URL(urlhub), capsFirefox);
			} catch (Exception e) {
				log.info("Unable to load the browser " + e);
				System.exit(1);

			}
		} else if (Browser.equalsIgnoreCase("HeadLess-Chrome")) {
			log.info("We got Chrome-Headless Browser");
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--headless");
			options.addArguments("--disable-gpu");
			driver = new ChromeDriver(options);
		} else
			log.info(Browser + "Not in the list please pass browser from the list Chrome,FireFox,Opera,Edge .");
	}

	public void browserSetting() {
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//		WebDriverWait wait = new WebDriverWait(driver,60);
//		 Wait wait = new FluentWait(driver)
//				    .withTimeout(30, SECONDS)
//				    .pollingEvery(5, SECONDS)
//				    .ignoring(NoSuchElementException.class);
	}

	public boolean setUrl(String url) {
		boolean urlFound;
		try {
			driver.navigate().to(url);
			urlFound = true;
		} catch (Exception e) {
			urlFound = false;
		}

		return urlFound;

	}

	// Not Used Anywhere
	public void selectDatebyJS(WebDriver driver, WebElement element, String dateVal) {
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].setAttribute('value','" + dateVal + "');", element);
	}

	public void refreshPage() throws InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(2000);
	}

	public boolean elemCheck(String key) {
		if (driver.findElements(By.id(key)).size() != 0) {
			log.debug("Element found by Id : " + key);
			return true;
		} else if (driver.findElements(By.name(key)).size() != 0) {
			log.debug("Element found by Name : " + key);
			return true;
		} else if (!driver.findElements(By.xpath(key)).isEmpty()) {
			log.debug("Element found by Xpath : " + key);
			return true;
		} else if (driver.findElements(By.linkText(key)).size() != 0) {
			log.debug("Element found by Link Text : " + key);
			return true;
		} else
			return false;
	}
	
	public String getDropDownText(WebElement ele)
	{
		Select ddElement = new Select(ele);
		return ddElement.getFirstSelectedOption().getText().toString();
	}
	
	public void setDropDownTextByValue(WebElement ele, String value)
	{
		Select ddElement = new Select(ele);
		ddElement.selectByValue(value);
	}
	
	public int getDropDownListSize(WebElement ele)
	{
		Select ddElement = new Select(ele);
		return ddElement.getOptions().size();
	}
	
	public void acceptAlert()
	{
		try
	    {
	    	Alert alert = driver.switchTo().alert();
	    	alert.accept();
	    }
	    catch(NoAlertPresentException ex)
	    {
	    	System.out.println("Alert is not displayed");
	    }
	}
	
	public void waitForPageLoadComplete(WebDriver driver)
	{
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("return document.readyState").toString().equals("complete");
	}
	
	public List<String> allTableHeaderNames (WebDriver driver, String headerLoc)
	{
		List<WebElement> allHeadersEle = driver.findElements(By.xpath(headerLoc));
		List<String> allHeaderNames = new ArrayList<String>();
		allHeaderNames.clear();
		for(WebElement header : allHeadersEle)
		{
			String headerName = header.getText().trim();
			allHeaderNames.add(headerName);
		}
		
		return allHeaderNames;
	}
	
	public List<HashMap<String, String>> getTableData(WebDriver driver, String headerLoc, String rowLoc)
	{
		List<String> allHeaderNames = allTableHeaderNames(driver,headerLoc);
		
		List<HashMap<String, String>> allTableData = new ArrayList<HashMap<String, String>>();
		
		List<WebElement> allRowsEle = driver.findElements(By.xpath(rowLoc));
		
		System.out.println("Total Table Rows : " + allRowsEle.size());
		
		allTableData.clear();
			
		for(int i=1; i<=allRowsEle.size();i=i+2)
		{
			List<WebElement> allColumnsEle = null;			
			
			String specificRowLoc = rowLoc+"["+i+"]";
			
			if(driver.findElement(By.xpath(specificRowLoc)).findElements(By.tagName("td")).size()>0)
			{	
				allColumnsEle = driver.findElement(By.xpath(specificRowLoc)).findElements(By.tagName("td"));
				
				HashMap<String, String> eachRowData = new HashMap<>();
			
				for(int j=0;j<allColumnsEle.size();j++)
				{
					String cellValue = allColumnsEle.get(j).getText();				
					eachRowData.put(allHeaderNames.get(j), cellValue);
				}
			
				allTableData.add(eachRowData);
			}
			
			allColumnsEle.clear();
		}
		
		allRowsEle.clear();
		
		return allTableData;
	}

	public void driverCloser() throws IOException {
				
//		  driver.close(); 
		  driver.quit();	 	 
		 
	}
}
