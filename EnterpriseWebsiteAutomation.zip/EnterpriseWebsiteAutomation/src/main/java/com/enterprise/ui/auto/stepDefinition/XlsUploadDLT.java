package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.DLTDBbtoExcelUtility;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.MessageCheckInFileUtility;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import org.apache.commons.lang3.StringUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class XlsUploadDLT {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	XlsUpload xlsUpload;
	String TemplateID;
	String enterpriseAccId = null;
	
	static String repoPath = "resources/Locators/XlsUploadDLT.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	
	MessageCheckInFileUtility msgcheck;
	
	

	public XlsUploadDLT() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		xlsUpload = new XlsUpload();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		msgcheck=new MessageCheckInFileUtility();

		
	}
	//Test Git Commit
	
	@Then("^set default dlt template id on dlt template match failure as false$")
	public void set_default_dlt_template_id_on_dlt_template_match_failure_as_false() throws InterruptedException, IOException {
		
		enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("set default dlt template id on dlt template match failure as false", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("setDefaultDltTemplateIdOnDltTemplateMatchFailureFalse ", userId.toString());
		
		

	}
	
	@Then("^set some value in deault dlt template id on dlt template match failure$")
	public void set_some_value_in_deault_dlt_template_id_on_dlt_template_match_failure() throws InterruptedException, IOException {
		
		enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("set some value in deault dlt template id on dlt template match failure", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("setValuesDefaultDltTemplateIdOnDltTemplateMatchFailure", userId.toString());
		
		

	}
	
	
	
	
	@Then("^Set include mask in template validation true$")
	public void Set_include_mask_in_template_validation_true() throws InterruptedException, IOException {
		
		enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("Set Include mask in template validation true", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("setMaskInTemplateValidationTrue", userId.toString());
		

	}
	
	@Then("^Set include mask in template validation false$")
	public void Set_include_mask_in_template_validation_false() throws InterruptedException, IOException {
		
		enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("Set Include mask in template validation false", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("setMaskInTemplateValidationFalse", userId.toString());
		

	}
	
	@Then("^Set fail request on mask mismatch false$")
	public void Set_fail_request_on_mask_mismatch_false() throws InterruptedException, IOException {
		
		enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("Set fail request on mask mismatch false", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("setfailRequestOnMaskMismatchFalse", userId.toString());
		

	}
	
	@Then("^set template service as true$")
	public void set_template_service_as_true() throws InterruptedException, IOException {
		enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("Set Call Template Service True", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("setCallTemplateServiceTrue", userId.toString());
		Thread.sleep(2000);
		
		boolean result2 = query.setDBResponse("callTemplateServiceDLTPass", userId.toString());
//		su.refreshPage();
	}
	
	@Then("^get column values of database in excel$")
	public void get_column_values_of_database_in_excel(DataTable data) throws InterruptedException, IOException {
		
		try {
			DLTDBbtoExcelUtility db = new DLTDBbtoExcelUtility();
			db.Write_database_values_in_excel(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Then("^click on Other Langauge Tab DLT$")
	public void click_on_Other_Langauge_Tab_DLT() throws InterruptedException {
		otherLang = true;
		log.logging("Setting Unicode Flag : " + otherLang, "info");

		driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
		Thread.sleep(5000);
		
		
	}
	
	@Then("^Upload the DLT File$")
	public void upload_the_File(DataTable files) throws InterruptedException, IOException {

		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			if (otherLang == true) {

				log.logging("Selecting Unicode Tab  Tab", "info");
				driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
				Thread.sleep(5000);
				
				By b1 = PropertiesFileReader.getPropertylocator("repoPath", "DltTemplateBtn", locator);
				driver.findElement(b1).click();

				Thread.sleep(5000);
				
				By b2 = PropertiesFileReader.getPropertylocator("repoPath", "UnicodeTextTemplateID", locator);
				TemplateID = driver.findElement(b2).getText();
				System.out.println("Value Template ID - " + TemplateID );
//				log.logging("TemplateID is -","info");
				
				
				By b3 = PropertiesFileReader.getPropertylocator("repoPath", "UnicodeTextMessageTemplate", locator);
				driver.findElement(b3).click();
				Thread.sleep(5000);
				
				By b4 = PropertiesFileReader.getPropertylocator("repoPath", "OkBtn", locator);
				driver.findElement(b4).click();
				
						
				driver.findElement(By.id("defaultMsg")).clear();
				//driver.findElement(By.id("defaultMsg")).sendKeys(msg);
				
			} else if (flash == true) {
				log.logging("Setting  Flash Flag : " + flash, "info");

				driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
				Thread.sleep(5000);
			} else if (unicodeFlash == true) {
				log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

				driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

			} else {
				log.logging("Selecting Text Tab final", "info");
//				Thread.sleep(20000);
//				WebDriverWait wait = new WebDriverWait(driver, 10);
				// WebElement
				// elementTextTab=wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[id=postTypeHeaderEnglishSmsSpan]")));
				WebElement element = driver.findElement(
						By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//			JavascriptExecutor executor = (JavascriptExecutor)driver;
//			executor.executeScript("arguments[0].click();", element);
//			Thread.sleep(5000);
				Actions action = new Actions(driver);

				action.moveToElement(element).click().perform();

//				WebElement Button1 =driver.findElement(By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//				Button1.submit();
//				Thread.sleep(5000);

				log.logging("Selecting Text Tab final", "info");

				// elementTextTab.sendKeys(Keys.ENTER);
				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}

			driver.findElement(By.id("defaultMsg")).clear();
			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFilesDLT/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			boolean hisTabPresent;
			try {
				hisTabPresent = driver.findElement(By.linkText("History")).isDisplayed();
				System.out.println("hisTabPresent value is -" +String.valueOf(hisTabPresent));
			} catch (Exception e) {
				hisTabPresent = false;
			}
			Thread.sleep(5000);
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();

			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}
			log.logging("Clicked on Upload Button", "info");
			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {
				log.logging("We have history tab so validation is according to History tab", "info");

				/*
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");

				log.logging("Now Checking Preview", "info"); // commted because it is unstable
				Thread.sleep(5000);
				driver.findElement(By.xpath("//img[@title='Preview']")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
//				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
//				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				Thread.sleep(3000);
				log.logging("Now Closing the Preview POP UP!!", "info");
				driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
				// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				Thread.sleep(3000);
				log.logging("Now Actually Posting the Campaign!", "info");
				Thread.sleep(3000);

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Thread.sleep(3000);
				// driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				Thread.sleep(3000);

				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				/*
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG'][1]//td//a)[1]"))
						.getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the causeId in table  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2]//td)[1]"))
						.getText();
				System.out.println(forTheTransaction);
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
			}
			Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			
//			  boolean dltidNo = metadata.toString().contains("dltid="+TemplateID);
//			  System.out.println("DLT ID is - " + dltidNo );
//			  log.logging(String.valueOf(dltidNo), "debug");
//			  log.logging("Matching htidNo is " + TemplateID, "info");
//			  sa.assertEquals(dltidNo, true, "dltidNo Not Matched");
			 
				
				boolean peid=metadata.toString().contains("peid");
				log.logging(String.valueOf(peid), "debug");
				log.logging("Verifying whether peid has value", "info");
				sa.assertEquals(true, peid);
				
				boolean status=metadata.toString().contains("status=0");
				log.logging(String.valueOf(status), "debug");
				log.logging("Verifying whether status has value 0", "info");
				sa.assertEquals(true, status);
				
				
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			if (webarooNo.toString() == null) {
				log.logging("MsgTupple did not found in DB", "info");
				System.out.println("MsgTupple did not found in DB");
				break;
			}

			String[] wNo = webarooNo.toString().split(",");
			if (otherLang == true) {
				log.logging("Checking Webaroo No as 3 for unicode", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "3");
			} else if (flash == true) {
				log.logging("Checking Webaroo No as 5 for flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "5");
			} else if (unicodeFlash == true) {
				log.logging("Checking Webaroo No as 20 for unicode_flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "20");
			} else {
				log.logging("Checking Webaroo No as 0 for text Message", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "0");
			}
		}
		sa.assertAll();
	}

	
	
	@Then("^Upload the File only Numbers DLT$")
	public void upload_the_File_only_Numbers_DLT(DataTable data) throws InterruptedException, IOException {
		for (Map<String, String> dataMap : data.asMaps(String.class, String.class)) {
			String fileName = dataMap.get("FileName");
			String msgType = dataMap.get("MsgType");
			String wbNo = dataMap.get("WebarooNo");
			String msg = dataMap.get("Message");
			
			
			if (msgType.equalsIgnoreCase("Unicode_Text")) {
				xlsUpload.click_on_Other_Langauge_Tab();
				

				Thread.sleep(2000);
				
				By b1 = PropertiesFileReader.getPropertylocator("repoPath", "DltTemplateBtn", locator);
				driver.findElement(b1).click();

				Thread.sleep(5000);
				
				By b2 = PropertiesFileReader.getPropertylocator("repoPath", "UnicodeTextTemplateID", locator);
				TemplateID = driver.findElement(b2).getText();
				System.out.println("Value Template ID - " + TemplateID );
				
				
				By b3 = PropertiesFileReader.getPropertylocator("repoPath", "UnicodeTextMessageTemplate", locator);
				driver.findElement(b3).click();
				Thread.sleep(5000);
				
				By b4 = PropertiesFileReader.getPropertylocator("repoPath", "OkBtn", locator);
				driver.findElement(b4).click();
				
				
			} else if (msgType.equalsIgnoreCase("Flash")) {
				xlsUpload.click_on_Flash_Tab();
				
				
			} else if (msgType.equalsIgnoreCase("Unicode_Flash")) {
				xlsUpload.click_on_Unicode_Flash_Tab();
				
				
			} else {
				log.logging("Selecting Text Tab", "info");

				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
				
				Thread.sleep(2000);
				
				By b1 = PropertiesFileReader.getPropertylocator("repoPath", "DltTemplateBtn", locator);
				driver.findElement(b1).click();

				Thread.sleep(5000);
				
				By b2 = PropertiesFileReader.getPropertylocator("repoPath", "TextTemplateID", locator);
				TemplateID = driver.findElement(b2).getText();
				System.out.println("Value Template ID - " + TemplateID );
				log.logging("TemplateID is -","info");
				
				
				By b3 = PropertiesFileReader.getPropertylocator("repoPath", "TextMessageTemplate", locator);
				driver.findElement(b3).click();
				Thread.sleep(5000);
				
				By b4 = PropertiesFileReader.getPropertylocator("repoPath", "OkBtn", locator);
				driver.findElement(b4).click();
				
				
			}
			//driver.findElement(By.id("defaultMsg")).clear();
			//driver.findElement(By.id("defaultMsg")).sendKeys(msg);

			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;

			log.logging("Passing the file: " + fileName, "info");
			fileName = System.getProperty("user.dir") + "/BulkUploadFilesDLT/" + fileName;
			driver.findElement(By.id("xlsFile")).sendKeys(fileName);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			boolean hisTabPresent = su.elemCheck("History");
			System.out.println("hisTabPresent value" + String.valueOf(hisTabPresent));
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();
			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}

			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {

				log.logging("We have history tab so validation is according to History tab", "info");

				/*
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");
				log.logging("Now Checking Preview", "info"); // commted because it is unstable
				Thread.sleep(5000);
				driver.findElement(By.xpath("//img[@title='Preview']")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				Thread.sleep(3000);
				log.logging("Now Closing the Preview POP UP!!", "info");
				driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
				// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				Thread.sleep(3000);
				log.logging("Now Actually Posting the Campaign!", "info");
				Thread.sleep(3000);

				/*
				 * log.logging("Now Checking Preview", "info");
				 * 
				 * driver.findElement(By.xpath("(//img[@alt='Preview'])[1]")).click();
				 * Thread.sleep(10000);
				 * log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp",
				 * "info"); String preview =
				 * driver.findElement(By.xpath("//div[text()='Preview']")).getText(); String
				 * pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				 * String mESSAGE =
				 * driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();
				 * 
				 * sa.assertEquals(preview.trim(), "Preview"); sa.assertEquals(pHONE.trim(),
				 * "PHONE"); sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				 * log.logging("Now Closing the Preview POP UP!!", "info");
				 * 
				 * driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				 * log.logging("Now Actually Posting the Campaign!", "info");
				 */

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				/*
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG']//td//a)[1]")).getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the campign for causeId  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2])")).getText();
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
			}
			Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			
		
		//	*****************************************************************************************************
		
		  boolean dltidNo = metadata.toString().contains("dltid="+TemplateID);
		  System.out.println("DLT ID is - " + dltidNo );
		  log.logging(String.valueOf(dltidNo), "debug");
		  log.logging("Matching htidNo is " + TemplateID, "info");
		  sa.assertEquals(dltidNo, true, "dltidNo Not Matched");
		 
			
			boolean peid=metadata.toString().contains("peid");
			log.logging(String.valueOf(peid), "debug");
			log.logging("Verifying whether peid has value", "info");
			sa.assertEquals(true, peid);
			
			boolean status=metadata.toString().contains("status=0");
			log.logging(String.valueOf(status), "debug");
			log.logging("Verifying whether status has value 0", "info");
			sa.assertEquals(true, status);
		
			
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			String[] wNo = webarooNo.toString().split(",");
			log.logging("Checking Webaroo No as : " + wbNo, "info");
			log.logging("Got Webaroo No " + wNo[1].trim(), "info");

			sa.assertEquals(wNo[1].trim(), wbNo);
		}
//		sa.assertAll();
	}
	
	//*******************************************************************************************
	
	@Then("^Upload the DLT DBtoExcel File$")
	public void Upload_the_DLT_DBtoExcel_File(DataTable files) throws InterruptedException, IOException {

		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			if (otherLang == true) {

				log.logging("Selecting Unicode Tab  Tab", "info");
				driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
				Thread.sleep(5000);
			} else if (flash == true) {
				log.logging("Setting  Flash Flag : " + flash, "info");

				driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
				Thread.sleep(5000);
			} else if (unicodeFlash == true) {
				log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

				driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

			} else {
				log.logging("Selecting Text Tab final", "info");
//				Thread.sleep(20000);
//				WebDriverWait wait = new WebDriverWait(driver, 10);
				// WebElement
				// elementTextTab=wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[id=postTypeHeaderEnglishSmsSpan]")));
				WebElement element = driver.findElement(
						By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//			JavascriptExecutor executor = (JavascriptExecutor)driver;
//			executor.executeScript("arguments[0].click();", element);
//			Thread.sleep(5000);
				Actions action = new Actions(driver);

				action.moveToElement(element).click().perform();

//				WebElement Button1 =driver.findElement(By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//				Button1.submit();
//				Thread.sleep(5000);

				log.logging("Selecting Text Tab final", "info");

				// elementTextTab.sendKeys(Keys.ENTER);
				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}

			driver.findElement(By.id("defaultMsg")).clear();
			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFiles/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			
			/*
			 * //###########################################################################
			 * ######### String msg; //static String repoPath =
			 * "resources/Locators/XlsUploadDLT.properties";C:\\Users\\Sagar.Jawle\\gitrepo\
			 * \gupshup-automations\\EnterpriseWebsiteAutomation\\ String filePath
			 * ="BulkUploadFilesDLT/TestData.xlsx";
			 * 
			 * String result=msgcheck.checkFileError(filename,filePath); String start =
			 * StringUtils.substringBefore(result, "|").trim(); //String
			 * start=StringUtils.substringBeforeLast(result, "|");
			 * System.out.println("Result of zip "+start);
			 * 
			 * Object tid = query.getDBResponse(start, "dltTemplateId", "GetDLTtemplateID");
			 * 
			 * log.logging(tid.toString(), "debug"); String tidNo = tid.toString();
			 * System.out.println("tidNO............................."+tidNo);
			 * 
			 * //###########################################################################
			 * ########
			 */			
			boolean hisTabPresent;
			try {
				hisTabPresent = driver.findElement(By.linkText("History")).isDisplayed();
			} catch (Exception e) {
				hisTabPresent = false;
			}
			Thread.sleep(5000);
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();

			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}
			log.logging("Clicked on Upload Button", "info");
			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {
				log.logging("We have history tab so validation is according to History tab", "info");

				/*
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");

				log.logging("Now Checking Preview", "info"); // commted because it is unstable
				Thread.sleep(5000);
				driver.findElement(By.xpath("//img[@title='Preview']")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				Thread.sleep(3000);
				log.logging("Now Closing the Preview POP UP!!", "info");
				driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
				// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				Thread.sleep(3000);
				log.logging("Now Actually Posting the Campaign!", "info");
				Thread.sleep(3000);

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Thread.sleep(3000);
				// driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				Thread.sleep(3000);

				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				/*
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG'][1]//td//a)[1]"))
						.getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the causeId in table  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2]//td)[1]"))
						.getText();
				System.out.println(forTheTransaction);
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
			}
			Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			
			/*
			 * if(tidNo.isEmpty()) { log.logging(String.valueOf(tidNo), "debug"); }
			 * 
			 * else { boolean dltidNo = metadata.toString().contains("dltid="+tidNo);
			 * log.logging(String.valueOf(dltidNo), "debug");
			 * log.logging("Matching htidNo is " + tidNo, "info"); sa.assertEquals(dltidNo,
			 * true, "dltidNo Not Matched"); }
			 */
			
			if (webarooNo.toString() == null) {
				log.logging("MsgTupple did not found in DB", "info");
				System.out.println("MsgTupple did not found in DB");
				break;
			}

			String[] wNo = webarooNo.toString().split(",");
			if (otherLang == true) {
				log.logging("Checking Webaroo No as 3 for unicode", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "3");
			} else if (flash == true) {
				log.logging("Checking Webaroo No as 5 for flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "5");
			} else if (unicodeFlash == true) {
				log.logging("Checking Webaroo No as 20 for unicode_flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "20");
			} else {
				log.logging("Checking Webaroo No as 0 for text Message", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "0");
			}
		}
		sa.assertAll();
	}
	
	@Then("^Upload the negative DLT File$")
	public void Upload_the_negative_DLT_File(DataTable files) throws InterruptedException, IOException {

		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			if (otherLang == true) {

				log.logging("Selecting Unicode Tab  Tab", "info");
				driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
				Thread.sleep(5000);
			} else if (flash == true) {
				log.logging("Setting  Flash Flag : " + flash, "info");

				driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
				Thread.sleep(5000);
			} else if (unicodeFlash == true) {
				log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

				driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

			} else {
				log.logging("Selecting Text Tab final", "info");
//				Thread.sleep(20000);
//				WebDriverWait wait = new WebDriverWait(driver, 10);
				// WebElement
				// elementTextTab=wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[id=postTypeHeaderEnglishSmsSpan]")));
				WebElement element = driver.findElement(
						By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//			JavascriptExecutor executor = (JavascriptExecutor)driver;
//			executor.executeScript("arguments[0].click();", element);
//			Thread.sleep(5000);
				Actions action = new Actions(driver);

				action.moveToElement(element).click().perform();

//				WebElement Button1 =driver.findElement(By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//				Button1.submit();
//				Thread.sleep(5000);

				log.logging("Selecting Text Tab final", "info");

				// elementTextTab.sendKeys(Keys.ENTER);
				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}

			driver.findElement(By.id("defaultMsg")).clear();
			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFiles/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			boolean hisTabPresent;
			try {
				hisTabPresent = driver.findElement(By.linkText("History")).isDisplayed();
			} catch (Exception e) {
				hisTabPresent = false;
			}
			Thread.sleep(5000);
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();

			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}
			log.logging("Clicked on Upload Button", "info");
			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {
				log.logging("We have history tab so validation is according to History tab", "info");

				/*
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");

				log.logging("Now Checking Preview", "info"); // commted because it is unstable
				Thread.sleep(5000);
				driver.findElement(By.xpath("//img[@title='Preview']")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				Thread.sleep(3000);
				log.logging("Now Closing the Preview POP UP!!", "info");
				driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
				// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				Thread.sleep(3000);
				log.logging("Now Actually Posting the Campaign!", "info");
				Thread.sleep(3000);

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Thread.sleep(3000);
				// driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				Thread.sleep(3000);

				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				/*
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 */

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG'][1]//td//a)[1]"))
						.getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the causeId in table  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2]//td)[1]"))
						.getText();
				System.out.println(forTheTransaction);
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
			}
			/*Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			if (webarooNo.toString() == null) {
				log.logging("MsgTupple did not found in DB", "info");
				System.out.println("MsgTupple did not found in DB");
				break;
			}

			String[] wNo = webarooNo.toString().split(",");
			if (otherLang == true) {
				log.logging("Checking Webaroo No as 3 for unicode", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "3");
			} else if (flash == true) {
				log.logging("Checking Webaroo No as 5 for flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "5");
			} else if (unicodeFlash == true) {
				log.logging("Checking Webaroo No as 20 for unicode_flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "20");
			} else {
				log.logging("Checking Webaroo No as 0 for text Message", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "0");
			}*/
		}
//		sa.assertAll();
	}
	
	
	@Then("^Check DB status for idt \"([^\"]*)\"$")
	public void check_DB_status_WebrooNo_and_Htid(String IDT ) throws Throwable {
		{
		
		Thread.sleep(3000);
		String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
			.getText();
		System.out.println(response);
		String causeId = response.replaceAll("[^0-9]", "").trim();
		log.logging("Got CauseId : " + causeId, "info");
		
		//Status
//		Object status = query.getDBResponse(causeId, "status", "gettingMsgLog");
//		log.logging("Got Post Status   : " + status, "info");
//		Assert.assertEquals(status.toString(), "DISPATCHED");
		
		
		Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
		
		//idt
		log.logging(metadata.toString(), "debug");
		boolean idtNo = metadata.toString().contains("idt"+IDT);
		System.out.print(idtNo);
		log.logging(String.valueOf(idtNo), "debug");
		//log.logging("Matching idt is -1", "info");
		if(idtNo == true)
		{
			sa.assertEquals(idtNo, true, "Matched");
		}
		else
		{sa.assertEquals(idtNo, false, "Not Matched");}
		
		/*
		 * // //htid boolean htidNo = metadata.toString().contains("htid="+Htid);
		 * log.logging(String.valueOf(htidNo), "debug");
		 * log.logging("Matching htidNo is " + Htid, "info"); sa.assertEquals(htidNo,
		 * true, "htidNo Not Matched");
		 * 
		 * //WebarooNo //String wbNo="19"; Object webarooNo =
		 * query.getDBResponse(causeId, "webarooNumber", "gettingMsgLog"); String[] wNo
		 * = webarooNo.toString().split(","); log.logging("Checking Webaroo No as : " +
		 * WebrooNo, "info"); log.logging("Got Webaroo No " + wNo[1].trim(), "info");
		 * 
		 * sa.assertEquals(wNo[1].trim(), WebrooNo); //sa.assertEquals(wNo[1].trim(),
		 * "0");
		 * 
		 * log.logging("Assert " + WebrooNo, "info"); sa.assertAll();
		 */
	}
	}
	

}
