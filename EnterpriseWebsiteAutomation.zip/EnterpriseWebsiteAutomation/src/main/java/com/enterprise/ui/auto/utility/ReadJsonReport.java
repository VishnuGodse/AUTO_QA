package com.enterprise.ui.auto.utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadJsonReport {

	public int getStatusCount(String file, String paramter) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(file));
		int result = 0;
		String line = null;
		int pass = 0;
		int fail = 0;
		int skip = 0;
		int passCnt = 0;
		int initclasscount = 0;
		int total = 0;
		while ((line = br.readLine()) != null) {
			if (line.contains("Inititor")) {

				initclasscount++;
			}
			if (line.contains("\"status\": \"passed\"")) {
				pass++;

			} else if (line.contains("\"status\": \"failed\"")) {
				fail++;

			} else if (line.contains("\"status\": \"skipped\"")) {
				skip++;
			}

		}
		passCnt = (pass - initclasscount);
		total = (passCnt + fail + skip);
		if (paramter.equalsIgnoreCase("Pass")) {

		//	passCnt = (pass - initclasscount);
			return result = passCnt;

		} else if (paramter.equalsIgnoreCase("Fail")) {
			return result = fail;

		} else if (paramter.equalsIgnoreCase("Skip")) {
			return result = skip;

		} else if (paramter.equalsIgnoreCase("Total")) {
			return result = total;
		}
		return result;

	}

}
