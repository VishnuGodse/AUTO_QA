/**
 * 
 */
package com.enterprise.ui.auto.utility;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanInfo;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

/**
 * @author Rahul Jain
 *
 */
public class JmxReader {

	public  Object getValueFromConfig(String host, String port, String username, String password,
			String configFileName, String propName) throws IOException, MalformedObjectNameException,
			InstanceNotFoundException, IntrospectionException, ReflectionException {
		Map<String, String[]> env = new HashMap<>();
		Object result;

		JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://"+host+ ":" + port + "/jmxrmi");
		String[] creds = { username, password };
		env.put(JMXConnector.CREDENTIALS, creds);
		JMXConnector jmxConn = JMXConnectorFactory.connect(url, env);
		MBeanServerConnection remoteMBS = jmxConn.getMBeanServerConnection();
		ObjectName mbeanName = new ObjectName("sms.config:type=properties,file=" + configFileName);
		MBeanInfo mBeanInfo = remoteMBS.getMBeanInfo(mbeanName);
		List<String> listOfAttributes = new LinkedList<String>();
		for (MBeanAttributeInfo attrInfo : mBeanInfo.getAttributes()) {
			if (attrInfo.isReadable()) {
				listOfAttributes.add(attrInfo.getName());
			}
		}
		String[] attributes = listOfAttributes.toArray(new String[0]);
		AttributeList attributeList = remoteMBS.getAttributes(mbeanName, attributes);
		Map<String, String> map = new HashMap<String, String>();
		for (int i = 0; i < attributeList.size(); ++i) {
			Attribute attribute = (Attribute) attributeList.get(i);
			/*
			 * properties.setProperty((String)attribute.getName(),
			 * parseObject(attribute.getValue()));
			 */
			map.put(attribute.getName(), attribute.getValue().toString());
		}
		if (mBeanInfo == null) {
			System.out.println("Null found");
		}
		/*
		 * SystemConfigMBean mbeanProxy = (SystemConfigMBean)
		 * MBeanServerInvocationHandler.newProxyInstance( mbeanServerConnection,
		 * mbeanName, SystemConfigMBean.class, true);
		 */
		result = map.get(propName);
		return result;
	}

	/*public static void main(String[] args) throws MalformedObjectNameException, IOException, InstanceNotFoundException,
			IntrospectionException, ReflectionException {
		System.out.println(getValueFromConfig("10.40.1.18", "9999", "configsrv", "configsrv00485", "enterprise.encryption.properties", "key.password"));
		System.out.println(getValueFromConfig("10.40.1.18", "9999", "configsrv", "configsrv00485", "enterprise.encryption.properties", "key.alias"));

	}*/
}
