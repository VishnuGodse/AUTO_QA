package com.enterprise.ui.auto.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import cucumber.api.java.sl.In;
import gherkin.lexer.Ar;

public class ExcelReaderUtility {
	public String path;
	public FileInputStream fis;
	public FileOutputStream fileOut = null;
	public File src;
	public XSSFWorkbook wb1;
	public HSSFWorkbook wb;
	public XSSFSheet sheet1;
	public HSSFSheet sheet;
	public HSSFRow row = null;
	public HSSFCell cell = null;
	public XSSFRow row1 = null;
	public XSSFCell cell1 = null;
	Map<String, String> dataMapping = new HashMap<>();
	Map<String, String> keywordMapping = new HashMap<>();

	public ExcelReaderUtility(String path) throws IOException {
		this.path = path;
		src = new File(path);

		try {
			fis = new FileInputStream(src);
			wb1 = new XSSFWorkbook(fis);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public String getCellfromsheet(String sheetName, int row, int cell) throws IOException {

		sheet1 = wb1.getSheet(sheetName);
		String result = (sheet1.getRow(row).getCell(cell).getStringCellValue());
		// wb1.close();
		return result;
	}

	public int gettotalRowSheet(String sheetName) throws IOException {

		int count = wb1.getSheet(sheetName).getLastRowNum();
		// System.out.println("No of Rows in sheet " + sheetName + " is :" + (count +
		// 1));
		return count + 1;
	}

	public void getAllDataSheet(String sheetName) throws IOException {
		int count = gettotalRowSheet(sheetName);
		for (int i = 0; i < count; i++) {
			String data = wb1.getSheet(sheetName).getRow(i).getCell(0).getStringCellValue();
			System.out.println(data);
		}
	}

	@SuppressWarnings("static-access")
	public String getCellData(String sheetName, int colNum, int rowNum) {

		try {
			// wb1 = new XSSFWorkbook(fis);
			if (rowNum < 0)

				return "1111";

			int index = wb1.getSheetIndex(sheetName);
			if (index == -1)
				return "";

			sheet1 = wb1.getSheetAt(index);
			row1 = sheet1.getRow(rowNum - 1);
			if (row1 == null)
				return "";
			cell1 = row1.getCell(colNum);
			if (cell1 == null)
				return "";

			//
			if (cell1.getCellType().name().equals("STRING"))
				return cell1.getStringCellValue();

			//
			// if (cell.getCellType().STRING != null)
			// return cell.getStringCellValue();
			/*
			 * else if ((cell1.getCellType().name().equals("NUMERIC")) ||
			 * (cell1.getCellType().name().equals("FORMULA"))) {
			 * 
			 * String cellText = String.valueOf(cell1.getNumericCellValue()); if
			 * (HSSFDateUtil.isCellDateFormatted(cell1)) { // format in form of M/D/YY
			 * double d = cell.getNumericCellValue();
			 * 
			 * Calendar cal = Calendar.getInstance();
			 * cal.setTime(HSSFDateUtil.getJavaDate(d)); cellText =
			 * (String.valueOf(cal.get(Calendar.YEAR))).substring(2); cellText =
			 * cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" +
			 * cellText;
			 * 
			 * // System.out.println(cellText);
			 * 
			 * }
			 * 
			 * return cellText; }
			 */
			else if (cell1.getCellType().BLANK != null)
				return "";
			else
				return String.valueOf(cell1.getBooleanCellValue());
		} catch (Exception e) {

			e.printStackTrace();
			return "row " + rowNum + " or column " + colNum + " does not exist  in xls";
		}
	}

	
	public String getCellDataWithHeaderwithSheetIndex (int sheetIndex, String headerName, int rowNum) throws IOException {
		if (rowNum <= 0) {
			return "";
		}
		int colNum = -1;
		int index = sheetIndex;
		//if (!isSheetExist(sheetName))
		//	return sheetName + "does not exsits";
		sheet1 = wb1.getSheetAt(index);
		row1 = sheet1.getRow(0);
		for (int i = 0; i < row1.getLastCellNum(); i++) {
			// System.out.println(row1.getLastCellNum());
			// System.out.println(row1.getCell(i).getStringCellValue().trim());
			if (row1.getCell(i).getStringCellValue().trim().equalsIgnoreCase(headerName)) {
				colNum = i;
			}
		}
		if (colNum == -1) {
			return "Header Not Found";
		}
		sheet1 = wb1.getSheetAt(index);
		row1 = sheet1.getRow(rowNum - 1);
		if (row1 == null)
			return "";
		cell1 = row1.getCell(colNum);
		if (cell1 == null)
			return "";
		if (cell1.getCellType().name().equals("STRING"))
			return cell1.getStringCellValue();
		else if (cell1.getCellType().BLANK != null)
			return "";
		else
			return String.valueOf(cell1.getBooleanCellValue());
	}
	@SuppressWarnings("unlikely-arg-type")
	public boolean setCellData(String sheetName, int colNum, int rowNum, String text) {
		try {
			if (rowNum <= 0) {
				return false;
			}
			int index = wb1.getSheetIndex(sheetName);
			int colName = -1;
			if (index == -1)
				return false;
			sheet1 = wb1.getSheetAt(index);
			row1 = sheet1.getRow(0);
			for (int i = 0; i < row1.getLastCellNum(); i++) {
				System.out.println(row1.getLastCellNum());
				// System.out.println(row.getCell(i).getStringCellValue().trim());
				if (row1.getCell(i).getStringCellValue().trim().equals(colName))
					colNum = i;
			}
			if (colNum == -1)
				return false;

			sheet1.autoSizeColumn(colNum);
			row1 = sheet1.getRow(rowNum - 1);
			if (row1 == null)
				row1 = sheet1.createRow(rowNum - 1);

			cell1 = row1.getCell(colNum);
			if (cell1 == null)
				cell1 = row1.createCell(colNum);
			cell1.setCellValue(text);

			fileOut = new FileOutputStream(path);

			wb1.write(fileOut);

			fileOut.close();

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean isSheetExist(String sheetName) throws IOException {

		int index = wb1.getSheetIndex(sheetName);
		if (index == -1) {
			index = wb1.getSheetIndex(sheetName);
			if (index == -1)
				return false;
			else
				return true;
		} else
			return true;
	}

	public int getColumnCount(String sheetName) throws IOException {
		// check if sheet exists
		if (!isSheetExist(sheetName))
			return -1;

		sheet1 = wb1.getSheet(sheetName);
		row1 = sheet1.getRow(0);

		if (row1 == null)
			return -1;

		return row1.getLastCellNum();

	}

	public String getValueKeyword(String keyword, String sheetName) throws IOException {
		String result = "";

		if (!isSheetExist(sheetName))
			return sheetName + "does not exsits";

		int index = wb1.getSheetIndex(sheetName);
		int count = (wb1.getSheetAt(index).getLastRowNum() + 1);
		for (int i = 1; i <= count; i++) {
			String getKeyword = getCellData(wb1.getSheetName(index), 0, i);
			if (getKeyword.equalsIgnoreCase(keyword)) {
				// System.out.println(getCellfromsheet(wb1.getSheetName(index), i - 1, 1));
				result = getCellfromsheet(wb1.getSheetName(index), i - 1, 1);

			}
		}
		return result;
	}

	@SuppressWarnings("static-access")
	public String getCellDataWithHeader(String sheetName, String headerName, int rowNum) throws IOException {
		if (rowNum <= 0) {
			return "";

		}
		int colNum = -1;
		int index = wb1.getSheetIndex(sheetName);
		if (!isSheetExist(sheetName))
			return sheetName + "does not exsits";
		sheet1 = wb1.getSheetAt(index);
		row1 = sheet1.getRow(0);
		for (int i = 0; i < row1.getLastCellNum(); i++) {
			// System.out.println(row1.getLastCellNum());
			// System.out.println(row1.getCell(i).getStringCellValue().trim());

			if (row1.getCell(i).getStringCellValue().trim().equalsIgnoreCase(headerName)) {
				colNum = i;
			}
		}
		if (colNum == -1) {
			return "Header Not Found";

		}
		sheet1 = wb1.getSheetAt(index);
		row1 = sheet1.getRow(rowNum - 1);
		if (row1 == null)
			return "";
		cell1 = row1.getCell(colNum);

		if (cell1 == null)
			return "";
		if (cell1.getCellType().name().equals("STRING"))
			return cell1.getStringCellValue();

		else if (cell1.getCellType().BLANK != null)
			return "";
		else
			return String.valueOf(cell1.getBooleanCellValue());

	}
	/*public String getCellDataWithHeaderwithSheetIndex (int sheetIndex, String headerName, int rowNum) throws IOException {
		if (rowNum <= 0) {
			return "";

		}
		int colNum = -1;
		int index = sheetIndex;
		//if (!isSheetExist(sheetName))
		//	return sheetName + "does not exsits";
		sheet1 = wb1.getSheetAt(index);
		row1 = sheet1.getRow(0);
		for (int i = 0; i < row1.getLastCellNum(); i++) {
			// System.out.println(row1.getLastCellNum());
			// System.out.println(row1.getCell(i).getStringCellValue().trim());

			if (row1.getCell(i).getStringCellValue().trim().equalsIgnoreCase(headerName)) {
				colNum = i;
			}
		}
		if (colNum == -1) {
			return "Header Not Found";

		}
		sheet1 = wb1.getSheetAt(index);
		row1 = sheet1.getRow(rowNum - 1);
		if (row1 == null)
			return "";
		cell1 = row1.getCell(colNum);

		if (cell1 == null)
			return "";
		if (cell1.getCellType().name().equals("STRING"))
			return cell1.getStringCellValue();

		else if (cell1.getCellType().BLANK != null)
			return "";
		else
			return String.valueOf(cell1.getBooleanCellValue());

	}*/
	public ArrayList<String> getAllHeader(String sheetName, int colNum) throws IOException {
		int col = getColumnCount(sheetName);
		int rowCount = gettotalRowSheet(sheetName);
		ArrayList<String> result = new ArrayList<String>();
		if (col >= colNum) {
			for (int i = colNum; i <= colNum; i++) {
				String header = getCellData(sheetName, i, 1);
				for (int j = 1; j <= rowCount; j++) {
					result.add(getCellDataWithHeader(sheetName, header, j));
				}
			}
		} else
			System.out.println(colNum + "Column Not valid");
		return result;
	}

	public Map<String, String> mappedData(String sheetName, int colNum) throws IOException {
		ArrayList<String> field = getAllHeader(sheetName, 0);
		ArrayList<String> data = getAllHeader(sheetName, colNum);
		int size = field.size();
		for (int i = 0; i < size; i++) {
			dataMapping.put(field.get(i), data.get(i));
		}
		return dataMapping;
	}

	public Map<String, String> getKeywordMapping(String sheetName) throws IOException {
		ArrayList<String> fieldName = getAllHeader(sheetName, 0);
		ArrayList<String> keyId = getAllHeader(sheetName, 1);
		int size = fieldName.size();

		for (int i = 0; i < size; i++) {
			keywordMapping.put(keyId.get(i), fieldName.get(i));

		}
		return keywordMapping;

	}

	public String getKeyElementName(String key, String sheetName) throws IOException {
		String result = null;
		getKeywordMapping(sheetName);
		result = keywordMapping.get(key);

		return result;
	}

	public String getTestDataForElement(String elementName, String sheetName, int colNum) throws IOException {
		String result = null;
		int colcnt = getColumnCount(sheetName);
		if (colNum > colcnt) {
			result = "Column No " + colNum + "does not exist";
		} else
			mappedData(sheetName, colNum);
		result = dataMapping.get(elementName);
		return result;

	}

	public ArrayList<String> getAllrowwithSpecficHeader(String sheetName, String headerName) throws IOException {
		ArrayList<String> data = new ArrayList<String>();
		for (int i = 2; i <= gettotalRowSheet(sheetName); i++) {
			data.add(String.valueOf(getCellDataWithHeader(sheetName, headerName, i)));
		}
		return data;

	}

	public int sumandavgOfallElementfromSpecficHeader(String sheetName, String headerName, String oprPerform)
			throws IOException {
		int result = 0;
		int add = 0;
		ArrayList<String> data = getAllrowwithSpecficHeader(sheetName, headerName);
		for (int i = 0; i < data.size(); i++) {
			add += Integer.valueOf(data.get(i));

		}
			if (oprPerform.equalsIgnoreCase("Average")) {
				double avg = (add / gettotalRowSheet(sheetName));
				result = (int) avg;
			} else if (oprPerform.equalsIgnoreCase("Addition")) {
				result = add;
			}

		return result;

	}
	
	public  String calculateAverageOfTime(String sheetName, String headerName) throws IOException, ParseException 
	{
		ArrayList<String>alltime =  new ArrayList<>();
		alltime=getAllrowwithSpecficHeader(sheetName, headerName);
		
		long seconds = 0;
	    for (int i = 0; i < alltime.size(); i++)
	    {
	        String[] hhmmss = alltime.get(i).split(":");            
	        seconds += Integer.valueOf(hhmmss[0]) * 60 * 60;
	        seconds += Integer.valueOf(hhmmss[1]) * 60;
	        seconds += Integer.valueOf(hhmmss[2]);
	    }
	    seconds /= alltime.size();

	    long hh = seconds / 60 / 60;
	    long mm = (seconds / 60) % 60;
	    long ss = seconds % 60;
	    String hms = String.format("%02d:%02d:%02d", hh,mm,ss);       
	    
	    long sum = 0L;

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        for (int i = 0; i < alltime.size(); i++)
            {
                sum += sdf.parse(alltime.get(i)).getTime(); 
            }
        Date avgDate = new Date((sum/alltime.size()));
        System.out.println("avg Date is:"+sdf.format(avgDate));
        return hms;
	}

	/*public static void main(String[] args) throws IOException {
	ExcelReaderUtility er = new ExcelReaderUtility("/home/rahul/bulk_upload_files/live_testing/aryacase.xls");
//System.out.println(er.getCellData("Quries", 0, 2));
	// String elementName =er.getKeyElementName("defaultMsg", "KeywordMapping");
	// System.out.println(er.getTestDataForElement(elementName, "TestData",2));

	 }*/

}
