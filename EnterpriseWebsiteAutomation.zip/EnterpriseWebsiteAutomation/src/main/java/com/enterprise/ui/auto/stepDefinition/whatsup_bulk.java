package com.enterprise.ui.auto.stepDefinition;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class whatsup_bulk {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	ExecuteQuery query;
	//String enterpriseAccId;
	SoftAssert sa;
	String whatUpUser = null;
	String whatUpPass = null;
	
	static String repoPath = "resources/Locators/Whatsup.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	
	public whatsup_bulk() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		query = new ExecuteQuery();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		sa=new SoftAssert();
		whatUpUser = env.getEnterpriseWhatsAppAccUserId();
		whatUpPass = env.getEnterpriseWhatsAppAccPass();
		

	}
	
	
	
	
	
	
	
	@Then("^Enter value in Latitude \"([^\"]*)\" and Longitude \"([^\"]*)\"$")
	public void Enter_value_in_Latitude_Longitude(String latitude,String longitude) throws InterruptedException
	{
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Latitude", locator);
		driver.findElement(b1).sendKeys(latitude);
		By b2 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Longitude", locator);
		driver.findElement(b2).sendKeys(longitude);
		log.logging("Entered Latitude,Longitude", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");
		
	}
	@Then("^Enter value in Name \"([^\"]*)\" and Address \"([^\"]*)\"$")
	public void Enter_value_in_Name_and_Address(String Name,String Address) throws InterruptedException
	{
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Name", locator);
		driver.findElement(b1).sendKeys(Name);
		By b2 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Address", locator);
		driver.findElement(b2).sendKeys(Address);
		log.logging("Entered Latitude,Longitude", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");
		
	}
	@Then("^Check the Sub Tab of WhatsApp Location$")
	public void Check_the_Sub_Tab_of_WhatsApp_Location() throws InterruptedException
	{   Thread.sleep(1000);
		log.logging("Verifying  Sub Tab of WhatsApp Tab Location", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Location", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");	

	}
	
	/*@Then("^Check the Sub Tab of WhatsApp Tab Bulk$")
	public void Check_the_Sub_Tab_of_WhatsApp_Tab_Bulk() throws InterruptedException
	{   Thread.sleep(1000);
		log.logging("Verifying  Sub Tab of WhatsApp Bulk", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Bulk", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");	

	}*/
	
	@Then("^User clicks on btn upload and post location$")
	public void User_clicks_on_btn_upload_and_post_location() throws InterruptedException
	{
		
		
		Thread.sleep(2000);
		log.logging("Click on upload and Post button", "info");
		 WebElement postbtn=driver.findElement(By.xpath("//input[@id='uploadDocButton']"));
		 //WebElement postbtn2=driver.findElement(By.xpath("//input[@value=' Upload and Post Button Messages']"));
		 
		 String btn1 = postbtn.getText();
		// String btn2 = postbtn2.getText();
		 if(btn1.equalsIgnoreCase("Upload And Post"))
		 {
			 postbtn.click();
		 }
		 else if(btn1.equalsIgnoreCase(" Upload and Post Button Messages")) 
		 {
			 postbtn.click();
		 }
		 System.out.println("Upload and post element found");
		 postbtn.click();
		 System.out.println("Upload and post element click");
		WebElement notify = driver.findElement(By.id("notification"));
		 Assert.assertEquals(true, notify.isDisplayed());
		
	}	
	@Then("^User clicks on choose file and uploads Location$")
	public void User_clicks_on_choose_file_and_uploads_Location(DataTable files) throws InterruptedException
	{
		
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
			
		     log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFiles/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			
//			WebElement duplicatechckbox= driver.findElement(By.xpath("//input[@id='quickPostCheckDuplicatesCheckbox']"));
//			duplicatechckbox.click();
//			log.logging("uncheck duplicates checkbox", "info");
		}
		
	}
	
	@Then("^User clicks on choose file and uploads for all header file$")
	public void User_clicks_on_choose_file_and_uploads_for_all_header_file(DataTable files) throws Throwable
	{
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			Check_the_Sub_Tab_of_WhatsApp_Location();
			
		     log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");
			String WebrooNo = fileUpload.get("WebrooNo");
			String Htid = fileUpload.get("Htid");
			String IDT = fileUpload.get("IDT");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFiles/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			User_clicks_on_btn_upload_and_post_location();
			check_DB_status_WebrooNo_and_Htid(WebrooNo,Htid,IDT);
			
//			WebElement duplicatechckbox= driver.findElement(By.xpath("//input[@id='quickPostCheckDuplicatesCheckbox']"));
//			duplicatechckbox.click();
//			log.logging("uncheck duplicates checkbox", "info");
		}
	}
		
	
	@Then("^User Select Template Location \"([^\"]*)\"$")
	public void user_Select_Template_Location(String Element) throws Throwable {

		By b1=PropertiesFileReader.getPropertylocator("repoPath",Element, locator);
		Thread.sleep(1000);
    log.logging("Switch to alert pop-up", "info");
	By b2=PropertiesFileReader.getPropertylocator("repoPath","WhatsApp-Click-on-Template", locator);
	Thread.sleep(1000);
	driver.findElement(b2).click();
	driver.findElement(b1).click();
    log.logging("Select a Template", "info");
    driver.findElement(By.xpath("//input[@value='OK']")).click();
    //driver.findElement(By.xpath("(//input[@id='submitFormButton'])[1]")).click();
    log.logging("click on ok button", "info");
		
		
		
//		//driver.findElement(By.xpath("//input[@name='buttonUrlParam']")).sendKeys("https://abc.com");
//		try {
//		if(driver.findElement(By.xpath("//input[@name='buttonUrlParam']")).isDisplayed()) 
//		{
//			//WebElement dynamic_url = driver.findElement(By.xpath("//input[@name='buttonUrlParam']"));
//			driver.findElement(By.xpath("//input[@name='buttonUrlParam']")).sendKeys("https://abc.com");
//			//Assert.assertEquals(true, dynamic_url.isDisplayed());
//			log.logging("Dynamic URL Found", "info");
////			WebElement e1 = driver.findElement(By.xpath("//input[@class='tbButton'][@name='button'][@value='OK']"));
////			e1.click();
//		}
//		
//		}catch(Exception e){}
//	
//		finally {
//			WebElement e1 = driver.findElement(By.xpath("//input[@class='tbButton'][@name='button'][@value='OK']"));
//			e1.click();
//	
//			log.logging("click on ok button", "info");
//			}
//		
//		Thread.sleep(5000);
	}
		
		@Then("^Check DB status WebrooNo \"([^\"]*)\" and Htid \"([^\"]*)\" and idt \"([^\"]*)\"$")
		public void check_DB_status_WebrooNo_and_Htid(String WebrooNo, String Htid ,String IDT ) throws Throwable {
			{
				
				try {

					{
					
					Thread.sleep(3000);
					String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
					System.out.println(response);
					String causeId = response.replaceAll("[^0-9]", "").trim();
					log.logging("Got CauseId : " + causeId, "info");
					
					//Status
					Object status = query.getDBResponse(causeId, "status", "gettingMsgLog");
					log.logging("Got Post Status   : " + status, "info");
//					Assert.assertEquals(status.toString(), "DISPATCHED");
					
					
					Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
					
					//idt
					log.logging(metadata.toString(), "debug");
					boolean idtNo = metadata.toString().contains("idt"+IDT);
					System.out.print(idtNo);
					log.logging(String.valueOf(idtNo), "debug");
					//log.logging("Matching idt is 1", "info");
					if(idtNo == true)
					{
						sa.assertEquals(idtNo, true, "Matched");
					}
					else
					{sa.assertEquals(idtNo, false, "Not Matched");}
					
//					//htid
					boolean htidNo = metadata.toString().contains("htid="+Htid);
					log.logging(String.valueOf(htidNo), "debug");
					log.logging("Matching htidNo is " + Htid, "info");
					sa.assertEquals(htidNo, true, "htidNo Not Matched");
					
					//WebarooNo
					//String wbNo="19";
					Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
							"gettingMsgLog");
					String[] wNo = webarooNo.toString().split(",");
					log.logging("Checking Webaroo No as : " + WebrooNo, "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), WebrooNo);
					//sa.assertEquals(wNo[1].trim(), "0");
				
					log.logging("Assert " + WebrooNo, "info");
//					sa.assertAll();
				}

					
				
			
					
				} catch (Exception e) {
					// TODO: handle exception
				}
			
			}

			
		
	}	
	

	

}
