package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.apache.commons.lang.StringUtils;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class dlt {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	SoftAssert sa;
	boolean bool;

	static String repoPath = "resources/Locators/Dlt.properties";
	public static Map<String, By> locator = new HashMap<String, By>();

	public dlt() throws IOException {
		System.out.println("Present Project Directory : " + System.getProperty("user.dir"));
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
	}

	@Then("^Check the DLT Template tab$")
	public void Check_the_DLT_Template_tab() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "DltTab", locator);
		driver.findElement(b1).click();
		log.logging("Verifying DLT Template tab  Title", "info");

		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Click the Submit button$")
	public void Click_the_Submit_button() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "SubmitButton", locator);
		driver.findElement(b1).click();
		log.logging("Verifying submit button", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Check the Single template radio button$")
	public void Check_the_Single_template_radio_button() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "SingleTemplateRadioButton", locator);
		driver.findElement(b1).click();
		log.logging("Verifying DLT Template tab  Title", "info");

		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Check the Template Name Text Box$")
	public void Check_the_Template_Name_Text_Box() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TemplateNameTextBox", locator);
		driver.findElement(b1).sendKeys(GeneralUtlities.genRandomName(5));
		log.logging("Verifying DLT Template tab  Title", "info");

		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Check the Template Id Text Box$")
	public void Check_the_Template_Id_Text_box() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TemplateId", locator);
		driver.findElement(b1).sendKeys(GeneralUtlities.genRandomNumber("5"));
		log.logging("Verifying DLT Template tab  Title", "info");

		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Select the Transactional radio button as yes$")
	public void Select_the_Transactional_radio_button_yes_option() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TransactionalYesRadioButton", locator);
		driver.findElement(b1).click();
		log.logging("Verifying Transactional radio button", "info");
		sa.assertEquals(bool, true);
	}

	@Then("Check the Transactional radio button as no$")
	public void Check_the_Transactional_radio_button_no_option() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TransactionalNoRadioButton", locator);
		driver.findElement(b1).click();
		log.logging("Verifying Transactional radio button", "info");
		sa.assertEquals(bool, true);
	}

	@Then("Check the DLT Message Type$")
	public void Check_the_DLT_Message_Type(List<String> data) {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "DltMsgType", locator);
		WebElement element = driver.findElement(b1);
		bool = dropdown_values_verfication(element, data);
		log.logging("Verifying DLT Message Type", "info");
		sa.assertEquals(bool, true);
	}

	@Then("Check the Message Type$")
	public void Check_the_Message_Type(List<String> data) {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "MsgType", locator);
		WebElement element = driver.findElement(b1);
		bool = dropdown_values_verfication(element, data);
		data.stream().forEach(e -> System.out.println(e));
		log.logging("Verifying Message Type", "info");
		sa.assertEquals(bool, true);
	}

	

	@Then("Check the Business Category$")
	public void Check_the_Business_Category(List<String> data) {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "CategoryId", locator);
		WebElement element = driver.findElement(b1);
		data.stream().forEach(e -> System.out.println(e));
//		Boolean CategoryId = driver.findElement(By.xpath("//*[@id=\"transCatDiv\"]/span")).isDisplayed();
		log.logging("Verifying Business Category", "info");
		sa.assertEquals(bool, true);
	}

	@Then("Check the Mask$")
	public void Check_the_Mask() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "Mask", locator);
		WebElement element = driver.findElement(b1);
		element.sendKeys(GeneralUtlities.genRandomName(5));
		log.logging("entering Mask value", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}
	@Then("Enter Promotional Mask$")
	public void Enter_Promotional_Mask() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "Mask", locator);
		WebElement element = driver.findElement(b1);
		element.sendKeys(GeneralUtlities.genRandomName(6));
		log.logging("entering Mask value", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Check the Template Content$")
	public void Check_the_Template_Content() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TempContent", locator);
		WebElement element = driver.findElement(b1);
		log.logging("Verifying Template Content", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Enter the Template Content$")
	public void Enter_the_Template_Content() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TempContent", locator);
		driver.findElement(b1).sendKeys(GeneralUtlities.genRandomName(20));
		log.logging("Entering Template Content", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
	}

	@Then("Verify template created successfully Trans$")
	public void Verify_template_created_successfully_Trans() {
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TemplateCreationNotificationTransactional", locator);
		WebElement element = driver.findElement(b1);
		log.logging("Verified that the template created successfully", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");

	}
	@Then("Verify template created successfully$")
	public void Verify_template_created_successfully() {
		try {
			By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TemplateCreationNotificationPromotional", locator);
			WebElement element = driver.findElement(b1);
			log.logging("Verified that the template created successfully", "info");
			Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");

		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
	
	//public void driver

	@Then("Fill all mandatory fields$")
	public void Fill_all_mandatory_fields(DataTable data) throws InterruptedException, IOException {
		for (Map<String, String> dataMap : data.asMaps(String.class, String.class)) {
			LoginPage loginpg=new LoginPage();
			String DLTMsgTypeValue = dataMap.get("DLTMsgTypeValue");
			String MsgTypeValue = dataMap.get("MsgTypeValue");
//			String BusinessCategoryValue = dataMap.get("BusinessCategoryValue");
			dropdown_values_selection("DltMsgType", DLTMsgTypeValue);
			dropdown_values_selection("MsgType", MsgTypeValue);
//			dropdown_values_selection("CategoryId", BusinessCategoryValue);
//			System.out.println(DLTMsgTypeValue+"----"+MsgTypeValue+"----"+BusinessCategoryValue);
			Check_the_Single_template_radio_button();
			Check_the_Template_Name_Text_Box();
			Check_the_Template_Id_Text_box();
			Select_the_Transactional_radio_button_yes_option();
			if(DLTMsgTypeValue.equals("TRANSACTIONAL"))
			{
			Check_the_Mask();
			}
			else if (DLTMsgTypeValue.equals("PROMOTIONAL"))
			{
				By b1 = PropertiesFileReader.getPropertylocator("repoPath", "Mask", locator);
				WebElement element = driver.findElement(b1);
//				element.sendKeys(BusinessCategoryValue+Math.round(Math.random()*10000));
				log.logging("entering Mask value", "info");
				Assert.assertEquals(driver.getTitle(), "Gupshup - DLT Template");
			}
			else {
				System.out.println("not going in loop");
			}
			Enter_the_Template_Content();
			Click_the_Submit_button();
			
			
			Verify_template_created_successfully();
			
			}

	}

	public void dropdown_values_selection(String elementname, String value) throws InterruptedException, IOException {

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", elementname, locator);
		Select se = new Select(driver.findElement(b1));
		se.selectByValue(value);

	}

	public static boolean dropdown_values_verfication(WebElement element, List<String> data) {
		Select select = new Select(element);
		List<WebElement> allOptions = select.getOptions();
		java.util.Iterator<WebElement> program = allOptions.iterator();
		boolean bool1 = false;
		while (program.hasNext()) {
			String values = program.next().getText();
			data.stream().forEach(e -> System.out.println(e));
			System.out.println(values);
			if (data.contains(values)) {
				bool1 = true;
			} else {
				bool1 = false;
				break;
			}

		}
		return bool1;
	}
}
