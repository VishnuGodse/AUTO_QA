package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Then;

public class TabVerificationSteps {

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	ExecuteQuery query;
	String enterpriseAccId;
	static String repoPath = "resources/Locators/Whatsup.properties";
	public static Map<String, By> locator = new HashMap<String, By>();

	public TabVerificationSteps() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		query = new ExecuteQuery();
		enterpriseAccId = env.getEnterpriseAccountId();
		// locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);

	}

	@Then("^Check the Voice Tab if present$")
	public void Check_the_Voice_Tab_if_present() throws InterruptedException {
		// driver.implicitly_wait(5);
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//span[text()='Voice'])[1]")).click();
		log.logging("Verifying Voice Tab Page  Title", "info");

		Assert.assertEquals(driver.getTitle(), "SMS GupShup Enterprise - Voice");

	}
	
	
	@Then("^Disable whatsapp tab in application$")
	public void disable_whatsapp_tab_in_application() throws Throwable {
		// enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("Disabling the WhatsApp tab", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("disableWhatsAppTab", userId.toString());
		su.refreshPage();
	}
	
	@Then("^Check the SMS Tab$")
	public void check_the_SMS_Tab() throws InterruptedException {
		// driver.implicitly_wait(5);
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//span[text()='SMS'])[1]")).click();
		log.logging("Verifying SMS Tab Page  Title", "info");

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");

	}

	@Then("^Check the Sub Tab of SMS Tab Simple$")
	public void check_the_Sub_Tab_of_SMS_Tab_Simple() {
		log.logging("Verifying SMS Tab Page Simple Tab  Title", "info");

//		driver.findElement(By.xpath("//*[@id=\"middle-col\"]/div[2]/div/a[1]")).click();
		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");

	}

	@Then("^Check the Sub Tab of SMS Tab Group$")
	public void check_the_Sub_Tab_of_SMS_Tab_Group() throws InterruptedException {
		log.logging("Verifying SMS Tab Page Group Tab  Title", "info");
		Thread.sleep(2000);
		driver.findElement(By.linkText("Group")).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Group Messaging");

	}

	@Then("^Check the Sub Tab of SMS Tab Bulk$")
	public void check_the_Sub_Tab_of_SMS_Tab_Bulk() throws Exception {
		log.logging("Verifying SMS Tab Page Bulk Tab  Title", "info");
		Thread.sleep(3000);
		driver.findElement(By.linkText("Bulk")).click();
		Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");
	}

	@Then("^Check the Sub Tab of SMS Tab History if present$")
	public void check_the_Sub_Tab_of_SMS_Tab_History_if_present() {
		if (su.elemCheck("History") == false) {
			log.logging("History tab Not Present", "info");

		} else {
			log.logging("Verifying History Tab Page Title", "info");

			driver.findElement(By.linkText("History")).click();

			Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");

		}
	}

	@Then("^Check the sub tab of History Requested$")
	public void check_the_sub_tab_of_History_Requested() {
		if (su.elemCheck("History") == false) {
			log.logging("History tab Not Present", "info");
		} else {
			log.logging("Verifying History Tab Page-Request Sub  Title", "info");

			driver.findElement(By.linkText("History")).click();

			driver.findElement(By.id("tabName_requested")).click();
			Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");

		}
	}

	@Then("^Check the sub tab of Sent/Scheduled$")
	public void check_the_sub_tab_of_Sent_Scheduled() {
		if (su.elemCheck("History") == false) {
			log.logging("History tab Not Present", "info");
		} else {
			driver.findElement(By.linkText("History")).click();

			driver.findElement(By.id("tabName_sent")).click();
			log.logging("Verifying History Tab Page-Sent Sub  Title", "info");

			Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");
		}
	}

	@Then("^Check the Mask Tab if present$")
	public void check_the_Mask_Tab_if_present() {
		if (su.elemCheck("Masks") == false) {
			log.logging("Mask tab Not Present", "info");
		} else {
			driver.findElement(By.xpath("//span[text()='Masks']")).click();
			log.logging("Verifying Mask Tab Page Title", "info");

			Assert.assertEquals(driver.getTitle(), "Gupshup - Masks");

		}
	}

	@Then("^Check the Sales Tab if Present$")
	public void check_the_Sales_Tab_if_Present() {
		if (su.elemCheck("Sales") == false) {
			log.logging("Sales tab Not Present", "info");
		} else {
			driver.findElement(By.linkText("Sales")).click();
			log.logging("Verifying Sales Tab Page Title", "info");

			Assert.assertEquals(driver.getTitle(), "Gupshup - Sales");

		}

	}

	@Then("^Check the Analytics Page if present$")
	public void check_the_Analytics_Page_if_present() throws InterruptedException {
		if (su.elemCheck("Analytics") == false) {
			log.logging("Analytics tab Not Present", "info");
		} else {
			driver.findElement(By.xpath("//span[text()='Analytics']")).click();
			log.logging("Verifying Analytics  Tab Page Title", "info");
			Thread.sleep(5000);

			Assert.assertEquals(driver.getTitle(), "Gupshup - Analytics Dashboard");

		}

	}

	@Then("^check the setting page$")
	public void check_the_setting_page() throws InterruptedException {
		driver.findElement(By.xpath("//img[@alt='Settings']")).click();
		log.logging("Verifying Setting Tab Page Title", "info");

		Thread.sleep(5000);

		Assert.assertEquals(driver.getTitle(), "Gupshup - Settings");

	}

	@Then("^Enable the Analytics Tab$")
	public void enable_the_Analytics_Tab() throws IOException, InterruptedException {
		log.logging("Enable the Analytics tab", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("enableAnalyticsTab", userId.toString());
	}

	@Then("^Enable the MasksCreation Tab$")
	public void enable_the_MasksCreation_Tab() throws IOException, InterruptedException {
		log.logging("Enable the Mask Creation in Mask tab", "info");
		Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		boolean result = query.setDBResponse("enableMaskCreation", userId.toString());
	}
	
	@Then("^Enable the Whatsup tab for the application$")
	
	public void Enable_the_Whatsup_tab_for_the_application() throws IOException, InterruptedException
	{
	log.logging("Enabling the Whatsup tab", "info");
	Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
	
	query.setDBResponse("disableWhatsAppTab", userId.toString());
	Thread.sleep(3000);
	query.setDBResponse("EnableWhatsupTab", userId.toString());
	}

	@Then("^Check the WhatsApp Tab is Present$")
	public void check_the_WhatsApp_Tab_is_Present() {
		log.logging("Checking WhatsApp Tab is Displayed", "info");
//		boolean wTab = driver.findElement(By.xpath("//span[text()='WhatsApp']")).isDisplayed();
		boolean wTab = driver.findElement(By.xpath("//ul[@class='clearfix']//descendant::li//span[contains(text(),'WhatsApp')]")).isDisplayed();
		
		Assert.assertEquals(wTab, true);

	}

	@Then("^Click On WhatsApp Tab$")
	public void click_On_WhatsApp_Tab() throws InterruptedException {
		log.logging("Clicking on WhatsApp Tab", "info");
		driver.findElement(By.xpath("//span[text()='WhatsApp']")).click();
		Thread.sleep(5000);
	}

	@Then("^Check the Sub Tab of WhatsApp Sub Tab Simple$")
	public void check_the_Sub_Tab_of_WhatsApp_Sub_Tab_Simple() {
		log.logging("Clicking on Simple Sub Tab", "info");
		driver.findElement(By.linkText("Simple")).click();
		log.logging("Checking sub tab name as Simple", "info");
		String tabName = driver.findElement(By.linkText("Simple")).getText();
		Assert.assertEquals(tabName, "Simple");
		log.logging("Checking Element Messaging is Present", "info");
		String pageElemCheck = driver.findElement(By.xpath("//*[@id=\"middle-col\"]/div[3]")).getText();
		Assert.assertEquals(pageElemCheck, "Messaging");

	}

	@Then("^Check the Sub Tab of WhatsApp Sub Tab Bulk$")
	public void check_the_Sub_Tab_of_WhatsApp_Sub_Tab_Bulk() throws Throwable {
		log.logging("Clicking on Bulk Sub Tab", "info");

		driver.findElement(By.linkText("Bulk")).click();
		log.logging("Checking sub tab name as Bulk", "info");

		String tabName = driver.findElement(By.linkText("Bulk")).getText();
		Assert.assertEquals(tabName, "Bulk");
		String pageElemCheck = driver.findElement(By.xpath("//*[@id=\"middle-col\"]/div[3]")).getText();
		Assert.assertEquals(pageElemCheck, "Bulk Message Queue");

	}

	@Then("^Refresh the Page$")
	public void refresh_the_Page() throws InterruptedException {
		log.logging("Refreshing The Page", "info");
		Thread.sleep(3000);
		su.refreshPage();

	}

	@Then("^Check the PopUp for Not Allowing SMS$")
	public void check_the_PopUp_for_Not_Allowing_SMS() {
		log.logging("Checking Popup", "info");
		boolean popUpcheck = driver.findElement(By.linkText("enterprise-support@smsgupshup.com")).isDisplayed();
		/*boolean popUpcheck = driver.findElement(By.xpath("//div[@id='whatsAppUserNotificationPopup']/div[1]/p[1]"))
				.isDisplayed();*/
		log.logging(String.valueOf(popUpcheck), "info");
		Assert.assertEquals(popUpcheck, true);
		log.logging("Closing PopUp", "info");
		driver.findElement(By.xpath("(//a[@class='popCloseBtn floatRight'])[2]")).click();
	}

	@Then("^Check the Location Tab$")
	public void check_the_Location_Tab() throws InterruptedException {
		log.logging("Checking sub tab name as Location", "info");

		driver.findElement(By.id("locationTabHeaderSpan")).click();
		
		String tabVerify = driver.findElement(By.xpath("//*[@id=\"locationTabHeaderSpan\"]")).getText();
		Assert.assertEquals(tabVerify, " Location ");

		/*Thread.sleep(2000);
		log.logging("Checking Some element Location", "info");
		Thread.sleep(2000);

		String longitude = driver.findElement(By.xpath("//div[text()='Longitude']")).getText();
		Assert.assertEquals(longitude, "Longitude");*/
	}
	@Then("^Click the SMS Tab$")
	public void click_the_SMS_Tab() throws InterruptedException {
		log.logging("Clicking on SMSTab", "info");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='SMS']")).click();
		Thread.sleep(3000);

	}

	@Then("^Tab Verification Test Start$")
	public void tab_Verification_Test_Start() {
		log.logging("Tab Verification Flow Started", "info");
	}

	@Then("^Tab Verification Test End$")
	public void tab_Verification_Test_End() {
		log.logging("Tab Verification Flow Ended", "info");

	}
}
