package com.enterprise.ui.auto.stepDefinition;

//import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;

public class settingFlowTesting {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	String username;
	String password;
	ReportingLogging log;
	public String getEnterpriseUsername = null;
	ExecuteQuery query;

	public settingFlowTesting() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		query = new ExecuteQuery();
	}
	
	@Given("^User is logged into the Enterprise website with proper credentials$")
	public void user_is_logged_into_the_enterprise_website_with_proper_credentials() throws InterruptedException {
		log.logging("Verifying whether user is already logged in", "info");
		//driver.findElement(By.xpath("//div[text()='Dashboard']")).isDisplayed();
		Assert.assertEquals(driver.findElement(By.xpath("//div[text()='Dashboard']")), "Dashboard");
		Thread.sleep(500);
		log.logging("User is already logged in", "info");
	}
	@When("^User clicks on the settings icon$")
	public void user_clicks_on_the_settings_icon() throws InterruptedException {
		try {
			log.logging("User will click on the Settings icon", "info");
			driver.findElement(By.xpath("//a[@title='Settings']")).click();
			Thread.sleep(500);
			log.logging("User has clicked on the Settings icon", "info");
		
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	@Then("^User should be directed to the Settings page$")
	public void user_should_be_directed_to_the_settings_page() throws InterruptedException {
		log.logging("User will be directed to the Settings page", "info");
		//Assert.assertEquals(driver.findElement(By.xpath("//div[text()='Settings']")).getText(), "Settings");
		Assert.assertEquals(driver.getTitle(), "Gupshup - Dashboard");
		Thread.sleep(500);
		log.logging("User has been directed to the Settings page", "info");
	}
	
/*	@And("^Personal Details sub tab should be expanded$")
	public void personal_details_sub_tab_should_be_expanded(){
	}
*/	
	@When("^User clicks on the Edit button$")
	public void user_clicks_on_the_edit_button() throws InterruptedException {
		log.logging("User will click on the Edit button", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		Thread.sleep(1000);
		log.logging("User has clicked on the Edit button", "info");
	}	

	@Then("^The Personal Details tab should open in edit mode$")
	public void the_personal_details_tab_should_open_in_edit_mode() throws InterruptedException {
		log.logging("Personal Details sub tab will open in edit mode", "info");
		Assert.assertEquals(driver.findElement(By.xpath("//input[@name='submitButton']")),driver.findElement(By.xpath("//input[@name='submitButton']")));
		Thread.sleep(1000);
		log.logging("Personal Details sub tab has opened in edit mode", "info");
	
	}
	
	@And("^The Name field should not be editable$")
	public void the_name_field_should_not_be_editable() throws InterruptedException {
		log.logging("Checking if the Name field is editable or not", "info");
		boolean popUpCheck = driver.findElement(By.id("contactPersonNameLabel")).isEnabled();
		log.logging(String.valueOf(popUpCheck) , "info");
		if (popUpCheck == true) {
			log.logging("Name field is not editable", "info");
		} else {
			log.logging(String.valueOf(popUpCheck) + " Name field is editable", "info");
		}
		Thread.sleep(500);
	}
	
	@And("^The Company Name field should not be editable$")
	public void the_company_name_field_should_not_be_editable() throws InterruptedException {
		log.logging("Checking if the Company Name field is editable or not", "info");
		boolean popUpCheck = driver.findElement(By.id("companyNameLabel")).isEnabled();
		log.logging(String.valueOf(popUpCheck) , "info");
		if (popUpCheck == true) {
			log.logging("Company Name field is not editable", "info");
		} else {
			log.logging(String.valueOf(popUpCheck) + " Company Name field is editable", "info");
		}
		Thread.sleep(500);
	}
	
	@And("^The Industry field should not be editable$")
	public void the_industry_field_should_not_be_editable() throws InterruptedException {
		log.logging("Checking if the Industry field is editable or not", "info");
		boolean popUpCheck = driver.findElement(By.id("industryLabel")).isEnabled();
		log.logging(String.valueOf(popUpCheck) , "info");
		if (popUpCheck == true) {
			log.logging("Industry field is not editable", "info");
		} else {
			log.logging(String.valueOf(popUpCheck) + " Industry field is editable", "info");
		}
		Thread.sleep(500);
	}
	
	@Then("^The Mobile field is mandatory$")
	public void the_mobile_field_is_mandatory() throws InterruptedException {
		log.logging("Verifying that the mobile field is mandatory", "info");
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		//Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"contactPersonMobileTextboxErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"contactPersonMobileTextboxErrorEle\"]")).getText(),"This information is mandatory.");
		//Assert.assertEquals(driver.findElement(By.xpath("//div[text()='One or more fields have errors marked in red beside them. Please correct those errors and submit again']")).getText(),"One or more fields have errors marked in red beside them. Please correct those errors and submit again");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the mobile field is mandatory", "info");
	}
	
	@Then("^The Mobile field should not be blank$")
	public void the_mobile_field_should_not_be_blank() throws InterruptedException {
		log.logging("Verifying that the mobile field should not be blank", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		//Assert.assertEquals(driver.findElement(By.xpath("//div[text()='One or more fields have errors marked in red beside them. Please correct those errors and submit again']")).getText(),"One or more fields have errors marked in red beside them. Please correct those errors and submit again");
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"contactPersonMobileTextboxErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the mobile field should not be blank", "info");
	}
	
	@Then("^The Mobile field should not accept alphabets$")
	public void the_mobile_field_should_not_accept_alphabets() throws InterruptedException {
		log.logging("Verifying that the mobile field should not should not accept alphabets", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).sendKeys("abc");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"contactPersonMobileTextboxErrorEle\"]")).getText(),"Please provide a valid mobile number.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the mobile field should not accept alphabets", "info");
	}
	
	@Then("^The Mobile field should not accept special characters$")
	public void the_mobile_field_should_not_accept_special_characters() throws InterruptedException {
		log.logging("Verifying that the mobile field should not accept special characters", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).sendKeys("!@#$");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"contactPersonMobileTextboxErrorEle\"]")).getText(),"Please provide a valid mobile number.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the mobile field should not accept special characters", "info");
	}

	@Then("^The Mobile field should only accept numbers$")
	public void the_mobile_field_should_only_accept_numbers() throws InterruptedException {
		log.logging("Verifying that the mobile field should only accept numbers", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).sendKeys("9876543210");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Thread.sleep(2000);
		log.logging("Verified that the mobile field should only accept numbers", "info");
	}

	@Then("^The Mobile field should only accept ten digits$")
	public void the_mobile_field_should_only_accept_ten_digits() throws InterruptedException {
		log.logging("Verifying that the mobile field should only accept ten digits", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		log.logging("Checking for numbers less than 10 digits", "info");
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).sendKeys("98765");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"contactPersonMobileTextboxErrorEle\"]")).getText(),"Please provide a valid mobile number.");
		Thread.sleep(500);
		log.logging("Checked that numbers less than 10 digits are not accepted", "info");
		log.logging("Checking for numbers more than 10 digits", "info");
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).sendKeys("987654321098");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"contactPersonMobileTextboxErrorEle\"]")).getText(),"Please provide a valid mobile number.");
		Thread.sleep(500);
		log.logging("Checked that numbers more than 10 digits are not accepted", "info");
		log.logging("Checking for numbers with Indian country code along with 10 digits", "info");
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).sendKeys("919876543210");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		log.logging("Checked that numbers with Indian country code along with 10 digits are accepted", "info");
		log.logging("Checking for numbers with exact with 10 digits", "info");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='contactPersonMobileTextbox']")).sendKeys("9988776655");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		log.logging("Checked that numbers with exact 10 digits are accepted", "info");
		log.logging("Verified that the mobile field should only accept ten digits", "info");
		Thread.sleep(500);
	}
	
	@Then("^The Email field is mandatory$")
	public void the_email_field_is_mandatory() throws InterruptedException {
		log.logging("Verifying that the email field is mandatory", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//textarea[@name='addressTextArea']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"addressTextAreaErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the email field is mandatory", "info");
	}
	
	@Then("^The Email field should not be blank$")
	public void the_email_field_should_not_be_blank() throws InterruptedException {
		log.logging("Verifying that the email field should not be blank", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//textarea[@name='addressTextArea']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"addressTextAreaErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the email field should not be blank", "info");
	}
	
	@Then("^The Address field is mandatory$")
	public void the_address_field_is_mandatory() throws InterruptedException {
		log.logging("Verifying that the address field is mandatory", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//textarea[@name='addressTextArea']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"addressTextAreaErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the address field is mandatory", "info");
	}
	
	@Then("^The Address field should not be blank$")
	public void the_address_field_should_not_be_blank() throws InterruptedException {
		log.logging("Verifying that the address field should not be blank", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//textarea[@name='addressTextArea']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"addressTextAreaErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the address field should not be blank", "info");
	}
	
	@Then("^The City field is mandatory$")
	public void the_city_field_is_mandatory() throws InterruptedException {
		log.logging("Verifying that the city field is mandatory", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='cityTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"cityTextboxErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the city field is mandatory", "info");
	}
	
	@Then("^The City field should not be blank$")
	public void the_city_field_should_not_be_blank() throws InterruptedException {
		log.logging("Verifying that the city field should not be blank", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='cityTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"cityTextboxErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the city field should not be blank", "info");
	}
	
	@Then("^The City field should not accept numbers$")
	public void the_city_field_should_not_accept_numbers() throws InterruptedException {
		log.logging("Verifying that the city field should not accept numbers", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='cityTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='cityTextbox']")).sendKeys("123");
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"cityTextboxErrorEle\"]")).getText(),"City should include alphabetic characters.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the city field should not accept numbers", "info");
	}
	
	@Then("^The City field should not accept special characters$")
	public void the_city_field_should_not_accept_special_characters() throws InterruptedException {
		log.logging("Verifying that the city field should not accept special characters", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='cityTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='cityTextbox']")).sendKeys("!@#$");
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"cityTextboxErrorEle\"]")).getText(),"City should include alphabetic characters.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the city field should not accept special characters", "info");
	}
	
	@Then("^The Pin Code field is mandatory$")
	public void the_pin_code_field_is_mandatory() throws InterruptedException {
		log.logging("Verifying that the pin code field is mandatory", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"pincodeTextboxErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the pin code field is mandatory", "info");
	}
	
	@Then("^The Pin Code field should not be blank$")
	public void the_pin_code_field_should_not_be_blank() throws InterruptedException {
		log.logging("Verifying that the pin code field should not be blank", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"pincodeTextboxErrorEle\"]")).getText(),"This information is mandatory.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the pin code field should not be blank", "info");
	}
	
	@Then("^The Pin Code field should not accept alphabets$")
	public void the_pin_code_field_should_not_accept_alphabets() throws InterruptedException {
		log.logging("Verifying that the pin code field should not accept alphabets", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).sendKeys("abc");
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"pincodeTextboxErrorEle\"]")).getText(),"Please provide a valid pincode.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the pin code field should not accept alphabets", "info");
	}
	
	@Then("^The Pin Code field should not accept special characters$")
	public void the_pin_code_field_should_not_accept_special_characters() throws InterruptedException {
		log.logging("Verifying that the pin code field should not accept special characters", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).sendKeys("!@#$");
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//span[@id=\"pincodeTextboxErrorEle\"]")).getText(),"Please provide a valid pincode.");
		Thread.sleep(500);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(500);
		log.logging("Verified that the pin code field should not accept special characters", "info");
	}
	
	@Then("^The Pin Code field should only accept numbers$")
	public void the_pin_code_field_should_only_accept_numbers() throws InterruptedException {
		log.logging("Verifying that the pin code field should only accept numbers", "info");
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@name='pincodeTextbox']")).sendKeys("400001");
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Thread.sleep(500);
		log.logging("Verified that the pin code field should only accept numbers", "info");
	}
/*	
	@When("^User clicks on Update button$")
	public void user_clicks_on_update_button() throws InterruptedException {
		log.logging("User will click on the update button", "info");
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		Thread.sleep(500);
		log.logging("User has clicked on the update button", "info");
		//input[@name='submitButton']
	}
	
	@Then("^All the details should get saved properly$")
	public void all_the_details_should_get_saved_properly() throws InterruptedException {
		log.logging("Verifying that the details are getting saved properly", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - Settings");
		Thread.sleep(500);
		log.logging("Verified, details are getting saved properly", "info");
	}

	@And("^The Personal Details edit mode should get disabled$")
	public void the_personal_details_edit_mode_should_get_disabled() throws InterruptedException {
		log.logging("Edit mode will get disabled for the Personal Details sub tab", "info");
		Assert.assertEquals(driver.findElement(By.xpath("//a[text()='Edit']")).getText(),"Edit");
		Thread.sleep(500);
		log.logging("Edit mode has been disabled for the Personal Details sub tab", "info");
	}
/*	
	@And("^User should be able to view the updated details$")
	public void user_should_be_able_to_view_the_updated_details(){
	} */
	
	@When("^User clicks on the GSTIN Details sub tab$")
	public void user_clicks_on_the_gstin_details_sub_tab() throws InterruptedException, IOException {
		try {

			log.logging("User will click on the GSTIN Details sub tab", "info");
			driver.findElement(By.id("AddGSTCookie")).click();
			Thread.sleep(500);
			log.logging("User has clicked on the GSTIN Details sub tab", "info");
			
			String accID = env.getEnterpriseUsername();
			query.getDBResponse(accID, "id", "enableGSTIN");
			
		
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@Then("^The GSTIN Details sub tab should open in edit mode$")
	public void the_gstin_details_sub_tab_should_open_in_edit_mode() throws InterruptedException {
		try {

			log.logging("The GSTIN Details sub tab will open in Edit mode", "info");
			boolean gstTabEnabledCheck = driver.findElement(By.id("readOnlybillingName")).isEnabled();
			if (gstTabEnabledCheck == true) {
				log.logging("The GSTIN Details sub tab has opened in edit mode", "info");
			} else {
				log.logging(String.valueOf(gstTabEnabledCheck) + " Try again", "info");
			}
			Thread.sleep(500);
		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@And("^Company Name field under GSTIN sub tab should not be editable$")
	public void company_name_field_under_gstin_sub_tab_should_not_be_editable() throws InterruptedException {
		log.logging("Checking if the Company Name field under GSTIN sub tab is editable or not", "info");
		boolean popUpCheck = driver.findElement(By.id("readOnlybillingName")).isEnabled();
		log.logging(String.valueOf(popUpCheck) , "info");
		if (popUpCheck == true) {
			log.logging("Company Name field under GSTIN sub tab is not editable", "info");
		} else {
			log.logging(String.valueOf(popUpCheck) + " Company Name field under GSTIN sub tab is editable", "info");
		}
		Thread.sleep(500);
	}
	
	@And("^Address field under GSTIN sub tab should not be editable$")
	public void address_field_under_gstin_sub_tab_should_not_be_editable() throws InterruptedException {
		log.logging("Checking if the Address field under GSTIN sub tab is editable or not", "info");
		boolean popUpCheck = driver.findElement(By.xpath("//div[@class='label']/strong[1]")).isEnabled();
		log.logging(String.valueOf(popUpCheck) , "info");
		if (popUpCheck == true) {//span[@id=\"cont//span[@id=\"contactPersonMobileTextboxErrorEle\"]//span[@id=\"contactPersonMobileTextboxErrorEle\"]actPersonMobileTextboxErrorEle\"]
			log.logging("Address field under GSTIN sub tab is not editable", "info");
		} else {
			log.logging(String.valueOf(popUpCheck) + " Address field under GSTIN sub tab is editable", "info");
		}
		Thread.sleep(500);
	}
	
	@And("^Address field should auto populate from the Personal Details sub tab$")
	public void address_field_should_auto_populate_from_the_personal_details_sub_tab() throws InterruptedException {
		log.logging("Verifying that the Address field under GSTIN sub tab should auto populate from the Address field under the Personal Details sub tab", "info");
		//String addressCheck = driver.findElement(By.xpath("//div[@id='showUserInfoDiv']//table[2]/tbody/tr/td[1]//div[@class='user-details']//table/tbody/tr[2]/td[2]")).getText();
		//log.logging(String.valueOf(addressCheck) , "info");
		Assert.assertEquals(driver.findElement(By.xpath("//div[@id='showUserInfoDiv']//table[2]/tbody/tr/td[1]//div[@class='user-details']//table/tbody/tr[2]/td[2]")).getText(),driver.findElement(By.xpath("//*[@id='addBillingDetailsDiv']/div[3]/div[2]/div[1]/div[2]")).getText());
		log.logging("Verified that the Address field under GSTIN sub tab auto populates from the Address field under the Personal Details sub tab", "info");
		Thread.sleep(1000);
	}
	
	@And("^Pin Code field under GSTIN sub tab should not be editable$")
	public void pin_code_field_under_gstin_sub_tab_should_not_be_editable() throws InterruptedException {
		log.logging("Checking if the Pin Code field under GSTIN sub tab is editable or not", "info");
		boolean popUpCheck = driver.findElement(By.xpath("//*[@id=\"addBillingDetailsDiv\"]/div[3]/div[2]/div[1]/div[2]")).isEnabled();
		log.logging(String.valueOf(popUpCheck) , "info");
		if (popUpCheck == true) {
			log.logging("Pin Code field under GSTIN sub tab is not editable", "info");
		} else {
			log.logging(String.valueOf(popUpCheck) + " Pin Code field under GSTIN sub tab is editable", "info");
		}
		Thread.sleep(1000);
	}
	
	@And("^Pin Code field should auto populate from the Personal Details sub tab$")
	public void pin_code_field_should_auto_populate_from_the_personal_details_sub_tab() throws InterruptedException {
		log.logging("Verifying that the Pin Code field under GSTIN sub tab should auto populate from the Pin Code field under the Personal Details sub tab", "info");
		String addressCheck1 = driver.findElement(By.xpath("//div[@class=\"showUserAccDetailsToggle\"]/div/div/div/table/tbody/tr/td/div/table[2]/tbody/tr/td/div/table/tbody/tr[5]/td[2]")).getText();
		log.logging(String.valueOf(addressCheck1) , "info");
		//String addressCheck2 = driver.findElement(By.xpath("//div[@class=\"showGSTDetailsToggle\"]/div/div/form/div/div[4]/div[2]/div/div[1]/input")).getText();
		//log.logging(String.valueOf(addressCheck2) , "info");
		List<WebElement> elements = driver.findElements(By.name("name"));
	    System.out.println("Number of elements:" +elements.size());

	    for (int i=0; i<elements.size();i++){
	      System.out.println("Radio button text:" + elements.get(i).getAttribute("value"));
	    }
		
		
		Thread.sleep(1000);
		//Assert.assertEquals(driver.findElement(By.xpath("//div[@id=\'showUserInfoDiv\']/table[2]/tbody/tr/td//div/table/tbody/tr[5]/td[2]")).getText(),driver.findElement(By.xpath("//*[@id=\"addBillingDetailsDiv\"]/div[4]/div[2]/div[1]/div")).getText());
		//log.logging("Verified that the Pin Code field under GSTIN sub tab auto populates from the Pin Code field under the Personal Details sub tab", "info");
		Thread.sleep(1000);
	}
	
	@And("^Billing / GSTIN field should be mandatory$")
	public void billing_gstin_field_should_be_mandatory() throws InterruptedException {
		log.logging("Verifying that the Billing / GSTIN field is mandatory", "info");
		boolean billingGSTIN = driver.findElement(By.xpath("//div[@class=\"block\"]//div[@class=\"ms-signup-fields\"]/strong[1]")).isEnabled();
		log.logging(String.valueOf(billingGSTIN) , "info");
		if (billingGSTIN == true) {
			log.logging("Billing / GSTIN field is Mandatory", "info");
		} else {
			log.logging("Billing / GSTIN field is not Mandatory", "info");
		}
		//*[@id="addBillingDetailsDiv"]/div[3]/div[2]/div[2]/div[1]/strong
		Thread.sleep(1000);
		log.logging("Verified that the Billing / GSTIN field is mandatory", "info");
	}
	
	@When("^Verify whether account is postpaid if Transaction History sub tab is not available$")
	public void verify_whether_account_is_postpaid_if_transaction_history_sub_tab_is_not_available() throws InterruptedException {
		log.logging("Verifying whether account is postpaid", "info");
		Thread.sleep(1000);
		log.logging("try and catch", "info");
		boolean present;
		try {
		   driver.findElement(By.id("TransactionHistoryCookie"));
		   present = true;
		} catch (NoSuchElementException e) {
		   present = false;
		}
		if (present == false) {
			log.logging("Verified that the account is postpaid", "info");
		}
		else {
			log.logging("Account is Prepaid", "info");
		}
	}
	
	@And("^Verify whether account is prepaid if Transaction History sub tab is available$")
	public void verify_whether_account_is_prepaid_if_transaction_history_sub_tab_is_available() throws InterruptedException {
		try{
			log.logging("Verifying whether account is prepaid", "info");
			boolean trnHist = driver.findElement(By.id("TransactionHistoryCookie")).isDisplayed();
			if(trnHist == true) {
				log.logging("Verified that the Account is prepaid", "info");
				log.logging("User will expand the Transaction History sub tab", "info");
				driver.findElement(By.id("TransactionHistoryCookie")).click();
				log.logging("User has expanded the Transaction History sub tab", "info");
				Thread.sleep(500);
				log.logging("User will collapse the Transaction History sub tab", "info");
				driver.findElement(By.id("TransactionHistoryCookie")).click();
				Thread.sleep(500);
				log.logging("User has collapsed the Transaction History sub tab", "info");
			}
		}
		catch(NoSuchElementException e){
			log.logging("Account is POSTPAID", "info");
		}
	}
	
	@When("^User clicks on the Email Settings sub tab$")
	public void user_clicks_on_the_email_settings_sub_tab() throws InterruptedException {
		log.logging("Verify the Email Settings sub tab", "info");
		log.logging("User will expand the Email Settings sub tab", "info");
		driver.findElement(By.id("EmailSettingsCookie")).click();
		Thread.sleep(500);
		log.logging("User will collapse the Email Settings sub tab", "info");
		driver.findElement(By.id("EmailSettingsCookie")).click();
		Thread.sleep(500);
		log.logging("Verified the Email Settings sub tab", "info");
	}
	
	@And("^click submit and check validations for mandatory fields$")
	public void click_submit_and_check_validations_for_mandatory_fields() throws InterruptedException {
		
		try {
			

			log.logging("Verifying validation message for mandatory fields", "info");
			driver.findElement(By.xpath("//*[@id=\"GSTPostalAddress\"]")).clear();
			
			driver.findElement(By.xpath("//*[@id=\"panNumber\"]")).clear();
			
			driver.findElement(By.xpath("//*[@id=\"editgstin\"]/input")).clear();
			
//			Select select = new Select(driver.findElement(By.xpath("//*[@id=\"registrationType\"]")));
//			select.selectByValue("Select Registration Type");
//			
//			Select custCategory = new Select(driver.findElement(By.xpath("//*[@id=\"customerCategory\"]")));
//			custCategory.selectByValue("Select customer category");
			
			driver.findElement(By.xpath("//*[@id=\"editbillingContactPersonName\"]/input")).clear();
			
			driver.findElement(By.xpath("//*[@id=\"editbillingPersonContactNumber\"]/input")).clear();
			
			driver.findElement(By.xpath("//*[@id=\"invoiceReceivingEmailId\"]")).clear();
			
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonName\"]/input")).clear();
			
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonContactNumber\"]/input")).clear();
			
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonEmailId\"]/input")).clear();
			
			
			driver.findElement(By.xpath("//*[@id=\"addGSTDetailsBtnId\"]")).click();
			
			String billingAddress = driver.findElement(By.xpath("//*[@id=\"billingAddressTextAreaErrorEle\"]")).getText();
			Assert.assertEquals("This information is mandatory.", billingAddress);
			
			String PanNumber = driver.findElement(By.xpath("//*[@id=\"panTextBoxErrorEle\"]")).getText();
			Assert.assertEquals("Please provide a valid PAN number.", PanNumber);
			
			String GSTINregNumber = driver.findElement(By.xpath("//*[@id=\"gstinTextBoxErrorEle\"]")).getText();
			Assert.assertEquals("The first two digits should be same as state code.", GSTINregNumber);
			
			
//			String regType = driver.findElement(By.xpath("//*[@id=\"registrationTypeErrorEle\"]")).getText();
//			Assert.assertEquals("This information is mandatory.", regType);
//			
//			String custCategoryValidation = driver.findElement(By.xpath("//*[@id=\"customerCategoryErrorEle\"]")).getText();
//			Assert.assertEquals("This information is mandatory.", custCategoryValidation);
			
			String contactPerName = driver.findElement(By.xpath("//*[@id=\"billingContactPersonNameTextBoxErrorEle\"]")).getText();
			Assert.assertEquals("This information is mandatory.", contactPerName);
			
			String MobileNumber = driver.findElement(By.xpath("//*[@id=\"billingPersonContactNumberTextboxErrorEle\"]")).getText();
			Assert.assertEquals("This information is mandatory.", MobileNumber);
			
			String emailID = driver.findElement(By.xpath("//*[@id=\"invoiceReceivingEmailIdTextboxErrorEle\"]")).getText();
			Assert.assertEquals("This information is mandatory.", emailID);
			
			String gstContactPersonName = driver.findElement(By.xpath("//*[@id=\"gstContactPersonNameTextboxErrorEle\"]")).getText();
			Assert.assertEquals("This information is mandatory.", gstContactPersonName);
			
			String GSTContactPersonContactNumber = driver.findElement(By.xpath("//*[@id=\"gstContactPersonMobileTextboxErrorEle\"]")).getText();
			Assert.assertEquals("This information is mandatory.", GSTContactPersonContactNumber);
			
			String GSTContactPersonEmailId = driver.findElement(By.xpath("//*[@id=\"gstContactPersonEmailTextboxErrorEle\"]")).getText();
			Assert.assertEquals("This information is mandatory.", GSTContactPersonEmailId);
		
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	@And("^enter all mandatory fields and submit the details$")
	public void enter_all_mandatory_fields_and_submit_the_details() throws InterruptedException {
		
		try {
			

			log.logging("Verifying validation message for mandatory fields", "info");
			driver.findElement(By.xpath("//*[@id=\"GSTPostalAddress\"]")).clear();
			driver.findElement(By.xpath("//*[@id=\"GSTPostalAddress\"]")).sendKeys("Gupshup Technologies,101 Silver Metropolis,\r\n"
					+ "\r\n"
					+ " 1st Floor,");
			
			driver.findElement(By.xpath("//*[@id=\"panNumber\"]")).clear();
			driver.findElement(By.xpath("//*[@id=\"panNumber\"]")).sendKeys("APTPJ0351D");
			
			driver.findElement(By.xpath("//*[@id=\"editgstin\"]/input")).clear();
			driver.findElement(By.xpath("//*[@id=\"editgstin\"]/input")).sendKeys("29APTPJ0351D1Z5");
			
			
//			Select select = new Select(driver.findElement(By.xpath("//*[@id=\"registrationType\"]")));
//			select.selectByValue("Select Registration Type");
//			
//			Select custCategory = new Select(driver.findElement(By.xpath("//*[@id=\"customerCategory\"]")));
//			custCategory.selectByValue("Select customer category");
			
			driver.findElement(By.xpath("//*[@id=\"editbillingContactPersonName\"]/input")).clear();
			driver.findElement(By.xpath("//*[@id=\"editbillingContactPersonName\"]/input")).sendKeys("Nirav Patel");
			
			driver.findElement(By.xpath("//*[@id=\"editbillingPersonContactNumber\"]/input")).clear();
			driver.findElement(By.xpath("//*[@id=\"editbillingPersonContactNumber\"]/input")).sendKeys("919819859580");
			
			driver.findElement(By.xpath("//*[@id=\"invoiceReceivingEmailId\"]")).clear();
			driver.findElement(By.xpath("//*[@id=\"invoiceReceivingEmailId\"]")).sendKeys("nirav.patel@webaroo.com");
			
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonName\"]/input")).clear();
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonName\"]/input")).sendKeys("Nirav Patel");
			
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonContactNumber\"]/input")).clear();
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonContactNumber\"]/input")).sendKeys("919819859580");
			
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonEmailId\"]/input")).clear();
			driver.findElement(By.xpath("//*[@id=\"editGSTContactPersonEmailId\"]/input")).sendKeys("nirav.patel@webaroo.com");
			
			
			driver.findElement(By.xpath("//*[@id=\"addGSTDetailsBtnId\"]")).click();
			
			String message = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			Assert.assertEquals("Billing details added successfully.", message);
		
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	
}