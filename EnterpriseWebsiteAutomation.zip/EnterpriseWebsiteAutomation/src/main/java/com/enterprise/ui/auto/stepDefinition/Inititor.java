package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;

import com.cucumber.listener.Reporter;
import com.enterprise.ui.auto.Bo.*;
//import com.enterprise.ui.auto.utility.ExtentReporting;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.Screenshot;
//import com.enterprise.ui.auto.utility.Screenshot;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Inititor extends SeleniumUtility {

	@Before
	public void initTest() throws InterruptedException, IOException {

		EnvBO env = new EnvBO();
		String browser = System.getProperty("browser");
		String pro = null;
		pro = System.getProperty("https");
		if (pro == null) {
			log.info("We are running with default Protocol which is http");
			pro = "false";
		}

		if (browser == null) {
			log.info("No browser provided so running on default browser Chrome");
			initDriver("Chrome");

		} else
			initDriver(browser);

		if (pro.equalsIgnoreCase("true")) {
			setUrl("https://" + env.getEnterpriseUrl());
		} else {
			setUrl("http://" + env.getEnterpriseUrl());
		}

		Thread.sleep(1000);
		browserSetting();

	}

	@After(order = 1)
	public void getScreenShot(Scenario scenario) throws IOException {
		String screenShotPath = "";
		if (scenario.isFailed()) {
			screenShotPath = Screenshot.getScreenShot(driver, scenario.getName().replace(" ", "_"));
			log.info(screenShotPath);
			Reporter.addScreenCaptureFromPath(screenShotPath);
		}

	}

	@After(order = 0)
	public void tearDown(Scenario scenario) throws IOException {

		driverCloser();

	}
}
