package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExcelReaderUtility;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.itextpdf.text.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

import org.openqa.selenium.support.ui.Select;

public class HomePage {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	ExecuteQuery query;
	String htid =null;
	String aggrAccId = null;
	ExcelReaderUtility fileread;
	
	static String repoPath = "resources/Locators/Whatsup.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	
	public HomePage() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		query = new ExecuteQuery();
		sa = new SoftAssert(); 
	}
	
	@Then("^User Checks Tab$")
	public void user_Checks_Tab(DataTable Tabs) throws Throwable 
	{
		for (Map<String, String> TabsClick : Tabs.asMaps(String.class, String.class)) 
		{
			String Tabname = TabsClick.get("TabName");
			log.logging(Tabname, "info");
		
			if(Tabname.equalsIgnoreCase("Messaging-API")) 
			{
				By b1 =PropertiesFileReader.getPropertylocator("repoPath","Messaging-API", locator);
				driver.findElement(b1).click();
				 WebElement url = driver.findElement(By.xpath("//div[text()='Enable engaging conversations seamlessly across 30+ channels using a Single API']"));
				 Assert.assertEquals(true, url.isDisplayed());
				log.logging("Tab Messaging-API found", "info");
			}
			else if(Tabname.equalsIgnoreCase("Channels"))
			{
				By b2 =PropertiesFileReader.getPropertylocator("repoPath","Channels", locator);
				driver.findElement(b2).click();
				 WebElement dd = driver.findElement(By.xpath("//ul[@class='dropdown-menu products-menu']"));
				 Assert.assertEquals(true, dd.isDisplayed());
				log.logging("Tab Channels found", "info");
			}
			else if(Tabname.equalsIgnoreCase("AboutUs")) 
			{
				By b3 =PropertiesFileReader.getPropertylocator("repoPath","AboutUs", locator);
				driver.findElement(b3).click();
				 WebElement abturl = driver.findElement(By.xpath("//h1[text()='About Us']"));
				 Assert.assertEquals(true, abturl.isDisplayed());
				log.logging("Tab About Us found", "info");
			}
			else if(Tabname.equalsIgnoreCase("ContactUs")) 
			{
				By b4 =PropertiesFileReader.getPropertylocator("repoPath","ContactUs", locator);
				driver.findElement(b4).click();
				 WebElement cnturl = driver.findElement(By.xpath("//h1[text()='Contact Us']"));
				 Assert.assertEquals(true, cnturl.isDisplayed());
				log.logging("Tab Contact Us found", "info");
			}
			else if(Tabname.equalsIgnoreCase("Login")) 
			{
				By b4 =PropertiesFileReader.getPropertylocator("repoPath","Login", locator);
				driver.findElement(b4).click();
				 WebElement lgurl = driver.findElement(By.xpath("//h1[text()='Log in to your account']"));
				 Assert.assertEquals(true, lgurl.isDisplayed());
				log.logging("Tab Login found", "info");
			}
			else if(Tabname.equalsIgnoreCase("Signup")) 
			{
				By b4 =PropertiesFileReader.getPropertylocator("repoPath","Signup", locator);
				driver.findElement(b4).click();
				 WebElement snurl = driver.findElement(By.xpath("//h1[text()='Signup to get started']"));
				 Assert.assertEquals(true, snurl.isDisplayed());
				log.logging("Tab Signup found", "info");
			}
			
			
		}
		
	}
	
	@Then("^Check Channel SubTabs$")
	public void check_Channel_SubTabs() throws Throwable {
		
		
		
		WebElement channel = driver.findElement(By.xpath("//a[text()='Channels ']"));
		channel.click();
		ArrayList expectedDropDownItems = new ArrayList();
		expectedDropDownItems.add("WhatsApp Business");
		expectedDropDownItems.add("Instagram");
		expectedDropDownItems.add("SMS");
		expectedDropDownItems.add("RCS");
		expectedDropDownItems.add("GBM");
		expectedDropDownItems.add("Gupshup IP (GIP)");
		expectedDropDownItems.add("Telegram");
		
	
	    WebElement ul_element = driver.findElement(By.xpath("//ul[@class='dropdown-menu products-menu'][1]"));
	    java.util.List<WebElement> li_All = ul_element.findElements(By.tagName("li"));
	    Thread.sleep(3000);
        System.out.println(li_All.size());
        for(int i = 0; i < li_All.size(); i++){
            //System.out.println(li_All.get(i).getText());
            //log.logging("Channel Sub list " + li_All.get(i).getText(), "info");
            for(int i1=0;i1<expectedDropDownItems.size();i++) 
            {
            	log.logging("Channel Sub list " + li_All.get(i).getText(), "info");
            	log.logging("List Element " + expectedDropDownItems.get(i1),"info");
            	boolean match =	expectedDropDownItems.get(i1).equals(li_All.get(i).getText());
            	//boolean match = expectedDropDownItems.remove(i1).equals(li_All.get(i).getText());
            	if(match == true) 
            	{
            		log.logging("Match", "info");
            		//log.logging("Channel Sub list " + li_All.get(i).getText(), "info");
            	}
            	else 
            	{
            		log.logging("Not Match", "info");
            	}
            	i1+=1;
            	
            }
        }
	}
	
	@Then("^Check Channel Dropdown$")
	public void check_Channel_Dropdown(DataTable ChannelTabs) throws Throwable {
		//WebElement channel = driver.findElement(By.xpath("//a[text()='Channels ']"));
		//channel.click();
		Thread.sleep(2000);
		for (Map<String, String> TabsClick : ChannelTabs.asMaps(String.class, String.class)) 
		{
		
			String ChTabname = TabsClick.get("CHTabName");
			log.logging(ChTabname, "info");
		
			if(ChTabname.equalsIgnoreCase("WhatsApp Business")) 
			{
				By Channel =PropertiesFileReader.getPropertylocator("repoPath","Channels", locator);
				driver.findElement(Channel).click();
				Thread.sleep(1000);
				By b1 =PropertiesFileReader.getPropertylocator("repoPath","WhatsAppBusiness", locator);
				driver.findElement(b1).click();
				 WebElement url = driver.findElement(By.xpath("//div[text()='Grow your business by enabling engaging conversations on WhatsApp']"));
				 Assert.assertEquals(true, url.isDisplayed());
				log.logging("Sub Tab WhatsAppBusiness", "info");
				Thread.sleep(1000);
			}
			else if(ChTabname.equalsIgnoreCase("Instagram"))
			{
				By Channel =PropertiesFileReader.getPropertylocator("repoPath","Channels", locator);
				driver.findElement(Channel).click();
				By b2 =PropertiesFileReader.getPropertylocator("repoPath","Instagram", locator);
				driver.findElement(b2).click();
				 WebElement dd = driver.findElement(By.xpath("//div[text()='Engage with and monetize your followers with the Messenger API for Instagram']"));
				 Assert.assertEquals(true, dd.isDisplayed());
				log.logging("Sub Tab Instagram", "info");
			}
			else if(ChTabname.equalsIgnoreCase("SMS"))
			{
				By Channel =PropertiesFileReader.getPropertylocator("repoPath","Channels", locator);
				driver.findElement(Channel).click();
				Thread.sleep(1000);
				By b2 =PropertiesFileReader.getPropertylocator("repoPath","SMS", locator);
				driver.findElement(b2).click();
				 WebElement dd = driver.findElement(By.xpath("//div[text()='Enrich your customer engagements with a quick, reliable and scalable SMS API']"));
				 Assert.assertEquals(true, dd.isDisplayed());
				log.logging("Sub Tab SMS", "info");
			}
			else if(ChTabname.equalsIgnoreCase("RCS"))
			{
				By Channel =PropertiesFileReader.getPropertylocator("repoPath","Channels", locator);
				driver.findElement(Channel).click();
				By b2 =PropertiesFileReader.getPropertylocator("repoPath","RCS", locator);
				driver.findElement(b2).click();
				 WebElement dd = driver.findElement(By.xpath("//div[text()='Enable interactive mobile experience between enterprises and customers with RCS']"));
				 Assert.assertEquals(true, dd.isDisplayed());
				log.logging("Sub Tab RCS", "info");
			}
			else if(ChTabname.equalsIgnoreCase("Telegram"))
			{
				By Channel =PropertiesFileReader.getPropertylocator("repoPath","Channels", locator);
				driver.findElement(Channel).click();
				By b2 =PropertiesFileReader.getPropertylocator("repoPath","Telegram", locator);
				driver.findElement(b2).click();
				Thread.sleep(1000);
				 WebElement dd = driver.findElement(By.xpath("//*[@id=\"tele-carousel\"]/div/div/div/div/div[1]/div"));
				 Assert.assertEquals(true, dd.isDisplayed());
				log.logging("Sub Tab Telegram", "info");
			}
			else if(ChTabname.equalsIgnoreCase("GupshupIP(GIP)"))
			{
				By Channel =PropertiesFileReader.getPropertylocator("repoPath","Channels", locator);
				driver.findElement(Channel).click();
				By b2 =PropertiesFileReader.getPropertylocator("repoPath","GupshupIP(GIP)", locator);
				driver.findElement(b2).click();
				 WebElement dd = driver.findElement(By.xpath("//h1[text()='Gupshup IP (GIP) Messaging Service']"));
				 Assert.assertEquals(true, dd.isDisplayed());
				log.logging("Sub Tab GupshupIP(GIP)", "info");
			}
			
			}
		}
	
	@Then("^Check Talk to Expert$")
	public void check_Talk_to_Expert() throws Throwable {

		WebElement Home = driver.findElement(By.xpath("//a[@title='Home']"));
		Home.click();

		
		
		WebElement service = driver.findElement(By.xpath("//select[@id='service'][1]"));
		service.click();
		ArrayList expectedDropDownItems = new ArrayList();
		expectedDropDownItems.add("Select Product of Interest");
		expectedDropDownItems.add("WhatsApp");
		expectedDropDownItems.add("SMS");
		expectedDropDownItems.add("RCS");
		expectedDropDownItems.add("Google Business Message");
		expectedDropDownItems.add("Voice"); 
		expectedDropDownItems.add("Email");
		expectedDropDownItems.add("GIP");
		expectedDropDownItems.add("Telegram");
		expectedDropDownItems.add("Instagram"); 
		expectedDropDownItems.add("Omni-channel");
		expectedDropDownItems.add("Others");
		
	    WebElement ul_element = driver.findElement(By.xpath("//select[@id='service']"));
	    java.util.List<WebElement> li_All = ul_element.findElements(By.tagName("option"));
	    Thread.sleep(3000);
        System.out.println(li_All.size());
        for(int i = 0; i < li_All.size(); i++){
            //System.out.println(li_All.get(i).getText());
            //log.logging("Channel Sub list " + li_All.get(i).getText(), "info");
            for(int i1=0;i1<expectedDropDownItems.size();i++) 
            {
            	log.logging("DD Element " + li_All.get(i).getText(), "info");
            	log.logging("List Element " + expectedDropDownItems.get(i1),"info");
            	boolean match =	expectedDropDownItems.get(i1).equals(li_All.get(i).getText());
            	//boolean match = expectedDropDownItems.remove(i1).equals(li_All.get(i).getText());
            	if(match == true) 
            	{
            		log.logging("Match", "info");
            		//log.logging("Channel Sub list " + li_All.get(i).getText(), "info");
            	}
            	else 
            	{
            		log.logging("Not Match", "info");
            	}
            	i1+=1;
            	
            }
        }
	}
	
	@Then("^User fill form$")
	public void user_fill_form() throws Throwable {
	 
	//FirstName	
	 WebElement FN = driver.findElement(By.xpath("//input[@name='First_Name']"));
	 FN.sendKeys("John");
	 log.logging("First_Name filled", "info");
	 
	 //LastName
	 WebElement LN = driver.findElement(By.xpath("//input[@name='Last_Name']"));
	 LN.sendKeys("Denim");
	 log.logging("Last_Name filled", "info");
	
	
	//Phone Number
	WebElement PhNo = driver.findElement(By.xpath("//input[@name='Phone']"));
    PhNo.sendKeys("9999999999");
    log.logging("PhoneNo filled", "info");
	
	//Email
	WebElement Email = driver.findElement(By.xpath("//input[@name='Email']"));
	Email.sendKeys("JohnDenim@example.com");
	 log.logging("Email filled", "info");
		
	//Select Product of Interest
	Select POI = new Select(driver.findElement(By.name("Department")));
	POI.selectByVisibleText("WhatsApp");
	 log.logging("POI selected", "info");
	
	//Company Name
	WebElement CN = driver.findElement(By.xpath("//input[@name='Company']"));
	CN.sendKeys("RoundRun");
	log.logging("Company selected", "info");
	
	//Select country
	Select country = new Select(driver.findElement(By.name("Country")));
	country.selectByVisibleText("Australia");
	log.logging("Country selected", "info");
	
	Thread.sleep(2000);
	//Select State
	Select state = new Select(driver.findElement(By.name("State")));
	state.selectByVisibleText("New South Wales");
	log.logging("State selected", "info");
	
	
	Thread.sleep(2000);
	//Select City
	Select city = new Select(driver.findElement(By.name("City")));
	city.selectByVisibleText("Albert");
	log.logging("City selected", "info");
	
	
	
	Thread.sleep(2000);
	//Select Industry
	Select industry = new Select(driver.findElement(By.name("Industry")));
	industry.selectByVisibleText("Travel, Tourism and Hospitality");
	log.logging("Industry selected", "info");
	
	//Send Message
//		
//		WebElement sendmsg = driver.findElement(By.xpath("//textarea[@name='Description']"));
//		sendmsg.sendKeys("Testing the message box");
		
		
	
	//Click on captcha checkbox
//	WebElement captcha = driver.findElement(By.xpath("//div[@class='recaptcha-checkbox-checkmark']"));
//	captcha.click();
//	log.logging("Captcha Checkbox checked", "info");
//	Thread.sleep(3500);
	
	//Click on Send Button
	WebElement Send = driver.findElement(By.xpath("//button[text()='Send']"));
	Send.click();
	log.logging("Send Clicked", "info");
	
	}
	
	@Then("^User fill Channel form$")
	public void user_fill_Channel_form() throws Throwable {
	   
		//FirstName	
		 WebElement FN = driver.findElement(By.xpath("//input[@name='First_Name']"));
		 FN.sendKeys("John");
		 log.logging("First_Name filled", "info");
		 
		 //LastName
		 WebElement LN = driver.findElement(By.xpath("//input[@name='Last_Name']"));
		 LN.sendKeys("Denim");
		 log.logging("Last_Name filled", "info");
		
		
		//Phone Number
		WebElement PhNo = driver.findElement(By.xpath("//input[@name='Phone']"));
	    PhNo.sendKeys("9999999999");
	    log.logging("PhoneNo filled", "info");
		
		//Email
		WebElement Email = driver.findElement(By.xpath("//input[@name='Email']"));
		Email.sendKeys("JohnDenim@example.com");
		 log.logging("Email filled", "info");
	
		//Company Name
		WebElement CN = driver.findElement(By.xpath("//input[@name='Company']"));
		CN.sendKeys("RoundRun");
		log.logging("Company selected", "info");
		
		//Select country
		Select country = new Select(driver.findElement(By.name("Country")));
		country.selectByVisibleText("Australia");
		log.logging("Country selected", "info");
		
		Thread.sleep(2000);
		//Select Industry
		Select industry = new Select(driver.findElement(By.name("Industry")));
		industry.selectByVisibleText("Travel, Tourism and Hospitality");
		log.logging("Industry selected", "info");
		
		//Send Message
		WebElement sendmsg = driver.findElement(By.xpath("//textarea[@name='Description']"));
		sendmsg.sendKeys("Testing the message box");
			
			
		
		//Click on captcha checkbox
//		WebElement captcha = driver.findElement(By.xpath("//div[@class='recaptcha-checkbox-checkmark']"));
//		captcha.click();
//		log.logging("Captcha Checkbox checked", "info");
//		Thread.sleep(3500);
		
		//Click on Send Button
		WebElement Send = driver.findElement(By.xpath("//button[text()='Submit ']"));
		Send.click();
		log.logging("Send Clicked", "info");
		
		
	}
	
	
}
