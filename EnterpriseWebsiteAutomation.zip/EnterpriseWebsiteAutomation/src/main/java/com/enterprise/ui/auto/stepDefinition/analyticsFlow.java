package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Then;
import cucumber.api.java.it.Data;

public class analyticsFlow {
	
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	
	
	public analyticsFlow() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
	
	}
	
	
	@Then("^Navigate to Analytics summary dashboard$")
	public void navigate_to_Analytics_summary_dashboard() throws InterruptedException {
		
//		driver.findElement(By.xpath("//*[@id=\"deliveryDataDiv\"]/div[7]/a")).click();
//		log.logging("Clicking view more and navigating to Analytics Dashboard", "info");
		
		Boolean dashboard = driver.findElement(By.xpath("//*[@id=\"deliveryDataDiv\"]/div[7]/a")).isDisplayed();
		System.out.println("Value of dashboard is "+dashboard);
		
		if(dashboard) {
			driver.findElement(By.xpath("//*[@id=\"deliveryDataDiv\"]/div[7]/a")).click();
			log.logging("Clicking view more and navigating to Analytics Dashboard", "info");
		}
		else {
			
			log.logging("View more link and Analytics dashboard is not present", "info");
			
		}

	}
	
	@Then("^Check Account expiry notification$")
	public void check_Account_expiry_notification() throws InterruptedException {
		
		Boolean alert = driver.findElement(By.xpath("//*[@id=\"showAlertExpiryPopupContainer\"]/div[1]")).isDisplayed();
		if (alert = true) {
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"expiryId\"]/input")).click();
			log.logging("Account expiry notification is selected OK", "info");
		}
		else
		{
			log.logging("Account expiry notification is not displayed", "info");
		}

	}
	
	
	@Then("^Select report type as \"([^\"]*)\" and date as \"([^\"]*)\"$")
	public void select_report_type_as(String reportType, String dateType) throws InterruptedException {
		
		try {
			
			Boolean anaType = driver.findElement(By.id("analyticsType")).isDisplayed();
			System.out.println("Value of element is " +anaType);
			
			if(anaType) {
				
				Select dropdown = new Select(driver.findElement(By.id("analyticsType")));
				dropdown.selectByValue(reportType);
				
				log.logging("Report type Selected as "+reportType, "info");
				Thread.sleep(3000);
				
				driver.findElement(By.id("dateRange")).click();
				Thread.sleep(1000);
				
				if(dateType.equals("Yesterday") ) {
					
					driver.findElement(By.xpath("/html/body/div[4]/div/ul/li[1]/a[text()='Yesterday']")).click();
					Thread.sleep(2000);
				}
				else if (dateType.equals("Last 7 days")) {
					
					driver.findElement(By.xpath("/html/body/div[4]/div/ul/li[2]/a[text()='Last 7 days']")).click();
					Thread.sleep(2000);
					
				}
				else if (dateType.equals("Month to date")) {
					
					driver.findElement(By.xpath("/html/body/div[4]/div/ul/li[3]/a[text()='Month to date']")).click();
					Thread.sleep(2000);
					
				}
				else if (dateType.equals("Last 30 Days") ){
					
					driver.findElement(By.xpath("/html/body/div[4]/div/ul/li[4]/a[text()='Last 30 Days']")).click();
					Thread.sleep(2000);
					
				}
				else if (dateType.equals("The previous Month")) {
					
					driver.findElement(By.xpath("/html/body/div[4]/div/ul/li[5]/a[text()='The previous Month']")).click();
					Thread.sleep(2000);
					
				}
				
				driver.findElement(By.xpath("//*[@id=\"super-container\"]/div/div/div[1]/div[1]/div/table/tbody/tr[3]/td[2]/div/input")).click();
				Thread.sleep(10000);
				
			}else {
				log.logging("Analytics data not present", "info");
				
			}
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		
	}
	

}
