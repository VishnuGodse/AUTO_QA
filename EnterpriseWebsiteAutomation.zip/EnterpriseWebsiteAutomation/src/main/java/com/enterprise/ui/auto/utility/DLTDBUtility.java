package com.enterprise.ui.auto.utility;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.stepDefinition.Inititor;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.MessageCheckInFileUtility;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class DLTDBUtility {

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	String template_id;
	MessageCheckInFileUtility msgcheck;
	String userid;
	Map<String, String> hm;

	public DLTDBUtility() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		// locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		msgcheck = new MessageCheckInFileUtility();
		userid = env.getEnterpriseUsername();
		hm = new HashMap<String, String>();

	}

	/*
	 * @Then("^User gets db data$") public void getTemplateDbdata() throws Throwable
	 * { userid=env.getEnterpriseUsername();
	 * System.out.println("user name "+userid); Object template_db =
	 * query.getDBResponse(userid,"id", "GetTemplate"); String
	 * temp=template_db.toString(); System.out.println("template name"+temp); throw
	 * new PendingException(); }
	 */

//	@Then("^User gets db data$")
	public Map<String, String> user_gets_db_data() throws Exception {

		
		try {
			log.logging("Got user id" + userid, "info");
			Object userId = query.getDBResponse(userid, "id", "getiingUserId");
			
			//Template for normal text
	           Object template_db = query.getDBResponse(userId.toString(),"template",
			  "GetTemplate");
			   String temp=template_db.toString(); 
			   log.logging("Template name: " + temp, "info");
			   hm.put("template", temp);
			  
			 //Template id for normal text
			   Object template_id=query.getDBResponse(temp.toString(),"dltTemplateId",
			  "GetTemplateId");
			   String id=template_id.toString();
			   log.logging("Template id: " + id, "info"); 
			   hm.put("dltTemplateId", id);
			  
			 
            //Template for unicode text
			  Object template_db_unicode = query.getDBResponse(userId.toString(), "template", "GetTemplateUnicode");
			  String temp_uni = template_db_unicode.toString();
			  log.logging("Unicode template name: " + temp_uni, "info");
			  hm.put("template_unicode", temp_uni);
      
			//Template id for unicode text 
			Object template_unicode_id = query.getDBResponse(temp_uni.toString(), "dltTemplateId", "GetTemplateIdUnicode");
      		String uni_id = template_unicode_id.toString();
      		log.logging("Unicode template id: " + uni_id, "info");
			hm.put("dltTemplateId_unicode", uni_id);
			
			
			
			}
		
		
		catch(Exception e )
		{
			log.logging("Exception encountered : " + e, "info");
		}
		
		
		return hm;
		
	}

}
