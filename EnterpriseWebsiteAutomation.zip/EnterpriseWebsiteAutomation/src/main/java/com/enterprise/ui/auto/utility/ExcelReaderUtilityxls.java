package com.enterprise.ui.auto.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelReaderUtilityxls {
	public String path;
	public FileInputStream fis;
	public FileOutputStream fileOut = null;
	public File src;
	public HSSFWorkbook wb;
	public HSSFSheet sheet;
	public HSSFRow row = null;
	public HSSFCell cell = null;

	Map<String, String> dataMapping = new HashMap<String, String>();
	Map<String, String> keywordMapping = new HashMap<String, String>();

	public ExcelReaderUtilityxls(String path) throws IOException {
		this.path = path;
		src = new File(path);

		try {
			fis = new FileInputStream(src);
			wb = new HSSFWorkbook(fis);
			//wb= new HSSFWorkbook(fis);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public String getCellfromsheet(String sheetName, int row, int cell) throws IOException {

		sheet = wb.getSheet(sheetName);
		String result = (sheet.getRow(row).getCell(cell).getStringCellValue());
		// wb1.close();
		return result;
	}

	public int gettotalRowSheet(String sheetName) throws IOException {

		int count = wb.getSheet(sheetName).getLastRowNum();
		// System.out.println("No of Rows in sheet " + sheetName + " is :" + (count +
		// 1));
		return count + 1;
	}
	
	public void getAllDataSheet(String sheetName) throws IOException {
		int count = gettotalRowSheet(sheetName);
		for (int i = 0; i < count; i++) {
			String data = wb.getSheet(sheetName).getRow(i).getCell(0).getStringCellValue();
			System.out.println(data);
		}
	}
	

	@SuppressWarnings("static-access")
	public String getCellData(String sheetName, int colNum, int rowNum) {

		try {
			// wb1 = new XSSFWorkbook(fis);
			if (rowNum < 0)

				return "1111";

			int index = wb.getSheetIndex(sheetName);
			if (index == -1)
				return "";

			sheet = wb.getSheetAt(index);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				return "";
			cell = row.getCell(colNum);
			if (cell == null)
				return "";

			//
			if (cell.getCellType().name().equals("STRING"))
				return cell.getStringCellValue();

			//
			// if (cell.getCellType().STRING != null)
			// return cell.getStringCellValue();
			/*
			 * else if ((cell1.getCellType().name().equals("NUMERIC")) ||
			 * (cell1.getCellType().name().equals("FORMULA"))) {
			 * 
			 * String cellText = String.valueOf(cell1.getNumericCellValue()); if
			 * (HSSFDateUtil.isCellDateFormatted(cell1)) { // format in form of M/D/YY
			 * double d = cell.getNumericCellValue();
			 * 
			 * Calendar cal = Calendar.getInstance();
			 * cal.setTime(HSSFDateUtil.getJavaDate(d)); cellText =
			 * (String.valueOf(cal.get(Calendar.YEAR))).substring(2); cellText =
			 * cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" +
			 * cellText;
			 * 
			 * // System.out.println(cellText);
			 * 
			 * }
			 * 
			 * return cellText; }
			 */
			else if (cell.getCellType().BLANK != null)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());
		} catch (Exception e) {

			e.printStackTrace();
			return "row " + rowNum + " or column " + colNum + " does not exist  in xls";
		}
	}

	
	public String getCellDataWithHeaderwithSheetIndex (int sheetIndex, String headerName, int rowNum) throws IOException {
		if (rowNum <= 0) {
			return "";
		}
		int colNum = -1;
		int index = sheetIndex;
		//if (!isSheetExist(sheetName))
		//	return sheetName + "does not exsits";
		sheet = wb.getSheetAt(index);
		row = sheet.getRow(0);
		for (int i = 0; i < row.getLastCellNum(); i++) {
			// System.out.println(row1.getLastCellNum());
			// System.out.println(row1.getCell(i).getStringCellValue().trim());
			if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(headerName)) {
				colNum = i;
			}
		}
		if (colNum == -1) {
			return "Header Not Found";
		}
		sheet = wb.getSheetAt(index);
		row = sheet.getRow(rowNum - 1);
		if (row == null)
			return "";
		cell = row.getCell(colNum);
		if (cell == null)
			return "";
		if (cell.getCellType().name().equals("STRING"))
			return cell.getStringCellValue();
		else if (cell.getCellType().BLANK != null)
			return "";
		else
			return String.valueOf(cell.getBooleanCellValue());
	}
	
	@SuppressWarnings("unlikely-arg-type")
	public boolean setCellData(String sheetName, int colNum, int rowNum, String text) {
		try {
			if (rowNum <= 0) {
				return false;
			}
			int index = wb.getSheetIndex(sheetName);
			int colName = -1;
			if (index == -1)
				return false;
			sheet = wb.getSheetAt(index);
			row = sheet.getRow(0);
			for (int i = 0; i < row.getLastCellNum(); i++) {
				System.out.println(row.getLastCellNum());
				// System.out.println(row.getCell(i).getStringCellValue().trim());
				if (row.getCell(i).getStringCellValue().trim().equals(colName))
					colNum = i;
			}
			if (colNum == -1)
				return false;

			sheet.autoSizeColumn(colNum);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				row = sheet.createRow(rowNum - 1);

			cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum);
			cell.setCellValue(text);

			fileOut = new FileOutputStream(path);

			wb.write(fileOut);

			fileOut.close();

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	public boolean isSheetExist(String sheetName) throws IOException {

		int index = wb.getSheetIndex(sheetName);
		if (index == -1) {
			index = wb.getSheetIndex(sheetName);
			if (index == -1)
				return false;
			else
				return true;
		} else
			return true;
	}

	public int getColumnCount(String sheetName) throws IOException {
		// check if sheet exists
		if (!isSheetExist(sheetName))
			return -1;

		sheet = wb.getSheet(sheetName);
		row = sheet.getRow(0);

		if (row == null)
			return -1;

		return row.getLastCellNum();

	}

	public String getValueKeyword(String keyword, String sheetName) throws IOException {
		String result = "";

		if (!isSheetExist(sheetName))
			return sheetName + "does not exsits";

		int index = wb.getSheetIndex(sheetName);
		int count = (wb.getSheetAt(index).getLastRowNum() + 1);
		for (int i = 1; i <= count; i++) {
			String getKeyword = getCellData(wb.getSheetName(index), 0, i);
			if (getKeyword.equalsIgnoreCase(keyword)) {
				// System.out.println(getCellfromsheet(wb1.getSheetName(index), i - 1, 1));
				result = getCellfromsheet(wb.getSheetName(index), i - 1, 1);

			}
		}
		return result;
	}

	@SuppressWarnings("static-access")
	public String getCellDataWithHeader(String sheetName, String headerName, int rowNum) throws IOException {
		if (rowNum <= 0) {
			return "";

		}
		int colNum = -1;
		int index = wb.getSheetIndex(sheetName);
		if (!isSheetExist(sheetName))
			return sheetName + "does not exsits";
		sheet = wb.getSheetAt(index);
		row = sheet.getRow(0);
		for (int i = 0; i < row.getLastCellNum(); i++) {
			// System.out.println(row1.getLastCellNum());
			// System.out.println(row1.getCell(i).getStringCellValue().trim());

			if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(headerName)) {
				colNum = i;
			}
		}
		if (colNum == -1) {
			return "Header Not Found";

		}
		sheet = wb.getSheetAt(index);
		row = sheet.getRow(rowNum - 1);
		if (row == null)
			return "";
		cell = row.getCell(colNum);

		if (cell == null)
			return "";
		if (cell.getCellType().name().equals("STRING"))
			return cell.getStringCellValue();

		else if (cell.getCellType().BLANK != null)
			return "";
		else
			return String.valueOf(cell.getBooleanCellValue());

	}
	/*public String getCellDataWithHeaderwithSheetIndex (int sheetIndex, String headerName, int rowNum) throws IOException {
		if (rowNum <= 0) {
			return "";

		}
		int colNum = -1;
		int index = sheetIndex;
		//if (!isSheetExist(sheetName))
		//	return sheetName + "does not exsits";
		sheet = wb.getSheetAt(index);
		row = sheet.getRow(0);
		for (int i = 0; i < row.getLastCellNum(); i++) {
			// System.out.println(row1.getLastCellNum());
			// System.out.println(row1.getCell(i).getStringCellValue().trim());

			if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(headerName)) {
				colNum = i;
			}
		}
		if (colNum == -1) {
			return "Header Not Found";

		}
		sheet = wb.getSheetAt(index);
		row = sheet.getRow(rowNum - 1);
		if (row == null)
			return "";
		cell = row.getCell(colNum);

		if (cell == null)
			return "";
		if (cell.getCellType().name().equals("STRING"))
			return cell.getStringCellValue();

		else if (cell.getCellType().BLANK != null)
			return "";
		else
			return String.valueOf(cell.getBooleanCellValue());

	}*/

	public ArrayList<String> getAllHeader(String sheetName, int colNum) throws IOException {
		int col = getColumnCount(sheetName);
		int rowCount = gettotalRowSheet(sheetName);
		ArrayList<String> result = new ArrayList<String>();
		if (col >= colNum) {
			for (int i = colNum; i <= colNum; i++) {
				String header = getCellData(sheetName, i, 1);
				for (int j = 1; j <= rowCount; j++) {
					result.add(getCellDataWithHeader(sheetName, header, j));
				}
			}
		} else
			System.out.println(colNum + "Column Not valid");
		return result;
	}

	public Map<String, String> mappedData(String sheetName, int colNum) throws IOException {
		ArrayList<String> field = getAllHeader(sheetName, 0);
		ArrayList<String> data = getAllHeader(sheetName, colNum);
		int size = field.size();
		for (int i = 0; i < size; i++) {
			dataMapping.put(field.get(i), data.get(i));
		}
		return dataMapping;
	}

	public Map<String, String> getKeywordMapping(String sheetName) throws IOException {
		ArrayList<String> fieldName = getAllHeader(sheetName, 0);
		ArrayList<String> keyId = getAllHeader(sheetName, 1);
		int size = fieldName.size();

		for (int i = 0; i < size; i++) {
			keywordMapping.put(keyId.get(i), fieldName.get(i));

		}
		return keywordMapping;

	}

	public String getKeyElementName(String key, String sheetName) throws IOException {
		String result = null;
		getKeywordMapping(sheetName);
		result = keywordMapping.get(key);

		return result;
	}

	public String getTestDataForElement(String elementName, String sheetName, int colNum) throws IOException {
		String result = null;
		int colcnt = getColumnCount(sheetName);
		if (colNum > colcnt) {
			result = "Column No " + colNum + "does not exist";
		} else
			mappedData(sheetName, colNum);
		result = dataMapping.get(elementName);
		return result;

	}

	/* public static void main(String[] args) throws IOException {
	ExcelReaderUtilityxls er = new ExcelReaderUtilityxls("/home/rahul/bulk_upload_files/live_testing/aryacase.xls");
//System.out.println(er.getCellData("Quries", 0, 2));
	System.out.println(er.getAllHeader("aryacase", 1));
	*/
	
	// String elementName =er.getKeyElementName("defaultMsg", "KeywordMapping");
	// System.out.println(er.getTestDataForElement(elementName, "TestData",2));

	// }

}
