/**
 * 
 */
package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.Bo.EnvRedisBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.RedisUtility;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.lambdaworks.redis.RedisClient;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

/**
 * @author Rahul Jain
 *
 */
public class TwoFactorAuthFlow {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	ExecuteQuery query;
	public EnvRedisBO redis;
	String enterpriseAccId;
	String enterpriseAccPass;
	String otpPhNo;
	String otpemailId;
	Object userId;
	RedisUtility  ru;

	public TwoFactorAuthFlow() throws IOException, InterruptedException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		query = new ExecuteQuery();
		enterpriseAccId = env.getEnterpriseAccountId();
		enterpriseAccPass = env.getEnterprisePassword();
		redis = new EnvRedisBO("2FA");
		otpPhNo=env.getOtpPhoneNo();
		otpemailId=env.getOtpEmailId();
		userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
		ru = new RedisUtility();
		

	}

	@Given("^Enable OTP for the account$")
	public void enable_OTP_for_the_account() throws IOException, InterruptedException {
		log.logging("Enable OTP for Users", "info");
		log.logging("Deleting the Attibute for OTP ", "info");
		query.setDBResponse("deleteOTPAttribute", userId.toString());
		log.logging("Enable the Attibute for OTP ", "info");
		query.setDBResponse("enableOTPAttribute", userId.toString());

	}

	@Then("^Set PhoneNo for OTP for the account$")
	public void set_PhoneNo_for_OTP_for_the_account() throws Throwable {
		log.logging("Setting Phone No from Config", "info");
		log.logging("Deleting the Attibute for PhoneNo ", "info");
		query.setDBResponse("deletePhoneNoAttibute", userId.toString());
		log.logging("Setting the Attibute for PhoneNo ", "info");
		query.setDBResponse("insertPhoneNoAttibute", userId.toString(),otpPhNo);

	}

	@Then("^Set SMS OTP for the account$")
	public void set_SMS_OTP_for_the_account() throws Throwable {
		log.logging("Deleting the Attibute for SMS/Email Flag ", "info");
		query.setDBResponse("EmailSmsFlagDelete", userId.toString());
		log.logging("Setting the Attibute for SMS ", "info");
		query.setDBResponse("EnableSmsFlag", userId.toString());
		Thread.sleep(5000);

	}

	@Then("^select the phoneNo$")
	public void select_the_phoneNo() throws Throwable {
		Thread.sleep(5000);
		log.logging("Selecting Phone No from Drop Down ", "info");

		WebElement phoneno = driver.findElement(By.id("contactNumberSelect")); 
		new Select(phoneno).selectByIndex(1);
	}

	@Then("^click on recieve OTP$")
	public void click_on_recieve_OTP() throws Throwable {
		log.logging("Clicking on Recieve OTP", "info");
		driver.findElement(By.id("loginBtnId")).click();
	}

	@Then("^fetch OTP from redis and put it and submit$")
	public void fetch_OTP_from_redis_and_put_it_and_submit() throws Throwable {
		log.logging("Fetching from Redis", "info");
		Thread.sleep(7000);

		String otp = ru.getDatafromRedis(redis.getRedisIp(), redis.getRedisPort(), "hget", userId.toString()+":"+otpPhNo, "o",redis.getRedisPass());
		log.logging("Got Otp from Redis : "+ otp, "info");
		driver.findElement(By.id("otpId")).sendKeys(otp);
		driver.findElement(By.id("loginBtnId")).click();
		Thread.sleep(5000);
		
	}

	@Then("^we will landed on Dashboard$")
	public void we_will_landed_on_Dashboard() throws Throwable {
		log.logging("Verify Dashboard Element", "info");
		String dashboard = driver.findElement(By.className("ms-page-heading")).getText();
		Assert.assertEquals(dashboard, "Dashboard");
	}
	@Then("^disable OTP for tha account$")
	public void disable_OTP_for_tha_account() throws IOException  {
		log.logging("Enable OTP for Users", "info");
		log.logging("Deleting the Attibute for OTP ", "info");
		query.setDBResponse("deleteOTPAttribute", userId.toString());
		log.logging("Disabling  the Attibute for OTP ", "info");
		query.setDBResponse("disableOTPAttribute", userId.toString());

	}
	@Then("^Set Email OTP for the account$")
	public void set_Email_OTP_for_the_account() throws IOException, InterruptedException {
		log.logging("Deleting the Attibute for SMS/Email Flag ", "info");
		query.setDBResponse("EmailSmsFlagDelete", userId.toString());
		log.logging("Setting the Attibute for Email ", "info");
		query.setDBResponse("EnableEmailFlag", userId.toString());
		Thread.sleep(5000);
	}

	@Then("^fetch OTP from redis and put it and submit for email$")
	public void fetch_OTP_from_redis_and_put_it_and_submit_for_email() throws InterruptedException  {
		Thread.sleep(5000);
		log.logging("Fetching from Redis", "info");
		String otp = ru.getDatafromRedis(redis.getRedisIp(), redis.getRedisPort(), "hget", userId.toString()+":"+otpemailId, "o",redis.getRedisPass());
		log.logging("Got Otp from Redis : "+ otp, "info");
		driver.findElement(By.id("otpId")).sendKeys(otp);
		driver.findElement(By.id("loginBtnId")).click();
		Thread.sleep(5000);
	}
	@Then("^Set Email for OTP for the account$")
	public void set_Email_for_OTP_for_the_account() throws IOException  {
		log.logging("Setting EmailId from Config", "info");
		log.logging("Deleting the Attibute for EmailId ", "info");
		query.setDBResponse("deleteEmailIdAttibute", userId.toString());
		log.logging("Setting the Attibute for EmailId ", "info");
		query.setDBResponse("insertEmailAttibute", userId.toString(),otpemailId);
	}

	@Then("^select the Email$")
	public void select_the_Email() throws InterruptedException {
		Thread.sleep(5000);
		log.logging("Selecting Email Id from Drop Down ", "info");
		WebElement phoneno = driver.findElement(By.id("contactNumberSelect")); 
		new Select(phoneno).selectByIndex(1); 


	}
}
