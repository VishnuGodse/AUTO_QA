package com.enterprise.ui.auto.stepDefinition;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExcelReaderUtility;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.MessageCheckInFileUtility;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Whatsapp_BulkPostFlow {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	ExecuteQuery query;
	String htid =null;
	String aggrAccId = null;
	String ERRORMESSAGE=null;
	ExcelReaderUtility fileread;
	GeneralUtlities gu;
MessageCheckInFileUtility mu;
	
	static String repoPath = "resources/Locators/Whatsup.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	
	public Whatsapp_BulkPostFlow() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		query = new ExecuteQuery();
		sa = new SoftAssert(); 
		gu = new GeneralUtlities();
		String username = gu.getSysDetail("username");
		String out = "C:\\Users\\" + username.toLowerCase() + "\\Downloads";
		fileread = new ExcelReaderUtility(out);
		mu = new MessageCheckInFileUtility();
	}
	
	

	//CHECK WHATSAPP TAB ON WEBSITE
	@Then("^Check the Sub Tab of WhatsApp Tab Bulk$")
	public void check_the_Sub_Tab_of_WhatsApp_Tab_Bulk() throws InterruptedException {
		Thread.sleep(2000);
		
		log.logging("Verifying  Sub Tab of WhatsApp Tab Bulk", "info");
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Bulk", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");	
		
	}
	
	
	
	//FOR FALLBACK AS SMS
		@Then("^Updating the fallback as SMS$")
		public void Updating_the_fallback_as_SMS() throws IOException, InterruptedException {
			aggrAccId = env.getEnterpriseUsername();
			//System.out.println("got the userId"+aggrAccId);
			log.logging("Got user id" + aggrAccId,"info");
			Object userId = query.getDBResponse(aggrAccId, "id", "getiingUserId");
			//System.out.println(userId);
			log.logging("USERID" + userId,"info");
			boolean result = query.setDBResponse("setFallbackSMS", userId.toString());
			log.logging("Fallback SMS Result" + result, "info");
			if (result == true) {
				
				log.logging("Inserting fallback SMS for the user" + userId + " setting value as SMS",
						"info");

				query.setDBResponse("InsertFallbackSMS", userId.toString());
			}

			Thread.sleep(5000);
			su.refreshPage();
		}
		
		//FOR FALLBACK AS DATA_TEXT
		@Then("^Updating the fallback as DATATEXT$")
		public void Updating_the_fallback_as_DATATEXT() throws IOException, InterruptedException {
			aggrAccId = env.getEnterpriseUsername();
			log.logging("Got user id" + aggrAccId,"info");
			Object userId = query.getDBResponse(aggrAccId, "id", "getiingUserId");
			//System.out.println(userId);
			log.logging("USERID" + userId,"info");
			boolean result = query.setDBResponse("setFallbackDATA_TEXT", userId.toString());

			if (result == true) {
				
				log.logging("Inserting fallback DATA_TEXT for the user" + userId + " setting value as DATA_TEXT",
						"info");

				query.setDBResponse("InsertFallbackDATA_TEXT", userId.toString());
			}

			Thread.sleep(5000);
			su.refreshPage();
		}
		
		
				//FOR FALLBACK AS FAIL
				@Then("^Updating the fallback as FAIL$")
				public void Updating_the_fallback_as_FAIL() throws IOException, InterruptedException {
					aggrAccId = env.getEnterpriseUsername();
					//System.out.println("got the userId"+aggrAccId);
					log.logging("Got user id" + aggrAccId,"info");
					Object userId = query.getDBResponse(aggrAccId, "id", "getiingUserId");
					System.out.println(userId);
					log.logging("USERID" + userId,"info");
					boolean result = query.setDBResponse("setFallbackFAIL", userId.toString());

					if (result == false) 
					{
						log.logging("Inserting fallback FAIL for the user" + userId + " setting value as FAIL",
								"info");
						query.setDBResponse("InsertFallbackFAIL", userId.toString());
					}

					Thread.sleep(5000);
					su.refreshPage();
				}
	

	
	//CHECKING ALL THE TABS IMAGE VIDEO & DOCUMENT
	@Then("^Check Image tab$")
	public void check_Image_tab() throws InterruptedException  {
		log.logging("Verifying Image Tab", "info");
		Thread.sleep(2000);
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Bulk-Image", locator);
		driver.findElement(b1).click();
		 WebElement textconfirm = driver.findElement(By.xpath("//div[@id='imageHeader']/*[contains(text(),'Select Image file to be sent to user (if common file for all users)')]"));
		  Assert.assertEquals(true, textconfirm.isDisplayed());
		Thread.sleep(3000);
	}
	
	@Then("^Check Document tab$")
	public void Check_Document_tab() throws InterruptedException  {
		log.logging("Verifying Document Tab", "info");
		Thread.sleep(2000);
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Bulk-Document", locator);
		driver.findElement(b1).click();
		WebElement textconfirm = driver.findElement(By.xpath("//div[@id='documentHeader']"));
		Assert.assertEquals(true, textconfirm.isDisplayed());
		Thread.sleep(3000);
	}
	
	@Then("^Check Video tab$")
	public void Check_Video_tab() throws InterruptedException  {
		log.logging("Verifying Video Tab", "info");
		Thread.sleep(2000);
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Bulk-Video", locator);
		driver.findElement(b1).click();
		WebElement textconfirm = driver.findElement(By.xpath("//div[@id='videoHeader']"));
		Assert.assertEquals(true, textconfirm.isDisplayed());
		Thread.sleep(3000);
	}
	
	//END OF TABS CHECK
	
	
	
	//FOR CUSTOM MEDIA RADIO BUTTON
		@Then("^User clicks on custom each radio button$")
		public void User_clicks_on_custom_each_radio_button() throws InterruptedException
		{
			 log.logging("Select radio button", "info");
			 By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Image-Each-Radio", locator);
			 driver.findElement(b1).click();
		     
		}
		
		
		
	//TO ENTER THE URL IN EACH TABS(IMAGEURL,DOCURL,VIDEOURL)	
		@Then("^User enters valid URL$")
		public void user_enters_valid_URL(DataTable files) throws Throwable 
		{
			for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
				
				
			     log.logging("click on choose file", "info");
				String URL = fileUpload.get("URL_LINK");

				log.logging("Passing the URL: " + URL, "info");
				//String URLL = System.getProperty() + URL;
				By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Bulk-URL-LINK", locator);
				driver.findElement(b1).sendKeys(URL);
				Thread.sleep(5000);

				
			}
     	 }
		
	
	//UPLOADING APPROPRIATE FILE
	@Then("^User clicks on choose file and uploads$")
	public void User_clicks_on_choose_file_and_uploads(DataTable files) throws InterruptedException, AWTException
	{
		
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
			
		     log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFiles/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			
//			WebElement duplicatechckbox= driver.findElement(By.xpath("//input[@id='quickPostCheckDuplicatesCheckbox']"));
//			duplicatechckbox.click();
//			log.logging("uncheck duplicates checkbox", "info");
		}
		
	}
	
	
	
	//SELECTION OF TEMPLATE FOR EACH MEDIA
		@Then("^User Select Template \"([^\"]*)\"$")
		public void user_Select_Template(String Element) throws Throwable {

			Thread.sleep(2000);
			By b1=PropertiesFileReader.getPropertylocator("repoPath",Element, locator);
			log.logging("Switch to alert pop-up", "info");
			By b2=PropertiesFileReader.getPropertylocator("repoPath","WhatsApp-Image-Click-on-Template", locator);

			driver.findElement(b2).click();
			driver.findElement(b1).click();
			log.logging("Select a Template", "info");
			
			
			
			//driver.findElement(By.xpath("//input[@name='buttonUrlParam']")).sendKeys("https://abc.com");
			try {
			if(driver.findElement(By.xpath("//input[@name='buttonUrlParam']")).isDisplayed()) 
			{
				//WebElement dynamic_url = driver.findElement(By.xpath("//input[@name='buttonUrlParam']"));
				driver.findElement(By.xpath("//input[@name='buttonUrlParam']")).sendKeys("https://abc.com");
				//Assert.assertEquals(true, dynamic_url.isDisplayed());
				log.logging("Dynamic URL Found", "info");
//				WebElement e1 = driver.findElement(By.xpath("//input[@class='tbButton'][@name='button'][@value='OK']"));
//				e1.click();
			}
			
			}catch(Exception e){}
		
			finally {
				WebElement e1 = driver.findElement(By.xpath("//input[@class='tbButton'][@name='button'][@value='OK']"));
				e1.click();
		
				log.logging("click on ok button", "info");
				}
			
			Thread.sleep(5000);
		}
	
	//CLICK ON THE UPLOAD FILE BUTTON
	@Then("^User clicks on btn upload and post$")
	public void User_clicks_on_btn_upload_and_post() throws InterruptedException
	{
		
		
		Thread.sleep(2000);
		log.logging("Click on upload and Post button", "info");
		 WebElement postbtn=driver.findElement(By.xpath("//input[@id='uploadDocButton']"));
	
		 
		 String btn1 = postbtn.getText();
		 if(btn1.equalsIgnoreCase("Upload And Post"))
		 {
			 postbtn.click();
		 }
		 else if(btn1.equalsIgnoreCase(" Upload and Post Button Messages")) 
		 {
			 postbtn.click();
		 }
		 //System.out.println("Upload and post element found");
		 log.logging("Upload and post element found", "info");
		 postbtn.click();
		 //System.out.println("Upload and post element click");
		 log.logging("Upload and post element click", "info");
		 WebElement notify = driver.findElement(By.id("notification"));
		 Assert.assertEquals(true, notify.isDisplayed());
		
	}	

	
		
	//CHECK AND UNCHECK THE INTERACTIVE CHECKBOX
	@Then("^User checks on send interactive button$")
	public void user_checks_on_send_interactive_button() throws Throwable {
	
	WebElement Interactivebtn = driver.findElement(By.xpath("//input[@id='isTemplateCheckbox']"));
	Interactivebtn.click();
	log.logging("Check the Interactive button", "info");
	
	if(Interactivebtn.isEnabled()) 
	{
		log.logging("Interactive checkbox is checked", "info");
	}
	else 
	{
		log.logging("Interactive checkbox is not checked", "info");
	}
	
	WebElement UPBtnText = driver.findElement(By.xpath("//input[@id='uploadDocButton']"));
	String UPText = UPBtnText.getText();
		
	if(UPText.equalsIgnoreCase("Upload and Post")) 
	{
		log.logging("Upload Button Not Changed", "info");
	}
	else 
	{
		log.logging("Upload Button is Changed", "info");
	}
}

	
	//USER CLICKS ON DOWNLOAD RESPONSE
	@Then("^User Clicks on download response$")
	public void User_Clicks_on_download_response() throws Throwable 
	{
		Thread.sleep(6000);
		su.refreshPage();
		WebElement downloadbtn = driver.findElement(By.xpath("//tbody/tr[1]/td[5]//a[text()='Download']"));
		log.logging("Download Response Button Found", "info");
		
		downloadbtn.click();
		log.logging("Download Response Button Clicked", "info");
		
	}
	

	@Then("^Check Response file \"([^\"]*)\"$")
	public void check_Response_file(String ERRORMSG) throws Throwable {
		//readfromfile("C:\\Users\\swapnil.kudalkar\\Downloads",ERRORMESSAGE);
		Thread.sleep(5000);
		String ERRRMSG = fileread.getCellfromsheet("response sheet",3,1);
		log.logging("ERRORMSG" + ERRRMSG, "info");
		Thread.sleep(5000);
		if(!ERRRMSG.equalsIgnoreCase(ERRORMSG))
		{
		log.logging("ERRORMSg" + ERRRMSG, "info");
		
		}
	}
	
	
	
	
/*	//CHECK DATABASE STATUS (WEBAROO,HTID,IDT)
	@Then("^Check DB status WebrooNo \"([^\"]*)\" and Htid \"([^\"]*)\" and idt \"([^\"]*)\"$")
	public void check_DB_status_WebrooNo_and_Htid(String WebrooNo, String Htid , String IDT ) throws Throwable {
		
		
		
		
		Thread.sleep(3000);
		String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
			.getText();
		log.logging("response" + response, "info");
		System.out.println(response);
		String causeId = response.replaceAll("[^0-9]", "").trim();
		log.logging("Got CauseId : " + causeId, "info");
		
		//Status
		Object status = query.getDBResponse(causeId, "status", "gettingMsgLog");
		log.logging("Got Post Status   : " + status, "info");
		Assert.assertEquals(status.toString(), "DISPATCHED");
		
		
		Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
		
		//idt
		log.logging(metadata.toString(), "debug");
		boolean idtNo = metadata.toString().contains("idt"+IDT);
		System.out.print(idtNo);
		log.logging(String.valueOf(idtNo), "debug");
		//log.logging("Matching idt is 1", "info");
		if(idtNo == true)
		{
			sa.assertEquals(idtNo, true, "Matched");
		}
		else
		{sa.assertEquals(idtNo, false, "Not Matched");}
		
//		//htid
		boolean htidNo = metadata.toString().contains("htid="+Htid);
		log.logging(String.valueOf(htidNo), "debug");
		log.logging("Matching htidNo is " + Htid, "info");
		sa.assertEquals(htidNo, true, "htidNo Not Matched");
		
		//WebarooNo
		//String wbNo="19";
		Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
				"gettingMsgLog");
		String[] wNo = webarooNo.toString().split(",");
		log.logging("Checking Webaroo No as : " + WebrooNo, "info");
		log.logging("Got Webaroo No " + wNo[1].trim(), "info");

		sa.assertEquals(wNo[1].trim(), WebrooNo);
		//sa.assertEquals(wNo[1].trim(), "0");
	
		log.logging("Assert " + WebrooNo, "info");
		sa.assertAll();
	}*/
	
	
//	public boolean FileContainsErrorMessage(String filepath) throws IOException {
//				boolean result = false;
//				if ((filepath.contains(".xls"))) {
//					File folder = new File(filepath);
//					File[] listOfFiles = folder.listFiles();
//					System.out.println(listOfFiles[0].toString());
//					BufferedReader reader = new BufferedReader(new FileReader(listOfFiles[0]));
//					String line = Files.readAllLines(Paths.get(listOfFiles[0].toString())).get(0);
//					if (line.contains("ERROR MESSAGE")) {
//						result = true;
//						
//					} else
//						result = false;
//				}
//					return result;
//				}
	
	public void readfromfile(String outpath,int row,int cell) throws IOException
	{
		if ((outpath.contains(".xls"))) {
			File folder = new File(outpath);
			File[] listOfFiles = folder.listFiles();
			String filename = listOfFiles[listOfFiles.length-1].toString();
		
			File file =    new File(filename);
	        FileInputStream inputStream = new FileInputStream(file);
	        HSSFWorkbook wb=new HSSFWorkbook(inputStream);
	        HSSFSheet sheet=wb.getSheet("response sheet");
	        HSSFRow row1=sheet.getRow(row);
	        HSSFCell cell3=row1.getCell(cell);
	        String Message= cell3.getStringCellValue();
	        log.logging("ERROR MESSAGE CELL FOUND", Message);
        
//        if(!Message.isEmpty())
//        {
//        	 HSSFRow row2=sheet.getRow(row);
//             HSSFCell cell2=row2.getCell(cell);
//             String ErrorMessage= cell2.getStringCellValue();
//             log.logging("ERROR MESSAGE is", ErrorMessage);
//            
//        }
//        
		}
	}
	
	
	@Then("^Check Response file$")
	public void check_Response_file() throws Throwable {
		  Thread.sleep(2000);
	
		  String message ="The parameter "+'"'+"media_url"+'"'+" is required. Please resend request.";
		  String message2 = "The parameter " +'"'+ "template_id/caption" +'"'+ " is required. Please resend request.";
		  String message3 = "This mobile number";
		  
		  String failmessage="Message does not match WhatsApp HSM template.";  
		  String filepath =null;
		  String dirName = "C:\\Users\\" + gu.getSysDetail("username").toLowerCase() + "\\Downloads";
		  File dir = new File(dirName);
		  File[] files = dir.listFiles();
		  try {
		  File lastModifiedFile = files[0];
		    for (int i = 1; i < files.length; i++) {
		       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
		           lastModifiedFile = files[i];
		       }
		    }
		    filepath = lastModifiedFile.toString();
		  }catch(Exception ex) {}
		    
		      log.logging("Full Path of file: " + filepath, "info");
			  String pout = System.getProperty("user.dir") + "/Download/";
			  String result = mu.checkFileError(filepath,pout);
			  log.logging("Error Message: " + result , "info");
			  
			 // log.logging("optmessage" + optmessage, "info");
			  if(result.contains(message)) 
			  {
				 log.logging("Media URL not specified","info"); 
			  }
			  else if(result.contains(failmessage)) 
			  {
				 log.logging("FallBack as fail","info"); 
			  }
			  else if(result.contains(message2)) 
			  {
				 log.logging("Caption Not specified","info"); 
			  
			  }
			  else if(result.contains(message3)) 
			  {
				 log.logging("Number is opted in","info"); 
			  }
	
		  	
}
	
}
