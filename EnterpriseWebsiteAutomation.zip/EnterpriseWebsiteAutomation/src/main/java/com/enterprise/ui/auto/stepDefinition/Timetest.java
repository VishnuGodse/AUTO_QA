package com.enterprise.ui.auto.stepDefinition;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Timetest {
	
	public static void main(String args[])
	{
		Date date = new Date();  
        //Timestamp ts=new Timestamp(date.getTime()); 
		System.out.println(date.getTime());
        Timestamp ts=new Timestamp(date.getTime()); 
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm");  
        System.out.println(formatter.format(ts));
        String dt=formatter.format(ts);
        String filename=System.getProperty("user.dir") + "\\Downloads\\" + "Upload_"+dt;
        System.out.println("FOlder"+filename);
	}

}
