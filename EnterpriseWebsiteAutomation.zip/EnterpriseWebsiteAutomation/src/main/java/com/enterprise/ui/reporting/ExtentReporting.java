package com.enterprise.ui.reporting;

import java.io.File;
import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.enterprise.ui.auto.utility.Screenshot;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.google.common.base.Utf8;

import cucumber.api.Scenario;

public class ExtentReporting  extends SeleniumUtility{
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public static ExtentTest scenarioDef;
	public static ExtentTest features;

	

	public void  ExtentReports() {
		String reportLocation = System.getProperty("user.dir") + "/Reports"; 
		reporter = new ExtentHtmlReporter(new File(reportLocation));
		reporter.config().setDocumentTitle("White Label Aggregator Report");
		reporter.config().setEncoding("utf-8");
		reporter.config().setReportName("White Label Aggregator Report");

		extent = new ExtentReports();
		extent.attachReporter(reporter);
		
	}

	
/*	public void createTest(Scenario scenario, String screenShotFileName) throws IOException {

		if (scenario != null) {
			String testName = getScenarioTitile(scenario);

			if (scenario.getStatus().equalsIgnoreCase("PASSED")) {
				extentReport.createTest(testName).pass("Passed");
			} else if (scenario.getStatus().equalsIgnoreCase("FAILED"))
				extentReport.createTest(testName).fail("Failed")
						.addScreenCaptureFromPath(getScreenShotPath(screenShotFileName));
			else {

				extentReport.createTest(testName).skip("Skipped");
			}
		}
	}*/

	public void writetoReport() {
		if (extent != null) {
			extent.flush();
		}

	}
	
	public void getScreenShot() throws IOException {
		Screenshot sc = new Screenshot();
		sc.getScreenShot(driver, features.toString());
	}

/*	public String getScreenShotPath(String location) {
		return location;

	}

	private String getScenarioTitile(Scenario scenario) {
		return scenario.getName().replaceAll(" ", "");
	}
*/
}
