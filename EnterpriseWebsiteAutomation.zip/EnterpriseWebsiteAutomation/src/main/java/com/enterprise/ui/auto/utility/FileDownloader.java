package com.enterprise.ui.auto.utility;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.WebElement;

public class FileDownloader 
{
	private String localDownloadPath;
	
	private boolean followRedirects = true;
	
	private int httpStatusOfLastDownloadAttempt = 0;
	
	public FileDownloader(String downloadPath) 
    {
		this.localDownloadPath = downloadPath;
    }
	public void followRedirectsWhenDownloading(boolean value) 
    {
        this.followRedirects = value;
    }
	public String localDownloadPath() 
    {
        return this.localDownloadPath;
    }
	public void localDownloadPath(String filePath) 
    {
        this.localDownloadPath = filePath;
    }
	public String downloadFile(WebElement element) throws Exception 
    {
        return downloader(element, "href");
    }
	public int getHTTPStatusOfLastDownloadAttempt() 
    {
        return this.httpStatusOfLastDownloadAttempt;
    }
	
    private String downloader(WebElement element, String attribute) throws IOException, NullPointerException, URISyntaxException 
    {
    	String fileToDownloadLocation = element.getAttribute(attribute);
    	if (fileToDownloadLocation.trim().equals("")) throw new NullPointerException("The element you have specified does not link to anything!");
    	URL fileToDownload = new URL(fileToDownloadLocation);
    	File downloadedFile = new File(this.localDownloadPath + fileToDownload.getFile().replaceFirst("/|\\\\", ""));
    	if (downloadedFile.canWrite() == false) 
        downloadedFile.setWritable(true);
    	
    	HttpClient client = HttpClientBuilder.create().build();
    	
    	RequestConfig new_config = RequestConfig.custom().setRedirectsEnabled(this.followRedirects).build();
        HttpGet request = new HttpGet(fileToDownload.toURI()); 
        request.setConfig(new_config);
        System.out.println("Sending GET request for: " + request.getURI());
        
        HttpResponse response = client.execute(request);
        
        this.httpStatusOfLastDownloadAttempt = response.getStatusLine().getStatusCode();
        System.out.println("HTTP GET request status: " + this.httpStatusOfLastDownloadAttempt);
        
        System.out.println("Downloading file: " + downloadedFile.getName());
        FileUtils.copyInputStreamToFile(response.getEntity().getContent(), downloadedFile);
        response.getEntity().getContent().close();
        
        String downloadedFileAbsolutePath = downloadedFile.getAbsolutePath();
        System.out.println("File downloaded to '" + downloadedFileAbsolutePath + "'");
  
        return downloadedFileAbsolutePath;
    }
    
    public int getURLStatusCode(String url) throws URISyntaxException, ClientProtocolException, IOException
    {
    	URL linkURL = new URL(url);
    	HttpClient client = HttpClientBuilder.create().build();
    	
    	RequestConfig new_config = RequestConfig.custom().setRedirectsEnabled(this.followRedirects).build();
        HttpGet request = new HttpGet(linkURL.toURI()); 
        request.setConfig(new_config);
        System.out.println("Sending GET request for: " + request.getURI());
        HttpResponse response = client.execute(request);
        return response.getStatusLine().getStatusCode();
    }
}
