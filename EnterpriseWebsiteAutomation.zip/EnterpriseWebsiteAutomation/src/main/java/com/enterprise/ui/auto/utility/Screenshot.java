package com.enterprise.ui.auto.utility;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;





	public class Screenshot extends SeleniumUtility {
		static PropRead pr;
		static String screenShotLoaction;



		public static String getScreenShot(WebDriver driver, String screenshotName) throws IOException {
			pr = new PropRead();
			screenShotLoaction = pr.readConfig("ScreenShotPath", "resources/config.properties");
			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			// String destination = System.getProperty("user.dir") + "/Reports/Screenshots/"
			// + screenshotName + dateName
			// + ".png";
			String destination = "."+screenShotLoaction + screenshotName + dateName + ".png";
			File finaldestinal = new File(destination);
			FileUtils.copyFile(source, finaldestinal);
			// dataMethod.setScreenshotPath(destination.getAbsolutePath());
			return destination;

		}

	}



