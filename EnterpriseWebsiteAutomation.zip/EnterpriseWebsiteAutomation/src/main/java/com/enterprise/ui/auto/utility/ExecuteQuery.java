package com.enterprise.ui.auto.utility;

import java.io.IOException;

import org.json.JSONArray;






public class ExecuteQuery {
	DbConnectionUtility db;
	ExcelReaderUtility read;
	PropRead pr;
	public String querySheet;
	ReportingLogging log;
	public RegexClass reg;
	JSONArray ja;
	public JsonUtility json;




public ExecuteQuery() throws IOException {
	db= new DbConnectionUtility();
	pr = new PropRead();
	String path = pr.readConfig("TestDataExcel", "resources/config.properties");
	read = new ExcelReaderUtility(path);
	querySheet = "Quries";
	log = new ReportingLogging();
	reg = new RegexClass();
	ja = new JSONArray();
	json = new JsonUtility();


	
	
}
public Object getDBResponse(String reqId, String elemFetch, String queryName) throws IOException, InterruptedException {
	// System.out.println(reqId + "from the method");
	Object result = null;
	for (int p = 0; p <= read.gettotalRowSheet(querySheet); p++) {
		String queryname = read.getCellData(querySheet, 0, p);
		if (queryname.equalsIgnoreCase(queryName)) {
			String queryfromData = read.getCellDataWithHeader(querySheet, "Query", p);
			String dbName = read.getCellDataWithHeader(querySheet, "DBName", p);
			String port = read.getCellDataWithHeader(querySheet, "Port", p);
			
			log.logging(reqId, "debug");

			String query = reg.queryVariableReplace(queryfromData, reqId);
			log.logging(query, "info");

			db = new DbConnectionUtility();

			// System.out.println(db.dbReadConnetion(dbName, query, port));
			ja = new JSONArray();
			Thread.sleep(25000);
			ja = db.dbReadConnetion(dbName, query, port);
			result = json.getKey(ja, elemFetch);
			if (result == null) {
				int i = 1;
				while (i <= 3) {
					log.logging("DB Tuple Not Found Retrying for "+ i +" time", "info");
					ja = db.dbReadConnetion(dbName, query, port);
					result = json.getKey(ja, elemFetch);
					Thread.sleep(20000);
					i++;
					result = "Not Found";
				}

			}
		}
	}
	return result;
}
public Object getDBResponse(String reqId,String reqId1, String elemFetch, String queryName) throws IOException, InterruptedException {
	// System.out.println(reqId + "from the method");
	Object result = null;
	for (int p = 0; p <= read.gettotalRowSheet(querySheet); p++) {
		String queryname = read.getCellData(querySheet, 0, p);
		if (queryname.equalsIgnoreCase(queryName)) {
			String queryfromData = read.getCellDataWithHeader(querySheet, "Query", p);
			String dbName = read.getCellDataWithHeader(querySheet, "DBName", p);
			String port = read.getCellDataWithHeader(querySheet, "Port", p);
			
			log.logging(reqId, "debug");

			String query = reg.queryVariableReplace(queryfromData, reqId,reqId1);
			log.logging(query, "info");

			db = new DbConnectionUtility();

			// System.out.println(db.dbReadConnetion(dbName, query, port));
			ja = new JSONArray();
			Thread.sleep(25000);
			ja = db.dbReadConnetion(dbName, query, port);
			//log.logging(ja.toString() + "Rahulllllllllllllllllllllllllll", "info");
			//log.logging(ja.toString(), "info");

			result = json.getKey(ja, elemFetch);
			if (result == null) {
				int i = 1;
				while (i <= 3) {
					log.logging("DB Tuple Not Found Retrying for "+ i +" time", "info");
					ja = db.dbReadConnetion(dbName, query, port);
					result = json.getKey(ja, elemFetch);
					Thread.sleep(20000);
					i++;
					result = "Not Found";
				}

			}
		}
	}
	return result;
}
public boolean setDBResponse(String queryName, String reqId1,String reqId2) throws IOException {
	boolean result = true;
	for (int p = 0; p <= read.gettotalRowSheet(querySheet); p++) {
		String queryname = read.getCellData(querySheet, 0, p);
		if (queryname.equalsIgnoreCase(queryName)) {
			String queryfromData = read.getCellDataWithHeader(querySheet, "Query", p);
			String dbName = read.getCellDataWithHeader(querySheet, "DBName", p);
			String port = read.getCellDataWithHeader(querySheet, "Port", p);
			log.logging(reqId1, "debug");

			String query = reg.queryVariableReplace(queryfromData, reqId1,reqId2);
			log.logging(query, "info");

			db = new DbConnectionUtility();

			// System.out.println(db.dbReadConnetion(dbName, query, port));
			result = db.dbInsertionUpdation(dbName, query, port);
		}
	}
	return result;
}

public boolean setDBResponse(String queryName, String reqId) throws IOException {
	boolean result = true;
	for (int p = 0; p <= read.gettotalRowSheet(querySheet); p++) {
		String queryname = read.getCellData(querySheet, 0, p);
		if (queryname.equalsIgnoreCase(queryName)) {
			String queryfromData = read.getCellDataWithHeader(querySheet, "Query", p);
			String dbName = read.getCellDataWithHeader(querySheet, "DBName", p);
			String port = read.getCellDataWithHeader(querySheet, "Port", p);
			log.logging(reqId, "debug");

			String query = reg.queryVariableReplace(queryfromData, reqId);
			log.logging(query, "info");

			db = new DbConnectionUtility();

			// System.out.println(db.dbReadConnetion(dbName, query, port));
			result = db.dbInsertionUpdation(dbName, query, port);
		}
	}
	return result;
}
}
