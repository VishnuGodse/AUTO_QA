package com.enterprise.ui.auto.stepDefinition;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.DbConnectionUtility;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.sun.mail.iap.Response;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class GroupPost {
	// String balance;

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String enterpriseAccId;
	SoftAssert sa;
	String prePaidUser = null;

	public GroupPost() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		enterpriseAccId = env.getEnterpriseAccountId();
		prePaidUser = env.getEnterprisePrePaidAccUserId();

	}

	@Then("^Disable whatsapp tab$")
	public void disable_whatsapp_tab() throws Throwable {
		// enterpriseAccId = env.getEnterpriseAccountId();
		log.logging("Disabling the WhatsApp tab", "info");
		Object userId = query.getDBResponse(prePaidUser, "id", "getiingUserId");
		boolean result = query.setDBResponse("disableWhatsAppTab", userId.toString());
		su.refreshPage();
	}

	@Then("^Click on create Group$")
	public void click_on_create_Group() {
		log.logging("Clicking on Create Group", "info");
		driver.findElement(By.xpath("(//input[@class='tbButton'])[3]")).click();
	}

	@Then("^Pass unique Group Name$")
	public void pass_unique_Group_Name() {
		groupName = "Auto" + gu.genRandomName(6);
		log.logging("Creating Group with Name : " + groupName, "info");
		driver.findElement(By.id("grpName")).sendKeys(groupName);

	}

	@Then("^Create the Mask$")
	public void create_the_Mask() {
		log.logging("Selecting Mask with Index 0", "info");

		WebElement defaultMaskId = driver.findElement(By.name("defaultMaskId"));
		new Select(defaultMaskId).selectByIndex(0);

	}

	@Then("^check the group has been created or not$")
	public void check_the_group_has_been_created_or_not() throws InterruptedException {
		log.logging("Creating Group", "info");

//		driver.findElement(By.xpath("(//input[@class='tbButton'])[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"popup\"]/form/input[1]")).click();
		su.refreshPage();
//		boolean groupCreated = driver.findElement(By.linkText(groupName)).isDisplayed();
//		boolean groupCreated = driver.findElement(By.xpath("//*[@id=\"middle-col\"]/div[3]/div/a[2]")).isDisplayed();
		 boolean groupCreated = su.elemCheck(groupName);

//		Assert.assertEquals(groupCreated, true, "Group Not Created");
		log.logging(groupName + " Group Created", "info");
	}

	@Then("^Add Members$")
	public void add_Members(DataTable memAdd) throws IOException, InterruptedException {

		for (Map<String, String> memAddition : memAdd.asMaps(String.class, String.class)) {
			String response = null;
			String responseExp = null;
			log.logging("Clicking on Manage Member", "info");
			driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[2]")).click();
			Thread.sleep(2000);
			// su.refreshPage();
			driver.findElement(By.xpath("(//div[@class='activeQuickActionInnerTab'])[2]")).click();
			if (memAddition.get("Mode").equalsIgnoreCase("TextBox")) {
				log.logging("Adding Members from TextBox", "info");

				driver.findElement(By.xpath("(//textarea[@name='memberNumbersTextBox'])[1]")).sendKeys(phoneNo);

			}
			if (memAddition.get("Mode").equalsIgnoreCase("File")) {
				log.logging("Adding Members from File", "info");

				String filePath = gu.CreatefileFromString(phoneNo, "csv");
				driver.findElement(By.xpath("(//input[@name='fileUploadCheckBox'])[1]")).click();
				driver.findElement(By.xpath("(//input[@name='subscriberNumbersFile'])[1]")).sendKeys(filePath);
				Thread.sleep(10000);
			}
			log.logging("Clicking on Add Button", "info");

			driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[2]")).click();
			if (phoneNo.contains(",")) {
				String[] phoneArr = phoneNo.split(",");
				phoneNocnt = phoneArr.length;
			} else {
				phoneNocnt = 1;

			}
			log.logging("Matching The response after adding", "info");
			if (memAddition.get("id").equalsIgnoreCase("1")) {
				responseExp = "Successfully added " + phoneNocnt + " members.";
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				log.logging("Closing Notification", "info");
				driver.findElement(By.linkText("×")).click();
				Thread.sleep(2000);
			} else {
				response = driver.findElement(By.xpath("//div[@classname='notification notificationRed']//div[1]"))
						.getText();
				responseExp = phoneNocnt + " numbers are already members of group and have not been processed.";

			}
			Assert.assertEquals(response, responseExp);
			log.logging("Got Response : " + response, "info");
			// su.refreshPage();

		}

	}

	@Then("^Click on Make a Post with message \"([^\"]*)\"$")
	public void click_on_Make_a_Post_with_message(String msg) throws InterruptedException {
		log.logging("Posting wih Message " + msg, "info");
		// su.refreshPage();
		driver.findElement(By.xpath("(//input[@name='entityIDArr'])[1]")).click();
		// driver.findElement(By.className("activeQuickActionTab")).click();
		driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).clear();
		Thread.sleep(2000);

		driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).sendKeys(msg);

		Thread.sleep(2000);

	}

	@Then("^Click on Make a Post$")
	public void click_on_Make_a_Post() throws InterruptedException {
		log.logging("Clicking on Post Button", "info");

		driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[1]")).click();
		Thread.sleep(3000);
	}

	@Then("^Check the DB Response$")
	public void check_the_DB_Response() throws IOException, InterruptedException {
		String responseCauseId = driver.findElement(By.xpath("//div[@id='notification']//div[1]")).getText();

		// String responseCauseId =
		// driver.findElement(By.xpath("//div[@classname='notification
		// notificationGreen']//div[1]"))
		// .getText();
		String causeId = responseCauseId.replaceAll("[^0-9]", "").trim();
		log.logging("Got CauseId : " + causeId, "info");
		driver.findElement(By.linkText("×")).click();
		Thread.sleep(2000);
		Object status = query.getDBResponse(causeId, "status", "gettingMsgLogGroupPost");
		log.logging("Got Group Post Status   : " + status, "info");
		Assert.assertEquals(status.toString(), "PROCESSED");

	}

	@Then("^Check the Post and MemberCount of the Group$")
	public void check_the_Post_and_MemberCount_of_the_Group() {
		try {
			String groupDetails = driver.findElement(By.xpath("(//table[@class='groupList']//td)[3]")).getText();
			Assert.assertEquals(groupDetails, groupName + "   1 posts, " + phoneNocnt + " members");
			log.logging("Verified Group Details : " + groupDetails, "info");
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

	@Then("^Check Disabling the Group$")
	public void check_Disabling_the_Group() throws InterruptedException {
		log.logging("Disabling the Group : " + groupName, "info");
		// su.refreshPage();
		driver.findElement(By.xpath("(//input[@name='entityIDArr'])[1]")).click();
		// driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[4]")).click();
		driver.findElement(By.xpath("(//input[@class='tbButton'])[5]")).click();
		Alert alert = driver.switchTo().alert();
		String disableAlert = driver.switchTo().alert().getText();
		Assert.assertEquals(disableAlert, "Are you sure you want to disable the selected groups?");
		alert.accept();

		String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
				.getText();
		driver.findElement(By.linkText("×")).click();
		Thread.sleep(2000);
		log.logging("Checking Response of Disabled Group : " + response, "info");
		Assert.assertEquals(response, "Selected groups have been disabled.");

	}

	@Then("^Enabling the Group$")
	public void enabling_the_Group() throws InterruptedException {
		log.logging("Now Clicking on Show Disabled Groups", "info");
		// su.refreshPage();

		driver.findElement(By.id("enableDisableLinkTextSpan")).click();
		Thread.sleep(2000);
		log.logging("Checking that group is Present or Not", "info");
		// driver.findElement(By.xpath("//span[text()[normalize-space()='AutoiVUY0T']]")).click();
		String groupLocator = "//input[@value='" + groupName + "']";
		driver.findElement(By.xpath(groupLocator)).click();
		String grpName = driver.findElement(By.xpath("//div[@class='select-1by1']//span[1]")).getText();
		Assert.assertEquals(grpName.trim(), groupName, "Group Name Not Matched");
		log.logging("Enabling the group : " + grpName.trim(), "info");

		driver.findElement(By.xpath("(//input[@value='Enable'])[1]")).click();
		String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
				.getText();
		log.logging("Checking Response of Enabled  Group : " + response, "info");
		Assert.assertEquals(response, "Selected groups have been enabled.");
		driver.findElement(By.linkText("×")).click();
		Thread.sleep(2000);
		log.logging("Now Clicking on Show Active Groups", "info");
		driver.findElement(By.id("enableDisableLinkTextSpan")).click();

	}

	@Then("^delete the group and check if deleted or not$")
	public void delete_the_group_and_check_if_deleted_or_not() throws InterruptedException {
		log.logging("Deleting the Group : " + groupName, "info");
		// su.refreshPage();
		Thread.sleep(2000);

		driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[5]")).click();
		log.logging("Clicked on Delete Button ", "info");

		Alert alert = driver.switchTo().alert();
		String alertMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(alertMessage, "Are you sure you want to delete the selected group?");
		alert.accept();
		Thread.sleep(5000);
		String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
				.getText();
		Assert.assertEquals(response, "Selected groups have been deleted.");
		driver.findElement(By.linkText("×")).click();
		Thread.sleep(2000);
		log.logging("After deleting : " + groupName + " Verifying Response : " + response, "info");
		log.logging("Checking group Present or not on UI " + groupName, "info");
		// su.refreshPage();
		boolean groupLink = su.elemCheck(groupName);
		assertEquals(groupLink, false, "Group : " + groupName + " Still present!!");

	}

	@Then("^Select Differnt Message type Post it and check the webarooNo on MsgLog Table in Logging DB$")
	public void select_Differnt_Message_type_Post_it_and_check_the_webarooNo_on_MsgLog_Table_in_Logging_DB(
			DataTable msgNmsgType) throws InterruptedException, IOException {
		for (Map<String, String> msgTypeMapping : msgNmsgType.asMaps(String.class, String.class)) {
			log.logging("Clicking on Making a Post", "info");
			// driver.findElement(By.linkText("Group")).click();
			// driver.findElement(By.xpath("(//input[@value='"+groupName+"'])[1]")).click();
			click_on_Make_a_Post_with_message(msgTypeMapping.get("Message"));
			// driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[1]")).click();
			if (msgTypeMapping.get("MsgType").equalsIgnoreCase("English")) {
				log.logging("Clicking on English", "info");
				driver.findElement(By.xpath("(//div[@class='activeQuickActionInnerTab'])[1]")).click();
			}
			if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Unicode")) {
				log.logging("Clicking on Other Languages", "info");
				driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[5]")).click();
			}
			if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Flash")) {
				log.logging("Clicking on Flash SMS", "info");
				driver.findElement(By.xpath("(//div[@classname='inactiveQuickActionTab'])[4]")).click();
			}
			if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Unicode_Flash")) {
				log.logging("Clicking on Unicode Flash SMS", "info");
				driver.findElement(By.xpath("(//div[@classname='inactiveQuickActionTab'])[5]")).click();
			}
			click_on_Make_a_Post();
			String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			String causeId = response.replaceAll("[^0-9]", "").trim();
			log.logging("Got CauseId : " + causeId, "info");
			driver.findElement(By.linkText("×")).click();
			Thread.sleep(2000);
			// Thread.sleep(10000);
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			String[] wNo = webarooNo.toString().split(",");
			log.logging("Got Group Post WebarooNo   : " + wNo[1].trim(), "info");
			Assert.assertEquals(wNo[1].trim(), msgTypeMapping.get("WebarooNo"));
		}
	}

	@Then("^Select Differnt Message type Post it and check the webarooNo on MsgLog Table in Logging DB and DLTTemplateID in DLT DB$")
	public void select_Differnt_Message_type_Post_it_and_check_the_webarooNo_on_MsgLog_Table_in_Logging_DB_and_DLTTemplateID_in_DLT_DB(
			DataTable msgNmsgType) throws InterruptedException, IOException {
		
		try {
			
			String msg = null;
			String dlt = null;
			String mask = null;
//			String maskText = driver.findElement(By.xpath("//td[@class='groupMask']")).getText();
//			String mask = maskText.substring(6);
			for (Map<String, String> msgTypeMapping : msgNmsgType.asMaps(String.class, String.class)) {
				log.logging("Clicking on Making a Post", "info");
				// driver.findElement(By.linkText("Group")).click();
				// driver.findElement(By.xpath("(//input[@value='"+groupName+"'])[1]")).click();
				// click_on_Make_a_Post_with_message(msgTypeMapping.get("Message"));
				// driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[1]")).click();

				driver.findElement(By.xpath("(//input[@name='entityIDArr'])[1]")).click();
				// driver.findElement(By.className("activeQuickActionTab")).click();
				driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[1]")).click();

				Thread.sleep(2000);
				if (msgTypeMapping.get("MsgType").equalsIgnoreCase("English")) {
					log.logging("Clicking on English", "info");

					driver.findElement(By.xpath("(//div[@class='activeQuickActionInnerTab'])[1]")).click();
				}
				if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Unicode")) {
					log.logging("Clicking on Other Languages", "info");

					driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[5]")).click();
				}
				if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Flash")) {
					log.logging("Clicking on Flash SMS", "info");

					driver.findElement(By.xpath("(//div[@classname='inactiveQuickActionTab'])[4]")).click();
				}
				if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Unicode_Flash")) {
					log.logging("Clicking on Unicode Flash SMS", "info");

					driver.findElement(By.xpath("(//div[@classname='inactiveQuickActionTab'])[5]")).click();
				}
				Thread.sleep(5000);
				if (msgTypeMapping.get("Message") != null) {
					msg = msgTypeMapping.get("Message");
					log.logging("Cleaning the Message Box", "info");
					driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).clear();
					log.logging("Passing the Message : " + msg, "info");
					driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).sendKeys(msg);
				} else {
					Thread.sleep(5000);

					driver.findElement(By.xpath("(//div[@class='actionLink floatRight'])[2]")).click();
					if (msgTypeMapping.get("MsgType").equalsIgnoreCase("English")) {
						msg = driver.findElement(By.cssSelector("div#dltTmplDiv_gupshup_english_1>div>div:nth-of-type(2)"))
								.getText();
						String dbFetchMsg = msg.replaceAll("123", "@__123__@");
						log.logging(dbFetchMsg, "info");
						Object userIdobj = query.getDBResponse(prePaidUser, "id", "getiingUserId");

						String userId = userIdobj.toString();

						log.logging("Got userId : " + userId, "info");

						Object dltId = query.getDBResponse(dbFetchMsg, userId, "dltTemplateId", "getDLTIdFromTemplate");
						dlt = dltId.toString();
						log.logging("DLT id for the message Selected in DB is : " + dlt, "info");

						driver.findElement(By.cssSelector("div#dltTmplDiv_gupshup_english_1>div>div:nth-of-type(2)>span"))
								.click();
						Thread.sleep(2000);
						driver.findElement(By.cssSelector("div#editDltTemplatesDiv>div>div:nth-of-type(2)>input")).click();
					} else if (msgTypeMapping.get("MsgType").equalsIgnoreCase("Unicode")) {
						msg = driver
								.findElement(By.cssSelector("div#dltTmplDiv_gupshup_unicode_1>div>div:nth-of-type(2)>span"))
								.getText();
						String dbFetchMsg = msg.replaceAll("123", "@__123__@");
						log.logging(dbFetchMsg, "info");
						Object userIdobj = query.getDBResponse(prePaidUser, "id", "getiingUserId");
						String userId = userIdobj.toString();
						Object dltId = query.getDBResponse(dbFetchMsg, userId, "dltTemplateId", "getDLTIdFromTemplate");
						dlt = dltId.toString();
						log.logging("DLT id for the message Selected in DB is : " + dlt, "info");

						driver.findElement(By.cssSelector("div#dltTmplDiv_gupshup_unicode_1>div>div:nth-of-type(2)>span"))
								.click();
						Thread.sleep(2000);
						driver.findElement(By.cssSelector("div#editDltTemplatesDiv>div>div:nth-of-type(2)>input")).click();
					}
				}

//				if (msgTypeMapping.get("Mask") != null) {
//					new Select(useMaskGPS).selectByValue(msgTypeMapping.get("Mask"));
//					mask = msgTypeMapping.get("Mask");
//					log.logging("Select Mask as : " + mask, "info");
//				}

				Thread.sleep(2000);
				click_on_Make_a_Post();
				

				String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				
				System.out.println("Response value is:" +response);
				

				String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("Got CauseId : " + causeId, "info");
				driver.findElement(By.linkText("×")).click();
				Thread.sleep(2000);
				// Thread.sleep(10000);
				Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
						"gettingMsgLogGroupPostForTransactionTuples");
				String[] wNo = webarooNo.toString().split(",");
				try {
				log.logging("Got Group Post WebarooNo   : " + wNo[1].trim(), "info");
				Assert.assertEquals(wNo[1].trim(), msgTypeMapping.get("WebarooNo"));
				}
				catch (Exception e) {
					// TODO: handle exception
				}
				if (msgTypeMapping.get("DLTTemplateId") != null) {
					String expdltTempId = msgTypeMapping.get("DLTTemplateId");
					if (expdltTempId.equalsIgnoreCase("DB")) {
						expdltTempId = dlt;
					}
					Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
					// if (msgTypeMapping.get("Mask") != null) {
					// Object masklog = query.getDBResponse(causeId, "mask", "gettingMsgLog");
					// Object userId1 = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");

					log.logging("CausID we are getting : " + causeId, "info");

					Object masklog = query.getDBResponse(causeId, "mask", "gettingMsgLogGroupPostForTransactionTuples");
					mask = masklog.toString();
					log.logging("Verifying Mask we sent from UI : " + mask, "info");

					Object userIdobj = query.getDBResponse(prePaidUser, "id", "getiingUserId");
					String userId = userIdobj.toString();

//						Object maskDlt = query.getDBResponse(dlt , userId, "defaultMask", "getMaskValueFromTemplate");
//						log.logging("Mask from DLTTemplate Table we get is: " + maskDlt.toString(), "info");
					

					Object dltAucID = query.getDBResponse(expdltTempId, userId, "id", "getMaskValueFromTemplate");
					log.logging("Id from DLTTemplate Table we get is: " + dltAucID, "info");

					String dltAucID1 = dltAucID.toString();

					System.out.println("<<<<<<<<<<<<Id we got>>>>>>>>>>>>>>> " + dltAucID1);

					Object maskdlt = query.getDBResponse(dltAucID1, "masks", "getMasksFromDLTMasks");
					log.logging("Mask from DLTTemplate Table we get is: " + maskdlt.toString(), "info");

					boolean maskValue = false;
					if (maskdlt.toString().contains(",")) {
						String[] masks = maskdlt.toString().split(",");
						List <String> myList = Arrays.asList(masks);
						
							if (myList.contains(mask)) {
								maskValue = true;
							} else {
								maskValue = false;
							}
						
					}

					else {
						if (maskdlt.toString().equals(mask)) {
							maskValue = true;
						} else {
							maskValue = false;
						}
					}

//						  String myString = maskdlt.toString();
//					      String[] myArray = myString.split(",");
//					      System.out.println("Contents of the array ::"+Arrays.toString(myArray));
//					      List <String> myList = Arrays.asList(myArray);
//						
//					      boolean flag = myList.contains(mask);
//					      Assert.assertTrue(flag);

					sa.assertEquals(maskValue, true);
					// }
					log.logging("Checking dltTempId Recieved should Match : " + expdltTempId, "info");
					sa.assertEquals(String.valueOf(metadata).contains("dltid=" + expdltTempId), true);

					log.logging("Getting Peid From  EntuserAttribute ", "info");
					// Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
					Object peid = query.getDBResponse(userId.toString(), "value", "getPeidFromAttribute");
					log.logging("Peid is  from EntuserAttribute : " + peid.toString(), "info");
					sa.assertEquals(String.valueOf(metadata).contains("peid=" + peid), true);
					log.logging("DLTTemplateId and Peid is Verified from MsgLog MetaData :  " + metadata.toString(),
							"info");
					log.logging("Peid is  from EntuserAttribute : " + peid.toString(), "info");

				}

			}

			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
			}

	@Then("^Check Group Name Post count will be \"([^\"]*)\" as four transaction is done from this group$")
	public void check_Group_Name_Post_count_will_be_as_four_transaction_is_done_from_this_group(String postCount) {
		String groupDetails = driver.findElement(By.xpath("(//table[@class='groupList']//td)[3]")).getText();
		Assert.assertEquals(groupDetails, groupName + "   " + postCount + " posts, " + phoneNocnt + " members");
		log.logging("Verified Group Details : " + groupDetails, "info");

	}

}
