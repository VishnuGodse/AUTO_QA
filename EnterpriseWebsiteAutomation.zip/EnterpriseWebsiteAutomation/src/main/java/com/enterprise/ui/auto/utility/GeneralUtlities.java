package com.enterprise.ui.auto.utility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class GeneralUtlities {
	List<String> filesListInDir = new ArrayList<String>();
	Logger log = Logger.getLogger(GeneralUtlities.class);
	EnvBO ev;

	// public static ExtentReports extent;
	// public static ExtentTest test;

	public void cleanDir(String path) {
		File file = new File(path);

		File[] files = file.listFiles();
		for (File f : files) {
			if (f.isFile() && f.exists()) {
				f.delete();
				log.debug("Successfully deleted" + " : " + f);
			} else {
				log.debug("Can't delete a file due to open or error" + " : " + f);
			}
		}

	}

	public void delFile(String path) {
		File file = new File(path);

		if (file.exists()) {
			file.delete();
			log.debug(file + "is deleted");
		} else
			log.debug(file + "not present!");
	}

	public String getSysDetail(String details) throws IOException {
		String result = "";
		if (details.equalsIgnoreCase("hostname")) {
			String sysname = InetAddress.getLocalHost().getHostName();

			return result = sysname;
		} else if (details.equalsIgnoreCase("OS")) {
			String os = System.getProperty("os.name");
			return result = os;
		} else if (details.equalsIgnoreCase("ip")) {
			Socket socket = new Socket();
			socket.connect(new InetSocketAddress("google.com", 80));
			// System.out.println(socket.getLocalAddress());
			// String ip = InetAddress.getLocalHost().getHostAddress();
			String[] ip = socket.getLocalAddress().toString().split("/");
			return result = ip[1];
		} else if (details.equalsIgnoreCase("javaVersion")) {
			String javaVersion = System.getProperty("java.version");

			return result = javaVersion;
		} else if (details.equalsIgnoreCase("envUri")) {

			ev.getEnterpriseUrl();
		} else if (details.equalsIgnoreCase("USERNAME")) {
			String username = System.getProperty("user.name");
			return result = username;
		}
		return result;
	}

	public void sendMail(String to, String cc, String sub, String mailbody, String attachLocation)
			throws UnknownHostException {

		// Sender's email ID needs to be mentioned
		String from = "bottest@gupshup.io";
		final String username = "bottest@gupshup.io";// change accordingly
		final String password = "Automation@123";// change accordingly

		// Assuming you are sending email through smtp.gmail.com
		String host = "smtp.gmail.com";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.ssl.trust", host);
		props.put("mail.smtp.ssl.protocols", "TLSv1.2");
		MimeMultipart multipart = new MimeMultipart();

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setContent(multipart);
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(cc));
			// File file = new File(attachLocation);
			message.setSubject(sub);
			BodyPart attachmentBodyPart = new MimeBodyPart();
			String filename = attachLocation;
			DataSource source = new FileDataSource(filename);
			attachmentBodyPart.setDataHandler(new DataHandler(source));
			attachmentBodyPart.setFileName(filename);
			multipart.addBodyPart(attachmentBodyPart);
			BodyPart htmlBodyPart = new MimeBodyPart();
			htmlBodyPart.setContent(mailbody, "text/html");
			multipart.addBodyPart(htmlBodyPart);
			message.setContent(multipart);
			Transport.send(message);
		} catch (MessagingException ex) {
			ex.printStackTrace();
		}
	}

	public String getCurrDate() {
		String date = "";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		date = dtf.format(now);
		return date;

	}

	public String getSpecificDateFormatForReport() {

		SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
		Date date = new Date();

		return formatter.format(date);
	}

	public void populateFilesList(File dir) throws IOException {
		File[] files = dir.listFiles();
		for (File file : files) {
			if (file.isFile())
				filesListInDir.add(file.getAbsolutePath());
			else
				populateFilesList(file);
		}
	}

	public void zipDirectory(File dir, String zipDirName) {

		try {
			populateFilesList(dir);
			// now zip files one by one
			// create ZipOutputStream to write to the zip file
			FileOutputStream fos = new FileOutputStream(zipDirName);
			ZipOutputStream zos = new ZipOutputStream(fos);
			for (String filePath : filesListInDir) {
				log.debug("Zipping " + filePath);
				// for ZipEntry we need to keep only relative file path, so we used substring on
				// absolute path

				ZipEntry ze = new ZipEntry(dir.getName() + File.separatorChar
						+ filePath.substring(dir.getAbsolutePath().length() + 1, filePath.length()));
				zos.putNextEntry(ze);
				// read the file and write to ZipOutputStream
				FileInputStream fis = new FileInputStream(filePath);
				byte[] buffer = new byte[1024];
				int len;
				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
				zos.closeEntry();
				fis.close();
			}
			zos.close();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String genRandomNumber(String inputNo) {
		String result = null;
		Integer inNo = Integer.valueOf(inputNo);
		Random rand = new Random();
		int toSendNow = rand.nextInt(inNo);
		result = String.valueOf(toSendNow);
		return result;

	}

	public static String genRandomName(int n) {
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";

// create StringBuffer size of AlphaNumericString 
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

// generate a random number between 
// 0 to AlphaNumericString variable length 
			int index = (int) (AlphaNumericString.length() * Math.random());

// add Character one by one in end of sb 
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	public static String genRandomString(int n)

	{
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvxyz";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}
		return sb.toString();
	}

	public static String timeDiff(String dateStart, String dateStop) {

		String diffTime = null;
		// String dateStart = "Thu Aug 13 18:01:01 IST 2020";
		// String dateStop = "Thu Aug 13 19:02:02 IST 2020";

		SimpleDateFormat format = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");

		Date d1 = null;
		Date d2 = null;
		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		// Get msec from each, and subtract.
		long diff = d2.getTime() - d1.getTime();
		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000);

		String sec = String.valueOf(diffSeconds);
		String min = String.valueOf(diffMinutes);
		String hours = String.valueOf(diffHours);

		if (sec.equals("0")) {
			diffTime = hours + " Hours " + min + " Minutes";

		}
		if ((min.equals("00")) || (min.equals("0"))) {
			diffTime = hours + " Hours ";
		}
		if ((hours.equals("00")) || (hours.equals("0"))) {
			diffTime = min + " Minutes " + sec + " Seconds ";
		}
		if (diffTime == null) {
			diffTime = hours + " Hours " + min + " Minutes " + sec + " Seconds ";
		}

		return diffTime;
	}

	public String genGraph(int pass, int fail, int skip, int total) throws UnsupportedEncodingException {
		String passCnt = String.valueOf(pass);
		String failCnt = String.valueOf(fail);
		String skipCnt = String.valueOf(skip);
		String totCnt = String.valueOf(total);
		String url;

		String chartConfigTemplate = "{type:'doughnut',data:{labels:['Pass','Fail','Skip'],datasets:[{data:[" + passCnt
				+ "," + failCnt + "," + skipCnt + "]}]},options:{plugins:{doughnutlabel:{labels:[{text:'" + totCnt
				+ "',font:{size:20}},{text:'total'}]}}}}";
		String chartUrl = "https://quickchart.io/chart?width=500&height=200&chart="
				+ URLEncoder.encode(chartConfigTemplate, StandardCharsets.UTF_8.name());

		return url = chartUrl;

	}

	public String genBarGraph(int pass, int fail, int skip) throws UnsupportedEncodingException {
		String passCnt = String.valueOf(pass);
		String failCnt = String.valueOf(fail);
		String skipCnt = String.valueOf(skip);
		// String totCnt = String.valueOf(total);
		String url;

		/*
		 * String chartConfigTemplate =
		 * "{ type: 'bar', data: { labels: ['Pass','Fail','Skipped'], datasets: [{ label: 'Test Case Status', data: ["
		 * + passCnt + "," + failCnt + "," + skipCnt +
		 * "], backgroundColor:  [\"#008000\", \"#FF0000\", \"#808080\"], }] }}";
		 */

		String chartConfigTemplate = "{ type: 'bar', data: { datasets: [{ label: 'Pass', data: [" + passCnt
				+ "], backgroundColor: pattern.draw('zigzag-horizontal', 'green'), }, { label: 'Fail', data: ["
				+ failCnt
				+ "], backgroundColor: pattern.draw('diagonal-right-left', 'red'), },{ label: 'Skipped', data: ["
				+ skipCnt + "], backgroundColor: pattern.draw('diagonal-right-left', 'darkgrey'), }] }}";
		// System.out.println(chartConfigTemplate);
		String barChartUrl = "https://quickchart.io/chart?bkg=white&c="
				+ URLEncoder.encode(chartConfigTemplate, StandardCharsets.UTF_8.name());

		return url = barChartUrl;

	}

	public static String CreatefileFromString(String phoneNo, String fileType) throws IOException {
		if (phoneNo.contains(",")) {
			String[] phoneArr = phoneNo.split(",");
			int i = 0;
			BufferedWriter bw = new BufferedWriter(
					new FileWriter(System.getProperty("user.dir") + "/BulkUploadFiles/phoneNo." + fileType));
			while (i < phoneArr.length) {
				bw.append(phoneArr[i]);
				bw.append('\n');

				i++;
				// bw.close();
			}
			bw.close();
		}

		return System.getProperty("user.dir") + "/BulkUploadFiles/phoneNo." + fileType;
	}

	public void createReportDir(String path) {
		File file = new File(path);
		// Creating the directory
		boolean bool = file.mkdir();
		if (bool) {
			log.debug("Directory created successfully");
		} else {
			log.debug("Sorry couldn't create specified directory");
		}
	}

	public String hitV3API(String endPointUrl, String botKey, String apiKey, String msg, String phoneNo, String channel,
			String dltId, int runTime) throws UnirestException {
		String output = null;
		Unirest.setTimeouts(0, 0);
		int i = 0;
		while (i < runTime) {
			HttpResponse<String> response = Unirest.post("https://" + endPointUrl + "/v3/" + botKey + "/msg")
					.header("Authorization", apiKey).header("Content-Type", "application/json")
					.body("{\n    \"destination\": \"" + phoneNo
							+ "\",\n    \"message\": {\n           \"type\": \"text\",\n           \"text\": \"" + msg
							+ "\",\n         \"dltTemplateId\": \"" + dltId
							+ "\",  //Optional\n         \"port\" : 1234 //optional\n},\n    \"route\": \"" + channel
							+ "\",\n    \"transformation\": \"\",\n    \"reqId\": \"\",\n    \"refId\": \"\",\n    \"source\": \"\"\n}")
					.asString();
			log.info("Getting Response from V3 API : " + response.getBody());
			output = response.getBody();
			i++;
		}
		return output;
	}

	public String getCauseIdFromLogs(String scriptPath, String message, String accountId, String configPath,
			String msgType ,String extra) throws IOException, InterruptedException {
		String result = null;
		String arg1 = accountId;
		String arg2 = message;
		String msg = null;
	
		String os = getSysDetail("OS");
		Process process;
		String command = null;
		if (msgType.equalsIgnoreCase("text")) {
			msg = arg2.replaceAll(" ", "+").trim();
		} else {
			msg = URLEncoder.encode(arg2, "UTF-8");
			log.debug(msg);
		}
		try {
			if (os.contains("Windows")) {
				log.info("It's a  Window OS");
				configPath = configPath.replaceAll("C:", "/mnt/c");
				scriptPath = scriptPath.replaceAll("C:", "/mnt/c");
				configPath = configPath.replaceAll("\\\\", "/");
				scriptPath = scriptPath.replaceAll("\\\\", "/");
				log.info(configPath + "  : " + scriptPath);
				command = scriptPath + " " + arg1 + " " + msg + " " + configPath + " " + "WINDOWS"+" "+extra;
				log.info("Converting Windows file to Unix Format");
				process = Runtime.getRuntime().exec("wsl dos2unix " + scriptPath);
				log.info("Sleeping for 5 Seconds");
				Thread.sleep(5000);
				process = Runtime.getRuntime().exec("wsl bash " + command);

			} else {
				log.info("It's a Linux OS");

				command = scriptPath + " " + arg1 + " " + msg + " " + configPath + " " + "LINUX"+" "+extra;
				log.info("Command is : " + command);

				process = Runtime.getRuntime().exec(command);
			}
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line;

			while ((line = reader.readLine()) != null) {
				log.info("Logs found : " + line);
				if (line.equals("")) {
					continue;
				}
				String data[] = line.split("\\|");
				String[] causeIdtmp = data[2].split("-");
				String causeId = causeIdtmp[0].trim();
				result = causeId;
			}
			if (result == null) {
				log.info("No Logs Found in All the Hosts");
			}
			reader.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
}
