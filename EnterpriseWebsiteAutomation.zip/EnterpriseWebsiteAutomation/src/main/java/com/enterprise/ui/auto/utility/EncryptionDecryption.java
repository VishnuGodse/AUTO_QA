/**
 * 
 */
package com.enterprise.ui.auto.utility;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import javax.crypto.Cipher;
import org.apache.commons.codec.binary.Base64;

import com.enterprise.ui.auto.Bo.ConfigServerBO;
/**
 * @author Rahul Jain
 *
 */
public class EncryptionDecryption {

	/**
	 * @param args
	 */
	private Key secretKey;
	private String keyStoreType = "JCEKS";

	
	public EncryptionDecryption(String keyAlias, String keystorePass, String keyPass, String keyStoreFilePath) throws Exception
	{
		InputStream keystoreStream = new FileInputStream(keyStoreFilePath);
		KeyStore keystore = KeyStore.getInstance(keyStoreType);
		keystore.load(keystoreStream, keystorePass.toCharArray());
		secretKey = keystore.getKey(keyAlias, keyPass.toCharArray());
		

		
	}
	public String encrypt(String plainText) throws Exception
	{
		byte[] plainTextByte = plainText.getBytes();
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedByte = cipher.doFinal(plainTextByte);
		return Base64.encodeBase64String(encryptedByte);
	}
	public String decrypt(String encryptedText) throws Exception
	{
		byte[] encryptedTextByte = Base64.decodeBase64(encryptedText);
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
		return new String(decryptedByte, "UTF-8");
	}
	/*public static void main(String[] args) throws Exception {
EncryptionDecryption enc = new EncryptionDecryption("smsgupshup", "yudGucDilg5", "yudGucDilg5", "/home/rahul/Encr/keystore-AES256.jks");
System.out.println(enc.encrypt("918767879963"));
	}*/

}
