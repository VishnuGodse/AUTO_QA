package com.enterprise.ui.auto.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ReportingLogging extends SeleniumUtility {

	public ReportingLogging() throws IOException {
		super();
	}

	public void logging(String msg, String logType) {
		if (logType.equalsIgnoreCase("Info")) {
			log.info(msg);

			//test.info(msg);

		} else if (logType.equalsIgnoreCase("Debug")) {
			log.debug(msg);
			//test.debug(msg);
		} else if (logType.equalsIgnoreCase("Step")) {
			/*
			 * log.info(msg); test.info(msg);
			 */
			//test.createNode(msg);
		} else
			log.debug("Invalid Log Type : " + logType);
	}

	public void logoUpdate(String fileName) throws IOException {
		Path path = Paths.get(fileName);
		Charset charset = StandardCharsets.UTF_8;
		String old = "https://cdn.rawgit.com/extent-framework/extent-github-cdn/d74480e/commons/img/logo.png";
		String newStr = "https://www.gupshup.io/developer/resources/img/assets/2019/logo_type4.png";
		String content = new String(Files.readAllBytes(path), charset);
		content = content.replaceAll(old, newStr);
		Files.write(path, content.getBytes(charset));
	}

}
