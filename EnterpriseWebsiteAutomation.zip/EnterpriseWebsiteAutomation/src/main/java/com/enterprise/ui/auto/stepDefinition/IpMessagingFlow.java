package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.Assert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.Bo.EnvDatabaseBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.mashape.unirest.http.exceptions.UnirestException;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.runtime.Env;

public class IpMessagingFlow {
	
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	public int FailedCountPresentInt;
	public int RequestedCountPresentInt;
	public int SentCountPresentInt;
	public int TotalFailedCountInt;
	public int TotalMsgRequestedCountInt;
	public int TotalSentCountInt;
	ReportingLogging log;
	String enterpriseAccId;
	ExecuteQuery query;
	String apiKey;
	String botKey;
	String phoneNoOptin;
	String phoneNoOptout;
	String v3URL;
	GeneralUtlities gu;
	public IpMessagingFlow() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		enterpriseAccId = env.getEnterpriseAccountId();
		query = new ExecuteQuery();
		apiKey = env.getV3ApiKey();
		botKey = env.getV3BotKey();
		phoneNoOptin = env.getV3Optin();
		phoneNoOptout= env.getV3Optout();
		v3URL= env.getV3Url();
		gu= new GeneralUtlities();
	}

	
@Given("^User should be able to set value false for IP Messaging tab in suport servlet$")
public void disable_IPMessaging_tab() throws Throwable {
	log.logging("Disabling the IPMessaging tab", "info");
	Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
	boolean result = query.setDBResponse("disableIpMessagingTab", userId.toString());
	if (result == false) {
		log.logging("IP Messaging Tab Attribute not present so inserting in userId" + userId + " setting value as false",
				"info");
		query.setDBResponse("insertIPMessagingFalse", userId.toString());
	}
	Thread.sleep(10000);
	su.refreshPage();
	
//	enterpriseAccId = env.getEnterpriseAccountId();
	
	//Commenting below code, have added insert in above code
//	log.logging("Disabling the IPMessaging tab", "info");
//	Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
//	boolean result = query.setDBResponse("disableIpMessagingTab", userId.toString());
//	Thread.sleep(10000);
//	su.refreshPage();
//	Thread.sleep(5000);
	}

@Given("^User should be able to set value true for IP Messaging tab in suport servlet$")
public void enable_IPMessaging_tab() throws Throwable {
	log.logging("Enabling the IPMessaging tab", "info");
	Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
	boolean result = query.setDBResponse("enableIpMessagingTab", userId.toString());
	if (result == false) {
		log.logging("IP Messaging Tab Attribute not present so inserting in userId" + userId + " setting value as true",
				"info");
		query.setDBResponse("insertIPMessagingTrue", userId.toString());
	}
	Thread.sleep(10000);
	su.refreshPage();

	
//	enterpriseAccId = env.getEnterpriseAccountId();

//Commenting below code, have added insert in above code
//	log.logging("Enabling the IPMessaging tab", "info");
//	Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
//	boolean result = query.setDBResponse("enableIpMessagingTab", userId.toString());
//	Thread.sleep(10000);
//	su.refreshPage();	
//	Thread.sleep(5000);
	}


@Then("^User verifies IP Messaging tab is not visible$")
public void IPMessagingTabDisableCheck() throws Throwable { driver.findElement(By.xpath("//span[text()='IP Messaging']")).isDisplayed();

	boolean VisibiltyOfTab = driver.findElement(By.xpath("//span[text()='IP Messaging']")).isDisplayed();
	if(VisibiltyOfTab==false) {
		log.logging("IP Messaging Tab is not visble", "info");
		}


//	try {
//		if(!driver.findElement(By.xpath("//span[text()='IP Messaging']")).isDisplayed()) 
//		{
//			log.logging("IP Messaging Tab is not visble", "info");
//		}
//		}catch(Exception e){
//			log.logging("IP Messaging Tab is visble", "info");
//		}
	
	}
	
@Given("^User verifies IP Messaging tab is visible$")
public void IPMessagingTabVisibility() {
	driver.findElement(By.xpath("//span[text()='IP Messaging']")).isDisplayed();
	log.logging("IP Messaging Tab is visble", "info");
}

@Given("^User click on IP Messaging tab$")
public void user_click_on_IP_Messaging_tab() {
	driver.findElement(By.xpath("//span[text()='IP Messaging']")).click();
	log.logging("Cliking on IP Messaging Tab", "info");
}

@Then("^User is able to see RCS, Signal and Telegram options$")
public void ChannelVisibility() {
	log.logging("Verifyng all 3 channels are displayed", "info");
	driver.findElement(By.xpath("//div[text()='RCS']")).isDisplayed();
	driver.findElement(By.xpath("//div[text()='Telegram']")).isDisplayed();
	driver.findElement(By.xpath("//div[text()='Signal']")).isDisplayed();
}

@Then("^User should be able to click Telegram option$")
public void TelegramOptionClick() throws Throwable {
	log.logging("Cliking on Telegram option", "info");
	driver.findElement(By.xpath("//div[text()='Telegram']")).click();
	driver.findElement(By.xpath("//div[text()='Telegram' and @class='activeTab']")).isDisplayed();
	
}


@Then("^User should be able to click Signal option$")
public void SignalOptionClick() throws Throwable {
	log.logging("Cliking on Signal option", "info");
	driver.findElement(By.xpath("//div[text()='Signal']")).click();
	driver.findElement(By.xpath("//div[text()='Signal' and @class='activeTab']")).isDisplayed();
}

@Then("^User should be able to click RCS option$")
public void RCSOptionClick() throws Throwable {
	log.logging("Cliking on RCS option", "info");
	driver.findElement(By.xpath("//div[text()='RCS']")).click();
	driver.findElement(By.xpath("//div[text()='RCS' and @class='activeTab']")).isDisplayed();
	Thread.sleep(5000);
}

@Then("^User clicks on Date selection Box$")
public void DateSelection() throws Throwable {
	log.logging("Cliking on Date selection box", "info");
	driver.findElement(By.xpath("//input[@id='dateRange']")).click();
	Thread.sleep(5000);
}
@And("^User selects Today and click on apply$")
public void TodayDate() throws Throwable {	
	log.logging("Cliking on Today option", "info");
	driver.findElement(By.xpath("//a[contains(text(),'Today')]")).click();
	driver.findElement(By.xpath("//div[contains(text(),'Apply')]")).click();
	
	Thread.sleep(5000);
	String DateSelection= driver.findElement(By.xpath("//input[@id='dateRange']")).getAttribute("value");
	String DateSelected = driver.findElement(By.xpath("//span[@id='selectedDateRange']")).getText();
	
	log.logging(DateSelection, "info");
	log.logging(DateSelected, "info");
	Assert.assertEquals(DateSelection,DateSelected);
	log.logging("Today's data is displayed", "info");
}

@And("^User Selects Yesterday and click on apply$")
public void YesterdayDate() throws Throwable {	
	log.logging("Cliking on Yesterday option", "info");
	driver.findElement(By.xpath("//a[contains(text(),'Yesterday')]")).click();
	driver.findElement(By.xpath("//div[contains(text(),'Apply')]")).click();
	
	Thread.sleep(5000);
	String DateSelection= driver.findElement(By.xpath("//input[@id='dateRange']")).getAttribute("value");
	String DateSelected = driver.findElement(By.xpath("//span[@id='selectedDateRange']")).getText();
	
	log.logging(DateSelection, "info");
	log.logging(DateSelected, "info");
	Assert.assertEquals(DateSelection,DateSelected);
	log.logging("Yesterday's data is displayed", "info");
	
}
@And("^User Selects Last 7 days and click on apply$")
public void LastSevenDays() throws Throwable {	
	log.logging("Cliking on Last 7 days option", "info");
	driver.findElement(By.xpath("//a[contains(text(),'Last 7 days')]")).click();
	driver.findElement(By.xpath("//div[contains(text(),'Apply')]")).click();
	
	Thread.sleep(5000);
	String DateSelection= driver.findElement(By.xpath("//input[@id='dateRange']")).getAttribute("value");
	String DateSelected = driver.findElement(By.xpath("//span[@id='selectedDateRange']")).getText();
	
	log.logging(DateSelection, "info");
	log.logging(DateSelected, "info");
	Assert.assertEquals(DateSelection,DateSelected);
	log.logging("Last 7 days data is displayed", "info");
}

@And("^User Selects Month to date and click on apply$")
public void MonthToDate() throws Throwable {	
	log.logging("Cliking on Month To Date option", "info");
	driver.findElement(By.xpath("//a[contains(text(),'Month to date')]")).click();
	driver.findElement(By.xpath("//div[contains(text(),'Apply')]")).click();
	
	Thread.sleep(5000);
	String DateSelection= driver.findElement(By.xpath("//input[@id='dateRange']")).getAttribute("value");
	String DateSelected = driver.findElement(By.xpath("//span[@id='selectedDateRange']")).getText();
	
	log.logging(DateSelection, "info");
	log.logging(DateSelected, "info");
	Assert.assertEquals(DateSelection,DateSelected);
	log.logging("Month to date data is displayed", "info");
}

@And("^User Selects Last 30 days and click on apply$")
public void LastThirtyDays() throws Throwable {	
	log.logging("Cliking on Last 30 days option", "info");
	driver.findElement(By.xpath("//a[contains(text(),'Last 30 Days')]")).click();
	driver.findElement(By.xpath("//div[contains(text(),'Apply')]")).click();
	
	Thread.sleep(5000);
	String DateSelection= driver.findElement(By.xpath("//input[@id='dateRange']")).getAttribute("value");
	String DateSelected = driver.findElement(By.xpath("//span[@id='selectedDateRange']")).getText();
	
	log.logging(DateSelection, "info");
	log.logging(DateSelected, "info");
	Assert.assertEquals(DateSelection,DateSelected);
	log.logging("Last 30 days data is displayed", "info");
}

@And("^User Selects Previous Month and click on apply$")
public void PreviousMonth() throws Throwable {	
	log.logging("Cliking on Previous Month option", "info");
	driver.findElement(By.xpath("//a[contains(text(),'The previous Month')]")).click();
	driver.findElement(By.xpath("//div[contains(text(),'Apply')]")).click();
	
	Thread.sleep(5000);
	String DateSelection= driver.findElement(By.xpath("//input[@id='dateRange']")).getAttribute("value");
	String DateSelected = driver.findElement(By.xpath("//span[@id='selectedDateRange']")).getText();
	
	log.logging(DateSelection, "info");
	log.logging(DateSelected, "info");
	Assert.assertEquals(DateSelection,DateSelected);
	log.logging("Previous Month's data is displayed", "info");
}

@And("^User Selects date from date range and click on apply$")
public void DateRangeSelection() throws Throwable {	
	log.logging("Cliking on Date range option", "info");
	driver.findElement(By.xpath("//a[contains(text(),'Date Range')]")).click();
	for(int i=0;i<=2;i++) {
	driver.findElement(By.xpath("(//span[text()='Prev'])[1]")).click();
	
	}
	
	driver.findElement(By.xpath("(//td[@data-event='click'])[1]")).click(); //start date
	driver.findElement(By.xpath("//td[contains(@class,'ui-datepicker-current-day ui-datepicker-today')]")).click(); //end date
	driver.findElement(By.xpath("//button[contains(text(),'Done')]")).click(); //done click
	log.logging("90 days date is selected", "info");
//	Thread.sleep(2000);
//	String DateSelection= driver.findElement(By.xpath("//input[@id='dateRange']")).getAttribute("value");
//	String DateSelected = driver.findElement(By.xpath("//span[@id='selectedDateRange']")).getText();
//	
//	log.logging(DateSelection, "info");
//	log.logging(DateSelected, "info");
//	Assert.assertEquals(DateSelection,DateSelected);
//	log.logging("Selected date range data is displayed", "info");
}

@Given("^User post message on telegram with optout user$")
public void TelegramMsgOptOutUser() throws Throwable{
	String output= gu.hitV3API(v3URL, botKey, apiKey, "Hi Automation", phoneNoOptout, "telegram", "123456", 2);
	log.logging(output, "info");
}

@Given("^User post message on telegram with optin user$")
public void TelegramMsgOptinUser() throws Throwable{
   String output= gu.hitV3API(v3URL, botKey, apiKey, "Hi Automation", phoneNoOptin, "telegram", "123456", 2);
   log.logging(output, "info");
 
   //random number to run the code
//   String randomNo = gu.genRandomNumber("10");
//	 while (randomNo.equals("0")) {
//			System.out.println("Getting in Loop");
//			randomNo=gu.genRandomNumber("10");
//		}
//		System.out.println(randomNo);
//		//use this as ur runtime variable
//		Integer.valueOf(randomNo);
}

@And("^Verify the graph is displayed$")
public void GraphVisibility() {
	driver.findElement(By.xpath("//div[@id='drawVisualization']")).isDisplayed();
	log.logging("Bar Graph is displayed", "info");
}

@Then("^User verifies current failed count$")
public int CurrentFailedCount() {
	if(driver.findElement(By.id("noDataMessageDiv")).isDisplayed()==true) {
		FailedCountPresentInt = 0;
		log.logging("Previous Failed Count"+FailedCountPresentInt, "info");
	}
	else {
	
		String  FailedCountPresent = driver.findElement(By.xpath("//*[@text-anchor='middle' and @fill='#ffffff']")).getText();
		log.logging("Previous Failed Count"+FailedCountPresent, "info");
		FailedCountPresentInt= Integer.parseInt(FailedCountPresent);
	}
	return FailedCountPresentInt;
}


@Then("^User verifies current Message Requested count$")
public int CurrentMessageRequestedCount() {
	if(driver.findElement(By.id("noDataMessageDiv")).isDisplayed()==true) {
		RequestedCountPresentInt = 0;
		log.logging("Previous Message requested Count"+RequestedCountPresentInt, "info");
	}
	else {
	String RequestedCountPresent = driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[1]")).getText();
	log.logging("Previous Message requested Count"+RequestedCountPresent, "info");
	RequestedCountPresentInt= Integer.parseInt(RequestedCountPresent);
	}
return RequestedCountPresentInt;
}

@Then("^User verifies current Sent Message count$")
public int CurrentSentCount() {
	if(driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[2]")).isDisplayed()==false) {
		SentCountPresentInt = 0;
		log.logging("Previous Sent Count"+SentCountPresentInt, "info");
	}
	else {
	String  SentCountPresent = driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[2]")).getText();
	log.logging("Previous Sent Count"+SentCountPresent, "info");
	SentCountPresentInt= Integer.parseInt(SentCountPresent);
	}
return SentCountPresentInt;
}

@And("^Verify the count of Message Requested and Failed message$")
public void FailedCountVerify() {
	//Message Requested
		String TotalMsgRequestedCount = driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[1]")).getText();
		log.logging(TotalMsgRequestedCount, "info");
		TotalMsgRequestedCountInt= Integer.parseInt(TotalMsgRequestedCount);
		int PreviousMsgRequestedCount = RequestedCountPresentInt + 2;
		System.out.println("Previous Failed count + New failed count = "+PreviousMsgRequestedCount);
		Assert.assertEquals(PreviousMsgRequestedCount,TotalMsgRequestedCountInt);
		log.logging("Message Requested Count Verified", "info");
		
	//Failed count
	String TotalFailedCount = driver.findElement(By.xpath("//*[@text-anchor='middle' and @fill='#ffffff']")).getText();
	log.logging(TotalFailedCount, "info");
	TotalFailedCountInt= Integer.parseInt(TotalFailedCount);
	int PreviousFailedCount = FailedCountPresentInt + 2;
	System.out.println("Previous Failed count + New failed count = "+PreviousFailedCount);
	Assert.assertEquals(PreviousFailedCount,TotalFailedCountInt);
	log.logging("Failed Count Verified", "info");
}

@And("^Verify the count of Message Requested and sent$")
public void MessageCountVerify() {
	
	//Message Requested
	String TotalMsgRequestedCount = driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[1]")).getText();
	log.logging(TotalMsgRequestedCount, "info");
	TotalMsgRequestedCountInt= Integer.parseInt(TotalMsgRequestedCount);
	int PreviousMsgRequestedCount = RequestedCountPresentInt + 2;
	System.out.println("Previous Failed count + New failed count = "+PreviousMsgRequestedCount);
	Assert.assertEquals(PreviousMsgRequestedCount,TotalMsgRequestedCountInt);
	log.logging("Message Requested count Verified", "info");
	
	
	//Sent Message
	String TotalSentCount = driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[2]")).getText();
	log.logging(TotalSentCount, "info");
	TotalSentCountInt= Integer.parseInt(TotalSentCount);
	int PreviousSentCount = SentCountPresentInt + 2;
	System.out.println("Previous Failed count + New failed count = "+PreviousSentCount);
	Assert.assertEquals(PreviousSentCount,TotalSentCountInt);
	log.logging("Sent Count Verified", "info");
}

@Then("^User verify Channel Statistic section is visible$")
public void ChannelStatVisiblity() {
	driver.findElement(By.xpath("//div[contains(text(),'Channel statistics')]")).isDisplayed();
	log.logging("Channel Statistic section is visible", "info");
}

@And("^User verify that legends of pie chart are displayed with correct data$")
public void PieChartLegendsVerify() {
	
	String BarGraphMsgRequestedCount = driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[1]")).getText();
	log.logging("Bar Graph Message requested Count"+BarGraphMsgRequestedCount, "info");
	int BarGraphMsgRequestedCountInt= Integer.parseInt(BarGraphMsgRequestedCount);
	
	String MsgRequestedCountPieChart = driver.findElement(By.xpath("//div[@id='statsTable']//following-sibling::td[text()='Messages Requested']//following-sibling::td")).getText();
	log.logging(MsgRequestedCountPieChart, "info");
	int MsgRequestedCountPieChartInt= Integer.parseInt(MsgRequestedCountPieChart);
	System.out.println("Message Requested Count present in Pie chart = "+MsgRequestedCountPieChartInt);
	Assert.assertEquals(MsgRequestedCountPieChartInt, BarGraphMsgRequestedCountInt);
	log.logging("Count for Message requested Legend of Pie chart is verified", "info");
	
	String  BarGraphSentCount = driver.findElement(By.xpath("(//*[@text-anchor='middle' and @fill='#404040'])[2]")).getText();
	log.logging("Bar graph Sent Count"+BarGraphSentCount, "info");
	int BarGraphSentCountInt= Integer.parseInt(BarGraphSentCount);

	
	String SentCountPieChart = driver.findElement(By.xpath("//div[@id='statsTable']//following-sibling::td[text()='Sent']//following-sibling::td")).getText();
	log.logging(SentCountPieChart, "info");
	int SentCountPieChartInt= Integer.parseInt(SentCountPieChart);
	System.out.println("Message Sent Count present in Pie chart = "+SentCountPieChartInt);
	Assert.assertEquals(SentCountPieChartInt, BarGraphSentCountInt);
	log.logging("Count for Sent Legend of pie chart is verified", "info");
	
	String  BarGraphFailedCount = driver.findElement(By.xpath("//*[@text-anchor='middle' and @fill='#ffffff']")).getText();
	log.logging("Bar Graph Failed Count"+BarGraphFailedCount, "info");
	int BarGraphFailedCountInt= Integer.parseInt(BarGraphFailedCount);
	
	String FailedCountPieChart = driver.findElement(By.xpath("//div[@id='statsTable']//following-sibling::td[text()='Failed']//following-sibling::td")).getText();
	log.logging(FailedCountPieChart, "info");
	int FailedCountPieChartInt= Integer.parseInt(FailedCountPieChart);
	System.out.println("Message Failed Count present in Pie chart = "+FailedCountPieChartInt);
	Assert.assertEquals(FailedCountPieChartInt, BarGraphFailedCountInt);
	log.logging("Count for Failed Legend of pie chart is verified", "info");
	
//	driver.findElement(By.xpath("//div[@id='statsTable']//following-sibling::td[text()='Messages Requested']//following-sibling::td[text()='4']")).isDisplayed();
//	log.logging("Count for Message requested Legend is verified", "info");
//	driver.findElement(By.xpath("//div[@id='statsTable']//following-sibling::td[text()='Sent']//following-sibling::td[text()='2']")).isDisplayed();
//	log.logging("Count for Sent Legend is verified", "info");
//	driver.findElement(By.xpath("//div[@id='statsTable']//following-sibling::td[text()='Failed']//following-sibling::td[text()='2']")).isDisplayed();
//	log.logging("Count for Failed Legend is verified", "info");
	
}

@And("^User verifies the sequence of legends in bar graph$")
public void LegendSequenceCheckBarGarph() {

	log.logging("Legend Sequence is verified for bar graph", "info");
}

@And("^User verifies the sequence of legends in pie chart$")
public void LegendSequenceCheckPieChart() {
	driver.findElement(By.xpath("(//tbody//tr//following::td[text()='Messages Requested'])[1]")).isDisplayed();
	driver.findElement(By.xpath("(//div[@id='statsTable']//following-sibling::td[text()='Messages Requested']//following::td[text()='Sent'])[1]")).isDisplayed();
	driver.findElement(By.xpath("(//div[@id='statsTable']//following-sibling::td[text()='Sent']//following::td[text()='Failed'])[1]")).isDisplayed();
	log.logging("Legend Sequence is verified for pie chart", "info");
	
}

@Then("^User verifies that Incoming message section is displayed$")
public void IncomingSection() {
	driver.findElement(By.xpath("//strong[contains(text(),'Incoming messages')]")).isDisplayed();
	log.logging("Incoming Message Section is displayd", "info");
}

@Then("^User verifies that Total incoming text is displayed$")
public void TotalIncomingText() {
	driver.findElement(By.xpath("//div[contains(text(),'Total Incoming')]")).isDisplayed();
	log.logging("Total Incoming text is displayd", "info");
}
//@Given("Date check")
//public void Date() throws Throwable {	
//	 DateFormat dateFormat = new SimpleDateFormat("Month D, Yr");
//	 
//	 //get current date time with Date()
//	 Date date = new DateTest();
//	 
//	 // Now format the date
//	 String date1= dateFormat.format(date);
//	 
//	 // Print the Date
//	 System.out.println(date1);
//	
//}
}

