package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class ConcurrentLoginFlow {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	SoftAssert sa;
	boolean bool;
	String url;
	String enterpriseAccId;
	String tokenCount;
	
	static String repoPath = "resources/Locators/Dlt.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	
	public ConcurrentLoginFlow() throws IOException {
		System.out.println("Present Project Directory : " + System.getProperty("user.dir"));
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
	}
@Then("^set the concurentlogin attr as \"([^\"]*)\"$")
public void set_the_concurentlogin_attr_as(String loginCount) throws IOException, InterruptedException
{
	enterpriseAccId = env.getEnterpriseAccountId();
	log.logging("Setting the Max concurrent login Attribute as 2", "info");
	Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
	boolean result = query.setDBResponse("settingConcurrentLogin", userId.toString());
}
@Then("^check the token count$")
public void check_the_token_count() throws IOException, InterruptedException {
	enterpriseAccId = env.getEnterpriseAccountId();
	Object count = query.getDBResponse(enterpriseAccId, "count(*)", "getCountOfToken");
	log.logging("Current count of  Token :"+ count.toString(), "info");
tokenCount=count.toString();
}
@Then("^check the error$")
public void check_the_error() {
	log.logging("Checking Error", "info");
	String youHaveExceeded = driver
			.findElement(By.xpath("//div[@classname='notification notificationRed']//div[1]")).getText();
	Assert.assertEquals(youHaveExceeded, "You have exceeded your concurrent login limit");
}
@Then("^delete the concurrent login attribute$")
public void delete_the_concurrent_login_attribute() throws IOException, InterruptedException {
	enterpriseAccId = env.getEnterpriseAccountId();
	log.logging("Deleting the Max concurrent login Attribute", "info");
	Object userId = query.getDBResponse(enterpriseAccId, "id", "getiingUserId");
	boolean result = query.setDBResponse("deleteConcurrentLogin", userId.toString());
}
@Then("^truncate the tokens$")
public void truncate_the_tokens() throws IOException {
	enterpriseAccId = env.getEnterpriseAccountId();
	log.logging("deleting token", "info");
	boolean result = query.setDBResponse("deleteToken", enterpriseAccId);
	log.logging("Deleting 1 Token ", "info");
	driver.findElement(By.id("phoneId")).clear();
}
@Then("^token count should be \"([^\"]*)\"$")
public void token_count_should_be(String token) throws Throwable {
	enterpriseAccId = env.getEnterpriseAccountId();
	Object count = query.getDBResponse(enterpriseAccId, "count(*)", "getCountOfToken");
	log.logging("Got Token Count for : " +enterpriseAccId  +" : "+count.toString(), "info");
	tokenCount=count.toString();
	Assert.assertEquals(token, tokenCount);
}
}






	