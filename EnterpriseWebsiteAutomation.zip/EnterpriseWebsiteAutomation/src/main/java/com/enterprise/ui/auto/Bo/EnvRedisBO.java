/**
 * 
 */
package com.enterprise.ui.auto.Bo;

import java.io.IOException;

import com.enterprise.ui.auto.utility.PropRead;

/**
 * @author Rahul Jain
 *
 */
public class EnvRedisBO {
	public String redisIp;
	public String redisPort;
	public String redisPass;
	public String env;

	public EnvRedisBO(String appRedis) throws IOException {
		PropRead pr = new PropRead();
		env = System.getProperty("env");
		String redis_path_config = "resources/redis.config.properties";
		redisIp = (pr.readConfig(env + "_Redis_" + appRedis + "_IP", redis_path_config));
		redisPort = (pr.readConfig(env + "_Redis_" + appRedis + "_PORT", redis_path_config));
		redisPass =(pr.readConfig(env + "_Redis_" + appRedis + "_Pass", redis_path_config));
	}

	public String getRedisPass() {
		return redisPass;
	}

	public String getEnv() {
		return env;
	}

	public String getRedisIp() {
		return redisIp;
	}

	public String getRedisPort() {
		return redisPort;
	}
}
