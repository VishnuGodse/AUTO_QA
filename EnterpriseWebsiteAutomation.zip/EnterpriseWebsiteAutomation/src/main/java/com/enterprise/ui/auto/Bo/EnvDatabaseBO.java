package com.enterprise.ui.auto.Bo;
import java.io.IOException;
import com.enterprise.ui.auto.utility.PropRead;


public class EnvDatabaseBO {
	public String dbUser;
	public String dbHost;
	public String dbPort;
	public String dbPass;
	public String env;

	public EnvDatabaseBO(String dbName) throws IOException {
		PropRead pr = new PropRead();

		env = System.getProperty("env");
		String db_path_config = "resources/db.config.properties";
		dbUser = (pr.readConfig(env + "_" + dbName + "_USER", db_path_config));
		dbHost = (pr.readConfig(env + "_" + dbName + "_HOST", db_path_config));
		dbPort = (pr.readConfig(env + "_" + dbName + "_PORT", db_path_config));
		dbPass = (pr.readConfig(env + "_" + dbName + "_PASS", db_path_config));
	}

	public String getDbUser() {
		return dbUser;
	}

	public String getDbHost() {
		return dbHost;
	}

	public String getDbPort() {
		return dbPort;
	}

	public String getDbPass() {
		return dbPass;
	}

	public String getEnv() {
		return env;
	}


}
