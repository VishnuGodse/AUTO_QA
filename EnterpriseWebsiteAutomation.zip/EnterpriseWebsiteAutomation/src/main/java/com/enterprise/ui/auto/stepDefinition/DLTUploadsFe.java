package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.DLTReadUtility;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.MessageCheckInFileUtility;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;



public class DLTUploadsFe
{
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
    String template_id;
    MessageCheckInFileUtility msgcheck;
    String userid;
    
    static String repoPath ="resources/Locators/DLTbulkupload.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	DLTReadUtility de=new DLTReadUtility();
	
	List<String> arr = new ArrayList<String>();
	List<String>available=new ArrayList<String>();
	 int teminc=0;
     String msgs = null,ti_d = null,mask = null,pe_id=null;
     String tidNo;
		boolean mask_v=false;
		boolean peid_v=false;
		boolean temp_v=false;

	public DLTUploadsFe() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		//locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		msgcheck=new MessageCheckInFileUtility();
		userid = env.getEnterpriseUsername();
				
	}
	   
	
	@Then("^Click on DLT template$")
	public void Click_on_DLT_template() throws InterruptedException 
	{
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//div[@id='dltTempListBtn']")).click();
		
		System.out.println("repo values "+repoPath); 
		/*
		 * By b1
		 * =PropertiesFileReader.getPropertylocator("repoPath","dlttemplatebut",locator)
		 * ;
		 */
		/*
		 * System.out.println("b values "+b1); driver.findElement(b1).click();
		 */
	 
		 
		driver.switchTo().activeElement();
		if(otherLang==true)
		{
			
			template_id=driver.findElement(By.xpath("//div[@id='unicodeDltTmplListTemplate_gupshup']//div[@id='dltTmplDiv_gupshup_unicode_1']//div[@id='messageTemplate_1007604933098561000']//div[@class='floatLeft']")).getText();
			System.out.println("Template_id ="+template_id);
			driver.findElement(By.xpath("//div[@id=\"messageTemplate_1007604933098561000\"]")).click();		
		}
		
		else if (flash == true) {
			log.logging("Setting  Flash Flag : " + flash, "info");
			driver.findElement(By.xpath(("messageTemplate_1007009238313466252"))).click();
			
		} else if (unicodeFlash == true) {
			log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

			driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

		} 
		else
		{
			template_id=driver.findElement(By.xpath("//div[@id='englishDltTmplListTemplate_gupshup']//div[@id='dltTmplDiv_gupshup_english_1']//div[@id='messageTemplate_1007009238313466252']//div[@class='floatLeft']")).getText();
			System.out.println("Template_id ="+template_id);
			driver.findElement(By.xpath("//div[@id='messageTemplate_1007009238313466252']")).click();	
			
		}
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 				 
		  WebElement okbutton=driver.findElement(By.xpath("//div[@id='editDltTemplatesDiv']//input[@class='tbButton' and @value='OK']"));

		//  By b1 = PropertiesFileReader.getPropertylocator("repoPath", "TemplateNameTextBox", ok_button);
		//  By b1= PropertiesFileReader.getPropertylocator("DLTbulkupload","ok_button",);
		//	driver.findElement(b1).sendKeys(GeneralUtlities.genRandomName(5));
			
			  JavascriptExecutor executor = (JavascriptExecutor) driver;
			  executor.executeScript("arguments[0].click();", okbutton);
			  Thread.sleep(10000);
		
	}
	
	@Then("^click on Other Language Tab$")
	public void click_on_Other_Language_Tab() throws InterruptedException {
		otherLang = true;
		//log.logging("Setting Unicode Flag : " + otherLang, "info");

		driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
		Thread.sleep(5000);
	}
	
	
	@Then("^User activates template$")
	public void User_activates_template() throws InterruptedException, Exception 
	{
		Object userId = query.getDBResponse(userid, "id", "getiingUserId");
		
		boolean result = query.setDBResponse("setCallTemplateServiceTrue", userId.toString());
		boolean result1 = query.setDBResponse("callTemplateServiceDLTPass", userId.toString());
	}
	
	@Then("^enable the mask feature$")
	public void enable_the_mask_feature() throws InterruptedException, Exception 
	{
		Object userId = query.getDBResponse(userid, "id", "getiingUserId");
		boolean result = query.setDBResponse("SetEntrMask", userId.toString());
	}
	
	@Then("^update the attribute$")
	public void update_attribute() throws InterruptedException, Exception
	{
		Object userId = query.getDBResponse(userid, "id", "getiingUserId");
		boolean result = query.setDBResponse("setCallTemplateServiceTrue", userId.toString());
	}
	
	@Then("^set peid as blank$")
	public void set_peid_as_blank() throws InterruptedException, Exception 
	{
		Object userId = query.getDBResponse(userid, "id", "getiingUserId");
		boolean result = query.setDBResponse("SetPeid", userId.toString());
	}
	
	
	@Then("^Upload the DLT_File$")
	public void f(DataTable files) throws InterruptedException, IOException {
		try {
			for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
				if (otherLang == true) {

					log.logging("Selecting Unicode Tab  Tab", "info");
					driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
					Thread.sleep(5000);
				} else if (flash == true) {
					log.logging("Setting  Flash Flag : " + flash, "info");

					driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
					Thread.sleep(5000);
				} else if (unicodeFlash == true) {
					log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

					driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

				} else {
					log.logging("Selecting Text Tab final", "info");

					WebElement element = driver.findElement(
							By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));

					Actions action = new Actions(driver);

					action.moveToElement(element).click().perform();


					log.logging("Selecting Text Tab final", "info");

					driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
				}

				driver.findElement(By.id("defaultMsg")).clear();
				driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

				String response = null;
				String filename = fileUpload.get("FileName");
				String f=filename;

				log.logging("Passing the file: " + filename, "info");
				filename = System.getProperty("user.dir") + "\\DLT_SMS_Upload\\" + filename;
				
				String path=System.getProperty("user.dir") + "\\DLT_SMS_Upload\\";
				driver.findElement(By.id("xlsFile")).sendKeys(filename);
				Thread.sleep(5000);
				System.out.println("filename"+filename);
				log.logging("Clicking on Upload Button", "info");
				
				Thread.sleep(1000);
				arr = de.readData(path, f, 0);

			        try {
			        	 
							for (int i = 0;i <=arr.size()-1; i++)
							{

								System.out.println(arr.get(i).toString());
								String s=arr.get(i).toString();
								int c=de.charCount(s);
								if(c==10)
								{
									System.out.println("Phone");
									available.add("phone");
								}
								if(s.contains(" ")&&(c>10))
								{
									System.out.println("Msg");	
									available.add("msg");
									msgs=s;
									System.out.println("msgs"+msgs);
								}
								if(c<8)
								{
									System.out.println("Mask");
									available.add("mask");
									mask=s;
								}
								if(c==19)
								{
									if(teminc==0)
									{
										System.out.println("Template id");
										available.add("dltid");
										ti_d=s;
									}
									if(teminc==1)
									{
										System.out.println("PE id");
										available.add("peid");
										pe_id=s;
									}
									teminc++;
								}
								
							}
							
							
							for(int j=0;j<available.size()-1;j++)
							{
								if(available.get(j).equalsIgnoreCase("dltid"))
								{
									System.out.println("Tid no "+ti_d);
								    tidNo=ti_d;
								    temp_v=true;
								    
								}
								if(available.get(j).equalsIgnoreCase("mask"))
								{
									mask_v=true;	
								}
								if(available.get(j).equalsIgnoreCase("peid"))
										{
									     peid_v=true;
										}
							}
								
			        }
			        catch(Exception e)
			        {
			        	System.out.println("Exception "+e);
			        }
				
					  
					  
				 		
				boolean hisTabPresent;
				try {
					hisTabPresent = driver.findElement(By.linkText("History")).isDisplayed();
				} catch (Exception e) {
					hisTabPresent = false;
				}
				Thread.sleep(5000);
				if (hisTabPresent == true) {
					driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();

				} else {
					driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
				}
				log.logging("Clicked on Upload Button", "info");
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();

				log.logging("Checking HistoryTab Present or not", "info");
				String causeId = response.replaceAll("[^0-9]", "").trim();

				if (hisTabPresent == true) {
					log.logging("We have history tab so validation is according to History tab", "info");

					log.logging("We got response on Upload :" + response, "info");

				
					log.logging("We got causeId in response  :" + causeId, "info");
					log.logging("Matching the Response", "info");

					sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
					log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

					driver.findElement(By.linkText("History")).click();

					String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
					sa.assertEquals(trans.trim(), causeId);
					log.logging("Yay!! We found our Transaction", "info");
					log.logging("Now Checking the Status as UPLOADED", "info");
					String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
					sa.assertEquals(status, "UPLOADED");

					log.logging("Now Checking Preview", "info"); // commted because it is unstable
					Thread.sleep(5000);
					driver.findElement(By.xpath("//img[@title='Preview']")).click();
					Thread.sleep(10000);
					log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
					
					Thread.sleep(3000);
					log.logging("Now Closing the Preview POP UP!!", "info");
					driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
					// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
					Thread.sleep(3000);
					log.logging("Now Actually Posting the Campaign!", "info");
					Thread.sleep(3000);

					driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
					Thread.sleep(3000);
					// driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
					Alert alert = driver.switchTo().alert();
					Thread.sleep(3000);

					alert.accept();
					response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
							.getText();
					/*
					 * sa.assertEquals(response, "Your file is being processed. Transaction id " +
					 * causeId + ". Please refer upload history below for final status.");
					 */
					log.logging("Now Checking the Status as SENT", "info");
					Thread.sleep(2000);

					status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
					su.refreshPage();
					sa.assertEquals(status, "SENT");

					driver.findElement(By.linkText("History")).click();
					log.logging("Now Clicking the Sent Tab", "info");

					driver.findElement(By.id("tabName_sent")).click();
					Thread.sleep(3000);
					log.logging("Now Checking our causeId is present or not", "info");
					String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

					sa.assertEquals(causeIdValidation, causeId);
					log.logging("Now Checking Campign is successfull or not", "info");

					String forTheTransaction = driver
							.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
							.getText();

					boolean successChk = (forTheTransaction.contains("successfully")
							&& forTheTransaction.contains(causeId));
					sa.assertEquals(successChk, true);
					driver.findElement(By.linkText("Bulk")).click();
					Thread.sleep(2000);

				} else {
					log.logging("History Tab Not Present", "info");
					/*
					 * Thread.sleep(5000); response = driver.findElement(By.
					 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
					 * .getText();
					 */

					log.logging("Got Response after Posting : " + response, "info");
					// String causeId = response.replaceAll("[^0-9]", "").trim();

					log.logging("Taking causeId from Response and we got  : " + causeId, "info");

					String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG'][1]//td//a)[1]"))
							.getText();
					sa.assertEquals(actualCauseId, causeId);
					log.logging("Yay! we got the causeId in table  : " + causeId, "info");
					Thread.sleep(5000);
					su.refreshPage();
					String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2]//td)[1]"))
							.getText();
					System.out.println(forTheTransaction);
					boolean successChk = (forTheTransaction.contains("successfully")
							&& forTheTransaction.contains(causeId));
					sa.assertEquals(successChk, true);
				}
				Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
				log.logging(metadata.toString(), "debug");
				boolean postMsgType = metadata.toString().contains("pmt=2");
				log.logging(String.valueOf(postMsgType), "debug");
				
				Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
						"gettingMsgLogGroupPostForTransactionTuples");
				
				
				if(temp_v=true)
		        {
					/*
					 * tidNo=ti_d; Object userId = query.getDBResponse(userid, "id",
					 * "getiingUserId"); Object metadata11 = query.getDBResponse(tidNo,"metadata",
					 * "TemplateIdCheck"); log.logging(metadata11.toString(), "debug"); boolean
					 * dltidNo = metadata11.toString().contains("dltid="+tidNo);
					 * log.logging(String.valueOf(dltidNo), "debug");
					 * log.logging("Matching htidNo is " + tidNo, "info"); sa.assertEquals(dltidNo,
					 * true, "dltidNo Not Matched");
					 * 
					 * boolean peid=metadata11.toString().contains("peid");
					 * log.logging(String.valueOf(peid), "debug");
					 * log.logging("Verifying whether peid has value", "info");
					 * sa.assertEquals(true, peid);
					 * 
					 * boolean status=metadata11.toString().contains("status=0");
					 * log.logging(String.valueOf(status), "debug");
					 * log.logging("Verifying whether status has value 0", "info");
					 * sa.assertEquals(true, status);
					 */
						 
		        }
		        else
		        {
					/*
					 * Object tid = query.getDBResponse(msgs,"dltTemplateId", "GetDLTtemplateID");
					 * 
					 * log.logging(tid.toString(), "debug"); tidNo = tid.toString();
					 * System.out.println("tidNO............................."+tidNo);
					 * 
					 * Thread.sleep(1000);
					 * 
					 * if(tidNo.isEmpty()) { log.logging(String.valueOf(tidNo), "debug"); }
					 * 
					 * else { boolean dltidNo = metadata.toString().contains("dltid="+tidNo);
					 * log.logging(String.valueOf(dltidNo), "debug");
					 * log.logging("Matching htidNo is " + tidNo, "info"); sa.assertEquals(dltidNo,
					 * true, "dltidNo Not Matched"); }
					 * 
					 * boolean peid=metadata.toString().contains("peid");
					 * log.logging(String.valueOf(peid), "debug");
					 * log.logging("Verifying whether peid has value", "info");
					 * sa.assertEquals(true, peid);
					 * 
					 * boolean status=metadata.toString().contains("status=0");
					 * log.logging(String.valueOf(status), "debug");
					 * log.logging("Verifying whether status has value 0", "info");
					 * sa.assertEquals(true, status);
					 */
		        }
				
				if(mask_v=true)
		        {
					/*
					 * Object metadata1 = query.getDBResponse(causeId, "mask", "GetmaskMsgLog");
					 * 
					 * log.logging(metadata1.toString(), "debug"); boolean maskdata =
					 * metadata1.toString().contains(mask); sa.assertEquals(maskdata, true);
					 * log.logging("Test"+maskdata,"info");
					 */
		        }

				String[] wNo = webarooNo.toString().split(",");
				if (otherLang == true) {
					log.logging("Checking Webaroo No as 3 for unicode", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "3");
				} else if (flash == true) {
					log.logging("Checking Webaroo No as 5 for flash", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "5");
				} else if (unicodeFlash == true) {
					log.logging("Checking Webaroo No as 20 for unicode_flash", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "20");
				} else {
					log.logging("Checking Webaroo No as 0 for text Message", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "0");
				}
			}
		}
		
			catch(Exception e)
			{
				System.out.println("Exception "+e);
			}
		
	
	//
	
	
	sa.assertAll();

	}

	
	@Then("^Upload the DLT Files$")
	public void fs(DataTable files) throws InterruptedException, IOException {
		try {
			for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
				if (otherLang == true) {

					log.logging("Selecting Unicode Tab  Tab", "info");
					driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
					Thread.sleep(5000);
				} else if (flash == true) {
					log.logging("Setting  Flash Flag : " + flash, "info");

					driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
					Thread.sleep(5000);
				} else if (unicodeFlash == true) {
					log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

					driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

				} else {
					log.logging("Selecting Text Tab final", "info");

					WebElement element = driver.findElement(
							By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));

					Actions action = new Actions(driver);

					action.moveToElement(element).click().perform();


					log.logging("Selecting Text Tab final", "info");

					driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
				}

				driver.findElement(By.id("defaultMsg")).clear();
				driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

				String response = null;
				String filename = fileUpload.get("FileName");

				log.logging("Passing the file: " + filename, "info");
				filename = System.getProperty("user.dir") + "\\DLT_SMS_Upload\\" + filename;
				driver.findElement(By.id("xlsFile")).sendKeys(filename);
				Thread.sleep(5000);
				System.out.println("filename"+filename);
				log.logging("Clicking on Upload Button", "info");
				
				
				
			//	String result=msgcheck.getMessageFromFile(filename,System.getProperty("user.dir") + "\\DLT_SMS_Upload\\" + filename);
				
				String result=msgcheck.getMessageFromFile(filename,System.getProperty("user.dir") + "\\DLT_SMS_Upload\\");
				String start = result;
				//String start = StringUtils.substringBefore(result, "|").trim(); 
				//String start=StringUtils.substringBeforeLast(result, "|");
				System.out.println("Result of zip "+start);
				
				
				
					
				Object tid = query.getDBResponse(start, "dltTemplateId", "GetDLTtemplateID");
					
					  log.logging(tid.toString(), "debug"); 
					  String tidNo = tid.toString();
					  System.out.println("tidNO............................."+tidNo);
				
					  
					  
				 		
				boolean hisTabPresent;
				try {
					hisTabPresent = driver.findElement(By.linkText("History")).isDisplayed();
				} catch (Exception e) {
					hisTabPresent = false;
				}
				Thread.sleep(5000);
				if (hisTabPresent == true) {
					driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();

				} else {
					driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
				}
				log.logging("Clicked on Upload Button", "info");
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();

				log.logging("Checking HistoryTab Present or not", "info");
				String causeId = response.replaceAll("[^0-9]", "").trim();

				if (hisTabPresent == true) {
					log.logging("We have history tab so validation is according to History tab", "info");

					log.logging("We got response on Upload :" + response, "info");

				
					log.logging("We got causeId in response  :" + causeId, "info");
					log.logging("Matching the Response", "info");

					sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
					log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

					driver.findElement(By.linkText("History")).click();

					String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
					sa.assertEquals(trans.trim(), causeId);
					log.logging("Yay!! We found our Transaction", "info");
					log.logging("Now Checking the Status as UPLOADED", "info");
					String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
					sa.assertEquals(status, "UPLOADED");

					log.logging("Now Checking Preview", "info"); // commted because it is unstable
					Thread.sleep(5000);
					driver.findElement(By.xpath("//img[@title='Preview']")).click();
					Thread.sleep(10000);
					log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
					
					Thread.sleep(3000);
					log.logging("Now Closing the Preview POP UP!!", "info");
					driver.findElement(By.xpath("//a[@class='popCloseBtn floatRight']")).click();
					// driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
					Thread.sleep(3000);
					log.logging("Now Actually Posting the Campaign!", "info");
					Thread.sleep(3000);

					driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
					Thread.sleep(3000);
					// driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
					Alert alert = driver.switchTo().alert();
					Thread.sleep(3000);

					alert.accept();
					response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
							.getText();
					/*
					 * sa.assertEquals(response, "Your file is being processed. Transaction id " +
					 * causeId + ". Please refer upload history below for final status.");
					 */
					log.logging("Now Checking the Status as SENT", "info");
					Thread.sleep(2000);

					status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
					su.refreshPage();
					sa.assertEquals(status, "SENT");

					driver.findElement(By.linkText("History")).click();
					log.logging("Now Clicking the Sent Tab", "info");

					driver.findElement(By.id("tabName_sent")).click();
					Thread.sleep(3000);
					log.logging("Now Checking our causeId is present or not", "info");
					String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

					sa.assertEquals(causeIdValidation, causeId);
					log.logging("Now Checking Campign is successfull or not", "info");

					String forTheTransaction = driver
							.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
							.getText();

					boolean successChk = (forTheTransaction.contains("successfully")
							&& forTheTransaction.contains(causeId));
					sa.assertEquals(successChk, true);
					driver.findElement(By.linkText("Bulk")).click();
					Thread.sleep(2000);

				} else {
					log.logging("History Tab Not Present", "info");
					/*
					 * Thread.sleep(5000); response = driver.findElement(By.
					 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
					 * .getText();
					 */

					log.logging("Got Response after Posting : " + response, "info");
					// String causeId = response.replaceAll("[^0-9]", "").trim();

					log.logging("Taking causeId from Response and we got  : " + causeId, "info");

					String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG'][1]//td//a)[1]"))
							.getText();
					sa.assertEquals(actualCauseId, causeId);
					log.logging("Yay! we got the causeId in table  : " + causeId, "info");
					Thread.sleep(5000);
					su.refreshPage();
					String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2]//td)[1]"))
							.getText();
					System.out.println(forTheTransaction);
					boolean successChk = (forTheTransaction.contains("successfully")
							&& forTheTransaction.contains(causeId));
					sa.assertEquals(successChk, true);
				}
				Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
				log.logging(metadata.toString(), "debug");
				boolean postMsgType = metadata.toString().contains("pmt=2");
				log.logging(String.valueOf(postMsgType), "debug");
				log.logging("Matching Post Message Type Status is 2", "info");
				sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
				Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
						"gettingMsgLogGroupPostForTransactionTuples");
				
				
				if(tidNo.isEmpty())
				{
					log.logging(String.valueOf(tidNo), "debug");	
				}
				
				else 
				{
				 boolean dltidNo = metadata.toString().contains("dltid="+tidNo); 
				 log.logging(String.valueOf(dltidNo), "debug");
				 log.logging("Matching htidNo is " + tidNo, "info");
				 sa.assertEquals(dltidNo, true, "dltidNo Not Matched");
				} 
				
				 
				boolean peid=metadata.toString().contains("peid");
				log.logging(String.valueOf(peid), "debug");
				log.logging("Verifying whether peid has value", "info");
				sa.assertEquals(true, peid);
				
				boolean status=metadata.toString().contains("status=0");
				log.logging(String.valueOf(status), "debug");
				log.logging("Verifying whether status has value 0", "info");
				sa.assertEquals(true, status);
				
				
				
				System.out.println("peid"+String.valueOf(peid));
				if (webarooNo.toString() == null) {
					log.logging("MsgTupple did not found in DB", "info");
					System.out.println("MsgTupple did not found in DB");
					break;
				}

				String[] wNo = webarooNo.toString().split(",");
				if (otherLang == true) {
					log.logging("Checking Webaroo No as 3 for unicode", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "3");
				} else if (flash == true) {
					log.logging("Checking Webaroo No as 5 for flash", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "5");
				} else if (unicodeFlash == true) {
					log.logging("Checking Webaroo No as 20 for unicode_flash", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "20");
				} else {
					log.logging("Checking Webaroo No as 0 for text Message", "info");
					log.logging("Got Webaroo No " + wNo[1].trim(), "info");

					sa.assertEquals(wNo[1].trim(), "0");
				}
			}
		}
		
			catch(Exception e)
			{
				System.out.println("Exception "+e);
			}
		
	
	//
	
	
//	sa.assertAll();

	}
	
	public int charCount(String s) {
		int count = 0;

		// Counts each character except space
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) != ' ')
				count++;
		}
		return count;

	}
}


