package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Then;
import junit.framework.Assert;

public class keywordFlow {

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
//	SoftAssert sa;
	String userid;

	public keywordFlow() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
//		sa = new SoftAssert();
		userid = env.getEnterpriseUsername();

	}
	
	@Then("^Check the Keywords Page if present$")
	public void check_the_Keywords_Page_if_present()  {
		
		driver.findElement(By.xpath("//span[text()='Keywords']")).click();
		
		
		
	}

	@Then("^Create keyword by response url$")
	public void create_keyword_by_response_url() throws InterruptedException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);

		String saltStr = gu.genRandomName(5);
		

		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isCallBackUrl")).click();
		driver.findElement(By.name("keywordGroupCallBackURL")).sendKeys("http://abc.com");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate = format1.format(nextMonthLastDay);

		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr);
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(10000);

	}

	@Then("^Create keyword by default response$")
	public void create_keyword_by_default_response() throws InterruptedException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);
		String saltStr = gu.genRandomName(5);
		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isSetDefault")).click();
		driver.findElement(By.name("keywordDefaultResponse")).sendKeys("Test Response");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");
//		select.selectByIndex(2);

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate = format1.format(nextMonthLastDay);

		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr);
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(10000);

	}

	@Then("^Create keyword and check it is present in awaiting approval$")
	public void create_keyword_and_check_it_is_present_in_awaiting_approval() throws InterruptedException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);

		
		String saltStr = gu.genRandomName(5);

		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isCallBackUrl")).click();
		driver.findElement(By.name("keywordGroupCallBackURL")).sendKeys("http://abc.com");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate = format1.format(nextMonthLastDay);

		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr);
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(10000);

		Boolean result = driver.findElement(By.xpath("//table/tbody/tr//a[contains(text(), '" + saltStr + "')]"))
				.isDisplayed();

//		Assert.assertEquals("Group Name exist in awaiting approval", true, result);

	}

	@Then("^Create keyword and delete it from awaiting approval$")
	public void create_keyword_and_delete_it_from_awaiting_approval() throws InterruptedException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);

		// ***********Random String for Keyword********************************
//		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
//		StringBuilder salt = new StringBuilder();
//		Random rnd = new Random();
//		while (salt.length() < 5) { // length of the random string.
//			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
//			salt.append(SALTCHARS.charAt(index));
//		}
//		String saltStr = salt.toString();
		// *********************************************************************
		
		String saltStr = gu.genRandomName(5);

		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isCallBackUrl")).click();
		driver.findElement(By.name("keywordGroupCallBackURL")).sendKeys("http://abc.com");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate = format1.format(nextMonthLastDay);

		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr);
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(10000);

		driver.findElement(By.xpath("//table/tbody/tr//a[contains(text(), '" + saltStr + "')]/../input")).click();
//		Thread.sleep(3000);

		driver.findElement(By.id("pendingKeywordGroupsRemoveButton")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);

	}

	@Then("^Create enabling the keyword from support servlet and validate keyword in Active Keyword Groups section$")
	public void Create_enabling_the_keyword_from_support_servlet_and_validate_keyword_in_Active_Keyword_Groups_section()
			throws InterruptedException, IOException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);
		

		// ***********Random String for Keyword********************************
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < 5) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();
		// *********************************************************************

		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isCallBackUrl")).click();
		driver.findElement(By.name("keywordGroupCallBackURL")).sendKeys("http://abc.com");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
		String futureDate = format1.format(nextMonthLastDay);
		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr); 
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(10000);
		
		
		log.logging("Got user id" + userid, "info");
		Object userId = query.getDBResponse(userid, "id", "getiingUserId");
		boolean result1 = query.setDBResponse("updateCampaign", userId.toString(), saltStr);
		boolean result2 = query.setDBResponse("UpdateCampaignUnit", userId.toString(), saltStr);
		Thread.sleep(2000);
		
		driver.navigate().refresh();
		
		Boolean result = driver.findElement(By.xpath("//table/tbody/tr//a[contains(text(), '" + saltStr + "')]"))
				.isDisplayed();

//		Assert.assertEquals("Group Name exist in awaiting approval", true, result);

	}
	
	@Then("^Edit the keyword for changing the Response URL$")
	public void edit_the_keyword_for_changing_the_Response_URL() throws InterruptedException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);

		
		String saltStr = gu.genRandomName(5);
		Thread.sleep(2000);

		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isCallBackUrl")).click();
		driver.findElement(By.name("keywordGroupCallBackURL")).sendKeys("http://abc.com");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate = format1.format(nextMonthLastDay);

		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr);
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(5000);
		driver.navigate().refresh();

		driver.findElement(By.xpath("//table/tbody/tr//a[contains(text(), '" + saltStr + "')]"))
				.click();
		driver.findElement(By.xpath("//*[@id=\"editGroupDetail\"]")).click();
		driver.findElement(By.name("keywordGroupCallBackURL")).sendKeys("http://xyz.com");
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(3000);

	}
	
	@Then("^Edit the keyword for changing the default response$")
	public void edit_the_keyword_for_changing_the_default_response() throws InterruptedException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);
		String saltStr = gu.genRandomName(5);
		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isSetDefault")).click();
		driver.findElement(By.name("keywordDefaultResponse")).sendKeys("Test Response");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");
//		select.selectByIndex(2);

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate = format1.format(nextMonthLastDay);

		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr);
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(5000);
		driver.navigate().refresh();

		driver.findElement(By.xpath("//table/tbody/tr//a[contains(text(), '" + saltStr + "')]"))
				.click();
		driver.findElement(By.xpath("//*[@id=\"editGroupDetail\"]")).click();
		driver.findElement(By.name("keywordDefaultResponse")).sendKeys("Test Response Edited");
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(3000);

	}
	
	
	@Then("^Edit the keyword for changing the date and name of the keyword$")
	public void edit_the_keyword_for_changing_the_date_and_name_of_the_keyword() throws InterruptedException {

		Boolean element = driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).isDisplayed();
		
		if (element == true) {
			driver.findElement(By.xpath("//*[@id=\"noActiveKeywordGroupListSuperContainer\"]/a")).click();
		}
		else
		{
			driver.findElement(By.xpath("//*[@id=\"updateMaskMappingBtnTop\"]/input")).click();
		}
		Thread.sleep(2000);
		String saltStr = gu.genRandomName(5);
		driver.findElement(By.name("keywordGrpName")).sendKeys(saltStr);
		driver.findElement(By.name("isSetDefault")).click();
		driver.findElement(By.name("keywordDefaultResponse")).sendKeys("Test Response");

		Select select = new Select(driver.findElement(By.name("maskSelectBoxKeywordGrpContainer")));
		select.selectByValue("SWGJOB");
//		select.selectByIndex(2);

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay = cal.getTime();
		SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate = format1.format(nextMonthLastDay);

		String currentDate = dateFormat.format(date);
		System.out.println("Future date is " + futureDate);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate);

		driver.findElement(By.name("kw_1")).sendKeys(saltStr);
		driver.findElement(By.name("phoneSelect_1")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"phonecode_1_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"pdiv1\"]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(5000);
		driver.navigate().refresh();

		driver.findElement(By.xpath("//table/tbody/tr//a[contains(text(), '" + saltStr + "')]"))
				.click();
		driver.findElement(By.xpath("//*[@id=\"editGroupDetail\"]")).click();
//		driver.findElement(By.name("keywordDefaultResponse")).sendKeys("Test Response Edited");
		
		
		DateFormat dateFormatedit = new SimpleDateFormat("MM/dd/yyyy");
		Date date_edit = new Date();

		Calendar calEdit = Calendar.getInstance();
		calEdit.add(Calendar.MONTH, 2);
		calEdit.set(Calendar.DATE, calEdit.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date nextMonthLastDay1 = cal.getTime();
		SimpleDateFormat format2 = new SimpleDateFormat("MM/dd/yyyy");

		String futureDate1 = format2.format(nextMonthLastDay1);

		String currentDate1 = dateFormatedit.format(date_edit);
		System.out.println("Future date is " + futureDate1);

		driver.findElement(By.name("startDate")).clear();
		driver.findElement(By.name("startDate")).sendKeys(currentDate1);
		driver.findElement(By.name("endDate")).clear();
		driver.findElement(By.name("endDate")).sendKeys(futureDate1);
		
		
		driver.findElement(By.name("kw_1")).sendKeys(saltStr + "Edit");
		
		driver.findElement(By.xpath("//*[@id=\"keywordGroupDefineBtn\"]/input")).click();
		Thread.sleep(3000);

	}


}
