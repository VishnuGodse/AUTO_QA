/*package com.enterprise.ui.auto.stepDefinition;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.DbConnectionUtility;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.sun.mail.iap.Response;

import cucumber.api.DataTable;
//import io.cucumber.java.cs.Ale;
import cucumber.api.java.en.Then;
//import io.cucumber.java.it.Date;

public class BulkUpload {
	String balance;

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;

	public BulkUpload() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
	}

	@Then("^Enable the preview Attributes$")
	public void enable_the_preview_Attribute() throws IOException, InterruptedException {
		aggrAccId = env.getEnterpriseUsername();
		System.out.println("got the userId" + aggrAccId);
		Object userId = query.getDBResponse(aggrAccId, "id", "getiingUserId");
		System.out.println(userId);
		boolean result = query.setDBResponse("settingPreviewOn", userId.toString());

		if (result == false) {
			log.logging("History Tab Attribute not present so inserting in userId" + userId + " setting value as true",
					"info");

			query.setDBResponse("insertpreviewTrue", userId.toString());
		}

		Thread.sleep(5000);
		su.refreshPage();
	}

	@Then("^Upload the File$")
	public void upload_the_File(DataTable files) throws InterruptedException, IOException {

		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			if (otherLang == true) {

				log.logging("Selecting Unicode Tab  Tab", "info");
				driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
				Thread.sleep(5000);
			} else if (flash == true) {
				log.logging("Setting  Flash Flag : " + flash, "info");

				driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
				Thread.sleep(5000);
			} else if (unicodeFlash == true) {
				log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

				driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();

			} else {
				log.logging("Selecting Text Tab final", "info");
//				Thread.sleep(20000);
//				WebDriverWait wait = new WebDriverWait(driver, 10);
				// WebElement
				// elementTextTab=wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[id=postTypeHeaderEnglishSmsSpan]")));
				WebElement element = driver.findElement(
						By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//			JavascriptExecutor executor = (JavascriptExecutor)driver;
//			executor.executeScript("arguments[0].click();", element);
//			Thread.sleep(5000);
				Actions action = new Actions(driver);

				action.moveToElement(element).click().perform();

//				WebElement Button1 =driver.findElement(By.xpath("//div[@id='quickActionsContainer']//div[@classname='activeQuickActionTab']"));
//				Button1.submit();
//				Thread.sleep(5000);

				log.logging("Selecting Text Tab final", "info");

				// elementTextTab.sendKeys(Keys.ENTER);
				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}

			driver.findElement(By.id("defaultMsg")).clear();
			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/BulkUploadFiles/" + filename;
			driver.findElement(By.id("xlsFile")).sendKeys(filename);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			boolean hisTabPresent = su.elemCheck("History");
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();

			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}
			log.logging("Clicked on Upload Button", "info");
			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {
				log.logging("We have history tab so validation is according to History tab", "info");

				
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");

				log.logging("Now Checking Preview", "info");

				driver.findElement(By.xpath("(//img[@alt='Preview'])[1]")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				log.logging("Now Closing the Preview POP UP!!", "info");

				driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				log.logging("Now Actually Posting the Campaign!", "info");

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG'][1]//td//a)[1]"))
						.getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the causeId in table  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2]//td)[1]"))
						.getText();
				System.out.println(forTheTransaction);
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
			}
			Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			if (webarooNo.toString() == null) {
				log.logging("MsgTupple did not found in DB", "info");
				System.out.println("MsgTupple did not found in DB");
				break;
			}

			String[] wNo = webarooNo.toString().split(",");
			if (otherLang == true) {
				log.logging("Checking Webaroo No as 3 for unicode", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "3");
			} else if (flash == true) {
				log.logging("Checking Webaroo No as 5 for flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "5");
			} else if (unicodeFlash == true) {
				log.logging("Checking Webaroo No as 20 for unicode_flash", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "20");
			} else {
				log.logging("Checking Webaroo No as 0 for text Message", "info");
				log.logging("Got Webaroo No " + wNo[1].trim(), "info");

				sa.assertEquals(wNo[1].trim(), "0");
			}
		}
		sa.assertAll();
	}

	@Then("^Disable the preview Attributes$")
	public void disable_the_preview_Attribute() throws IOException, InterruptedException {
		aggrAccId = env.getEnterpriseAccountId();

		Object userId = query.getDBResponse(aggrAccId, "id", "getiingUserId");
		System.out.println(userId);
		boolean result = query.setDBResponse("settingPreviewOff", userId.toString());

		if (result == false) {
			log.logging("History Tab Attribute not present so inserting in userId" + userId + " setting value as false",
					"info");

			query.setDBResponse("insertpreviewFalse", userId.toString());
		}
	}

	@Then("^Choose MsgType,message,phoneNo and post  the message  and check balance$")
	public void choose_MsgType_message_phoneNo_and_post_the_message_and_check_balance(DataTable msgtypemsg)
			throws Throwable {

		for (Map<String, String> mappingMsg : msgtypemsg.asMaps(String.class, String.class)) {
			int phoneNocnt;
			String response = null;
			String responseExp = null;

			log.logging("Passing the Phone No : " + phoneNo, "info");
			if (mappingMsg.get("MessageType").equalsIgnoreCase("Text")) {
				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}
			if (mappingMsg.get("MessageType").equalsIgnoreCase("Unicode_Text")) {
				driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
			}
			if (mappingMsg.get("MessageType").equalsIgnoreCase("Flash")) {
				driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
			}
			if (mappingMsg.get("MessageType").equalsIgnoreCase("Unicode_Flash")) {
				driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();
			}
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//textarea[@id='quickPostNumberBox'])[1]")).sendKeys(phoneNo);
			String msg = mappingMsg.get("Message");
			log.logging("Cleaning the Message Box", "info");
			driver.findElement(By.xpath("(//textarea[@id='quickPostTextArea'])[1]")).clear();
			log.logging("Passing the Message : " + msg, "info");
			driver.findElement(By.xpath("(//textarea[@id='quickPostTextArea'])[1]")).sendKeys(msg);
			driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[1]")).click();
			log.logging("Submitting the Message ", "info");
			Thread.sleep(2000);
			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();
			log.logging("Checking response after submitting ", "info");
			if (phoneNo.contains(",")) {
				String[] phoneArr = phoneNo.split(",");
				phoneNocnt = phoneArr.length;
				responseExp = "Your messages will be sent shortly subject to Current Status of your account.Messages sent to "
						+ phoneNocnt + " phone numbers.";
			} else {
				phoneNocnt = 1;
				responseExp = "Your messages will be sent shortly subject to Current Status of your account.";

			}
			Assert.assertEquals(response, responseExp);
			su.refreshPage();
			String balancetmp = driver.findElement(By.xpath("(//span[@class='strong'])[1]")).getText();
			String newbalance = balancetmp.replaceAll("[^0-9]", "").trim();
			log.logging("Checking new  balance : " + balance + " and old balance : " + newbalance, "info");
			int newbalanceint = Integer.parseInt(newbalance);
			newbalanceint = (Integer.parseInt(balance) - newbalanceint);
			Assert.assertEquals(newbalanceint, 6);
			balance = newbalance;

		}
	}

	@Then("^Click on Make a Post with message \"([^\"]*)\"$")
	public void click_on_Make_a_Post_with_message(String msg) throws InterruptedException {
		log.logging("Posting wih Message " + msg, "info");
		su.refreshPage();

		driver.findElement(By.xpath("(//div[@class='inactiveQuickActionTab'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).clear();
		Thread.sleep(2000);

		driver.findElement(By.xpath("(//textarea[@rows='4'])[1]")).sendKeys(msg);

		Thread.sleep(2000);

	}

	@Then("^Click on Make a Post$")
	public void click_on_Make_a_Post() {
		log.logging("Clicking on Post Button", "info");

		driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[1]")).click();
	}

	@Then("^Check the DB Response$")
	public void check_the_DB_Response() throws IOException, InterruptedException {
		String response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
				.getText();
		String causeId = response.replaceAll("[^0-9]", "").trim();
		log.logging("Got CauseId : " + causeId, "info");
		Object status = query.getDBResponse(causeId, "status", "gettingMsgLogGroupPost");
		log.logging("Got Group Post Status   : " + status, "info");
		Assert.assertEquals(status.toString(), "PROCESSED");

	}

	@Then("^click on Other Langauge Tab$")
	public void click_on_Other_Langauge_Tab() throws InterruptedException {
		otherLang = true;
		log.logging("Setting Unicode Flag : " + otherLang, "info");

		driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
		Thread.sleep(5000);
	}

	@Then("^click on Flash Tab$")
	public void click_on_Flash_Tab() throws InterruptedException {
		flash = true;
		log.logging("Setting  Flash Flag : " + flash, "info");

		driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
		Thread.sleep(5000);

	}

	@Then("^click on Unicode_Flash Tab$")
	public void click_on_Unicode_Flash_Tab() throws InterruptedException {
		unicodeFlash = true;
		log.logging("Setting  UnicodeFlash Flag : " + unicodeFlash, "info");

		driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();
		Thread.sleep(5000);

	}

	@Then("^Upload the File only Numbers$")
	public void upload_the_File_only_Numbers(DataTable data) throws InterruptedException, IOException {
		for (Map<String, String> dataMap : data.asMaps(String.class, String.class)) {
			String fileName = dataMap.get("FileName");
			String msgType = dataMap.get("MsgType");
			String wbNo = dataMap.get("WebarooNo");
			log.logging("The webaroo no from datamap is" + wbNo, "info");
			String msg = dataMap.get("Message");
			if (msgType.equalsIgnoreCase("Unicode_Text")) {
				click_on_Other_Langauge_Tab();
			} else if (msgType.equalsIgnoreCase("Flash")) {
				click_on_Flash_Tab();
			} else if (msgType.equalsIgnoreCase("Unicode_Flash")) {
				click_on_Unicode_Flash_Tab();
			} else {
				log.logging("Selecting Text Tab", "info");

				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}
			driver.findElement(By.id("defaultMsg")).clear();
			driver.findElement(By.id("defaultMsg")).sendKeys(msg);

			driver.findElement(By.id("quickPostSendNowOptionRadio")).click();

			String response = null;

			log.logging("Passing the file: " + fileName, "info");
			fileName = System.getProperty("user.dir") + "/BulkUploadFiles/" + fileName;
			driver.findElement(By.id("xlsFile")).sendKeys(fileName);
			Thread.sleep(5000);
			log.logging("Clicking on Upload Button", "info");
			boolean hisTabPresent = su.elemCheck("History");
			if (hisTabPresent == true) {
				driver.findElement(By.xpath("//input[@value='Upload' and @name='button']")).click();
			} else {
				driver.findElement(By.xpath("//input[@value='Upload And Post' and @name='button']")).click();
			}

			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking HistoryTab Present or not", "info");
			String causeId = response.replaceAll("[^0-9]", "").trim();

			if (hisTabPresent == true) {

				log.logging("We have history tab so validation is according to History tab", "info");

				
				 * //response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 
				log.logging("We got response on Upload :" + response, "info");

				// String causeId = response.replaceAll("[^0-9]", "").trim();
				log.logging("We got causeId in response  :" + causeId, "info");
				log.logging("Matching the Response", "info");

				sa.assertEquals(response, "SUCCESS | File uploaded successfully | Transaction Id: " + causeId);
				log.logging("Clicking on history tab and Verifying The causeId we posted is there or not.", "info");

				driver.findElement(By.linkText("History")).click();

				String trans = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[1]")).getText();
				sa.assertEquals(trans.trim(), causeId);
				log.logging("Yay!! We found our Transaction", "info");
				log.logging("Now Checking the Status as UPLOADED", "info");
				String status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				sa.assertEquals(status, "UPLOADED");

				log.logging("Now Checking Preview", "info");

				driver.findElement(By.xpath("(//img[@alt='Preview'])[1]")).click();
				Thread.sleep(10000);
				log.logging("Now Checking Some Phone,Message,Preview in Preview PopUp", "info");
				String preview = driver.findElement(By.xpath("//div[text()='Preview']")).getText();
				String pHONE = driver.findElement(By.xpath("//th[text()='PHONE']")).getText();
				String mESSAGE = driver.findElement(By.xpath("//th[text()='MESSAGE']")).getText();

				sa.assertEquals(preview.trim(), "Preview");
				sa.assertEquals(pHONE.trim(), "PHONE");
				sa.assertEquals(mESSAGE.trim(), "MESSAGE");
				log.logging("Now Closing the Preview POP UP!!", "info");

				driver.findElement(By.xpath("(//a[@title='Close'])[1]")).click();
				log.logging("Now Actually Posting the Campaign!", "info");

				driver.findElement(By.xpath("(//img[@class='action-icon'])[2]")).click();
				Alert alert = driver.switchTo().alert();
				alert.accept();
				response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
						.getText();
				sa.assertEquals(response, "Your file is being processed. Transaction id " + causeId
						+ ". Please refer upload history below for final status.");
				log.logging("Now Checking the Status as SENT", "info");
				Thread.sleep(2000);

				status = driver.findElement(By.xpath("(//tr[@class='$ROW_BACKGROUND$']//td)[3]")).getText();
				su.refreshPage();
				sa.assertEquals(status, "SENT");

				driver.findElement(By.linkText("History")).click();
				log.logging("Now Clicking the Sent Tab", "info");

				driver.findElement(By.id("tabName_sent")).click();
				Thread.sleep(3000);
				log.logging("Now Checking our causeId is present or not", "info");
				String causeIdValidation = driver.findElement(By.linkText(causeId)).getText();

				sa.assertEquals(causeIdValidation, causeId);
				log.logging("Now Checking Campign is successfull or not", "info");

				String forTheTransaction = driver
						.findElement(By.xpath("//div[@id='uploadHistoryContainer']/table[1]/tbody[1]/tr[2]/td[1]"))
						.getText();

				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				sa.assertEquals(successChk, true);
				driver.findElement(By.linkText("Bulk")).click();
				Thread.sleep(2000);

			} else {
				log.logging("History Tab Not Present", "info");
				
				 * Thread.sleep(5000); response = driver.findElement(By.
				 * xpath("//div[@classname='notification notificationGreen']//div[1]"))
				 * .getText();
				 

				log.logging("Got Response after Posting : " + response, "info");
				// String causeId = response.replaceAll("[^0-9]", "").trim();

				log.logging("Taking causeId from Response and we got  : " + causeId, "info");

				String actualCauseId = driver.findElement(By.xpath("(//tr[@class='alternateBG']//td//a)[1]")).getText();
				sa.assertEquals(actualCauseId, causeId);
				log.logging("Yay! we got the campign for causeId  : " + causeId, "info");
				Thread.sleep(5000);
				su.refreshPage();
				String forTheTransaction = driver.findElement(By.xpath("(//tr[@class='alternateBG'][2])")).getText();
				System.out.println(forTheTransaction);
				boolean successChk = (forTheTransaction.contains("successfully")
						&& forTheTransaction.contains(causeId));
				log.logging(successChk + "amruta successchek", "info");
				sa.assertEquals(successChk, true);
			}
			Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
			log.logging(metadata.toString(), "debug");
			boolean postMsgType = metadata.toString().contains("pmt=2");
			log.logging(String.valueOf(postMsgType), "debug");
			log.logging("Matching Post Message Type Status is 2", "info");
			sa.assertEquals(postMsgType, true, "Post Message Type Not Matched");
			Object webarooNo = query.getDBResponse(causeId, "webarooNumber",
					"gettingMsgLogGroupPostForTransactionTuples");
			String[] wNo = webarooNo.toString().split(",");
			log.logging("Checking Webaroo No as : " + wbNo, "info");
			log.logging("Got Webaroo No " + wNo[1].trim(), "info");

			sa.assertEquals(wNo[1].trim(), wbNo);
		}
		sa.assertAll();
	}

}
*/