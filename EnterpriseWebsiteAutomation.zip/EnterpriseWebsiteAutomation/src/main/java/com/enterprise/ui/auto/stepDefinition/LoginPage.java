package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginPage {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	String username;
	String password;
	ReportingLogging log;
	WebDriverWait wait;

	public LoginPage() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		wait = new WebDriverWait(driver, 10);
	}

	@Given("^User is on Login page$")
	public void user_is_on_Login_page(){
		log.logging("Verifying Login Page Title", "info");
//		Assert.assertEquals(driver.getTitle(), "Gupshup - Enable Engaging Conversations Seamlessly Across 30+ Channels Using a Single API");
		Assert.assertEquals(driver.getTitle(), "Enable engaging conversations seamlessly across 30+ channels using a Single API - Gupshup.io");
//	Assert.assertEquals(driver.getTitle(), "Gupshup | Login");

	}
	
	@Then("^User click on login link$")
	public void user_click_on_login_link() throws InterruptedException {
		
        Thread.sleep(5000);
		driver.findElement(By.linkText("Login")).click();

	}
	

	@Then("^User put username and password$")
	public void user_put_username_and_password() throws InterruptedException {
	
		username = env.getEnterpriseUsername();
		password = env.getEnterprisePassword();		log.logging("Passing Username and Password", "info");
		
		Thread.sleep(2000);
		driver.findElement(By.id("phoneId")).sendKeys(username);
		driver.findElement(By.id("passwordId")).sendKeys(password);
		
		log.logging("Username and password entered", "info");

	}

	@Then("^User click on login button$")
	public void user_click_on_login_button() throws InterruptedException {
		log.logging("Clicking on Login Button", "info");

		driver.findElement(By.id("loginBtnId")).click();
		Thread.sleep(2000);

	}

	@Then("^User landed on login page$")
	public void user_landed_on_login_page() {
		log.logging("Veryfying Page Title of Dashboard", "info");

		//Assert.assertEquals(driver.getTitle(), "Gupshup - Dashboard");
	}

//	@Then("^verify userInfo$")
//	public void verify_userInfo() throws Throwable {
//		
//		String userName = driver.findElement(By.xpath("//div[@class='float toplink']//a[@href='/settings']")).getText();
//		String[] user = userName.split(" ");
//		username = env.getEnterpriseUsername();
//		log.logging("Veryfying Username as "+username+" .", "info");
//
//		Assert.assertEquals(user[1].trim(), username);
//	}

	@Then("^user put wrong username and Password$")
	public void user_put_wrong_username_and_Password() {
		username = env.getEnterpriseUsername();
		password = env.getEnterprisePassword();
		log.logging("Checking with wrong Username and Password", "info");

		driver.findElement(By.id("phoneId")).sendKeys("abcdef");
		driver.findElement(By.id("passwordId")).sendKeys("test");

	}

	@Then("^verify the error$")
	public void verify_the_error() throws InterruptedException {
		String error = driver.findElement(By.xpath("//div[@id='notification']//div[1]")).getText();
		log.logging("Checking error User Id or Password entered is incorrect."  , "info");

		Assert.assertEquals(error.trim(), "User Id or Password entered is incorrect.");
		su.refreshPage();
	}

	@Then("^Logout from Panel$")
	public void logout_from_Panel() throws InterruptedException {
		WebElement element = driver.findElement(By.xpath("//a[@title='Logout']"));
		wait.until(ExpectedConditions.visibilityOf(element));
		driver.findElement(By.xpath("//a[@title='Logout']")).click();
		log.logging("Logging out"  , "info");
		//log.logging("Verifying Login Page Title", "info");

		//Thread.sleep(10000);
		
		//Assert.assertEquals(driver.getTitle(), "Gupshup - Enable Engaging Conversations Seamlessly Across 30+ Channels Using a Single API");
		/*log.logging("Verifying Login Page Title", "info");

		Thread.sleep(15000);
		
		Assert.assertEquals(driver.getTitle(), "Gupshup - Enable Engaging Conversations Seamlessly Across 30+ Channels Using a Single API");*/
		//driver.close();
	}
}
