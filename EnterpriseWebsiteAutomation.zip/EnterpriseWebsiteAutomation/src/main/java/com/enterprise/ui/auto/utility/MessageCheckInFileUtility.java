package com.enterprise.ui.auto.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;




public class MessageCheckInFileUtility extends GeneralUtlities {
	ExcelReaderUtilityxls xls;
	ExcelReaderUtility xlsx;

	public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
		File destFile = new File(destinationDir, zipEntry.getName());

		String destDirPath = destinationDir.getCanonicalPath();
		String destFilePath = destFile.getCanonicalPath();

		if (!destFilePath.startsWith(destDirPath + File.separator)) {
			throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
		}

		return destFile;
	}

	public static void  unzip(String compressedfile, String outpath) throws IOException {
		String fileZip = compressedfile;
		File destDir = new File(outpath);
		byte[] buffer = new byte[1024];
		ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
		ZipEntry zipEntry = zis.getNextEntry();
		while (zipEntry != null) {
			File newFile = newFile(destDir, zipEntry);
			FileOutputStream fos = new FileOutputStream(newFile);
			int len;
			while ((len = zis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}
			fos.close();
			zipEntry = zis.getNextEntry();
		}
		zis.closeEntry();
		zis.close();
	}

	public boolean checkFileHasMessageOrNot(String filepath, String outpath) throws IOException {
//false means file have message in it
		boolean result = false;
		if ((filepath.contains(".7z")) || (filepath.contains(".zip"))) {
			cleanDir(outpath);
			unzip(filepath, outpath);
			File folder = new File(outpath);
			File[] listOfFiles = folder.listFiles();
			System.out.println(listOfFiles[0].toString());
			BufferedReader reader = new BufferedReader(new FileReader(listOfFiles[0]));
			String line = Files.readAllLines(Paths.get(listOfFiles[0].toString())).get(0);
			if (line.contains("Message") || line.matches("[A-Za-z0-9]+")) {
				result = true;
			} else
				result = false;
		}else  if ((filepath.contains(".xls")) || (filepath.contains(".xlsx"))) {
			System.out.println("Ignoring for now");
		}
		else {
			BufferedReader reader = new BufferedReader(new FileReader(filepath));

			String line = Files.readAllLines(Paths.get(filepath)).get(0);
			if (line.contains("Message") || line.matches("[A-Za-z0-9]+")) {
				result = true;
			} else
				result = false;
		}
			return result;
		}
	public String checkFileError(String filepath, String outpath) throws IOException {
		//Get Response like "The messageId "" is invalid. Please provide a valid positive alpha numeric value less than 200 digits."|"138"

		String result = null;
		String error = null;
		String errorId = null;
		if ((filepath.contains(".7z")) || (filepath.contains(".zip"))) {
			// cleanDir(outpath);
			unzip(filepath, outpath);
			File folder = new File(outpath);
			File[] listOfFiles = folder.listFiles();
			// System.out.println(listOfFiles[0].toString());
			BufferedReader reader = new BufferedReader(new FileReader(listOfFiles[0]));
			String line = null;
			if (listOfFiles[0].toString().contains("csv")) {
				line = Files.readAllLines(Paths.get(listOfFiles[0].toString())).get(1);
				String allData[] = line.split(",");
				result = allData[2] + "|" + allData[1];
			} else if (listOfFiles[0].toString().contains("txt")) {
				String allData[] = line.split("	");
				result = allData[2] + "|" + allData[1];
			} else if ((listOfFiles[0].toString().contains("xls"))) {
				xls = new ExcelReaderUtilityxls(listOfFiles[0].toString());
				error = xls.getTestDataForElement("failure", "response sheet", 2);
				errorId = xls.getTestDataForElement("failure", "response sheet", 1);
				result = error + "|" + errorId;
			} else if ((listOfFiles[0].toString().contains("xlsx"))) {
				xlsx = new ExcelReaderUtility(listOfFiles[0].toString());
				error = xlsx.getTestDataForElement("failure", "response sheet", 2);
				errorId = xlsx.getTestDataForElement("failure", "response sheet", 1);
				result = error + "|" + errorId;
			}
		} else {
			BufferedReader reader = new BufferedReader(new FileReader(filepath));

			String line = Files.readAllLines(Paths.get(filepath)).get(1);
			if (filepath.contains("csv")) {
				String allData[] = line.split(",");
				result = allData[2]+ "|" + allData[1];;
			} else if (filepath.contains("txt")) {
				String allData[] = line.split("	");
				result = allData[2]+ "|" + allData[1];;
			} else if ((filepath.contains(".xls")) || (filepath.contains(".xlsx"))) {
				xls = new ExcelReaderUtilityxls(filepath);
				error = xls.getTestDataForElement("failure", "response sheet", 2);
				errorId = xls.getTestDataForElement("failure", "response sheet", 1);
				result = error + "|" + errorId;
			} else if ((filepath.contains(".xlsx"))) {
				xlsx = new ExcelReaderUtility(filepath);
				error = xlsx.getTestDataForElement("failure", "response sheet", 2);
				errorId = xlsx.getTestDataForElement("failure", "response sheet", 1);
				result = error + "|" + errorId;
			}
		}
		return result;
	}
	public String getMessageFromFile(String filepath, String outpath) throws IOException {
		//Get Response like "The messageId "" is invalid. Please provide a valid positive alpha numeric value less than 200 digits."|"138"

		String result = null;
		String message = null;
		String errorId = null;
		if ((filepath.contains(".7z")) || (filepath.contains(".zip"))) {
			// cleanDir(outpath);
			unzip(filepath, outpath);
			File folder = new File(outpath);
			File[] listOfFiles = folder.listFiles();
			// System.out.println(listOfFiles[0].toString());
			BufferedReader reader = new BufferedReader(new FileReader(listOfFiles[0]));
			String line = null;
			if (listOfFiles[0].toString().contains("csv")) {
				line = Files.readAllLines(Paths.get(listOfFiles[0].toString())).get(1);
				String allData[] = line.split(",");
				result =  allData[1];
			} else if (listOfFiles[0].toString().contains("txt")) {
				String allData[] = line.split("	");
				result = allData[1];
			} else if ((listOfFiles[0].toString().contains("xls"))) {
				xls = new ExcelReaderUtilityxls(listOfFiles[0].toString());
				message = xls.getCellDataWithHeaderwithSheetIndex(0, "Message", 2);
				result = message + "|" + errorId;
			} else if ((listOfFiles[0].toString().contains("xlsx"))) {
				xlsx = new ExcelReaderUtility(listOfFiles[0].toString());
				message = xlsx.getCellDataWithHeaderwithSheetIndex(0, "Message", 2);
				result = message;
			}
		} else {
			BufferedReader reader = new BufferedReader(new FileReader(filepath));
			System.out.println(filepath);
			if (filepath.contains("csv")) {
				String line = Files.readAllLines(Paths.get(filepath)).get(1);
				String allData[] = line.split(",");
				result =  allData[1];
			} else if (filepath.contains("txt")) {
				String line = Files.readAllLines(Paths.get(filepath)).get(1);

				String allData[] = line.split("	");
				result = allData[1];
			} else if ((filepath.contains(".xls")) || (filepath.contains(".xlsx"))) {
				xls = new ExcelReaderUtilityxls(filepath);
				message = xls.getCellDataWithHeaderwithSheetIndex(0, "Message", 1);
				result = message ;
			} else if ((filepath.contains(".xlsx"))) {
				xlsx = new ExcelReaderUtility(filepath);
				message = xlsx.getCellDataWithHeaderwithSheetIndex(0, "Message", 2);
				result = message ;
			}
		}
		return result;
	}		
/*	public static void main(String[] args) throws IOException {
		MessageCheckInFileUtility mu = new MessageCheckInFileUtility();
System.out.println(mu.checkFileHasMessageOrNot(System.getProperty("user.dir") + "/BulkUploadFiles/csv_all_headersms.7z", System.getProperty("user.dir") + "/zip-file"));
	}*/
}
