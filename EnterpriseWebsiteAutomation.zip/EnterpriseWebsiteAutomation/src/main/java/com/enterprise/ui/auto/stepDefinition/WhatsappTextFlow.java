package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Then;

public class WhatsappTextFlow {
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	
	
	static String repoPath = "resources/Locators/Whatsup.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	
	public WhatsappTextFlow() throws IOException {
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
	}
	
@Then("^User clicks on Bulk Tab and verify$")
public void BulkTabClick() {

	log.logging("Verifying Bulk Tab of WhatsApp Tab Simple", "info");
	
	driver.findElement(By.xpath("//a[text()='Bulk']")).click();
//	By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsAppp-Bulk", locator);
//	driver.findElement(b1).click();

	Assert.assertEquals(driver.getTitle(), "Gupshup - Message Upload");	
}
	
@Then("^Verify that the Text option is clicked$")
public void BulkTextOption() {
	driver.findElement(By.id("testTabHeaderSpan")).click();
	driver.findElement(By.id("testTabHeaderSpan")).isSelected();
	log.logging("Bulk Text option is selected", "info");
}

@Then("^User selects NA template$")
public void NATemplateSelect() {
	driver.findElement(By.xpath("//div[@title='Insert Template']")).click();
	driver.findElement(By.xpath("//div[@id='messageTemplate_6081232']")).click();
	driver.findElement(By.xpath("//input[@value='OK']")).click();
}

@Then("^User upload file which have only phone no$")
public void FileUploadPhoneNo() {

}

@Then("^User upload file which have phone no and Message for NA template$")
public void FileUPloadPhoneMessage() {
	
}

@Then("^User upload file which have phone no, MessageType and Message for NA template$")
public void PhoneMessageTypeNATemp(){
	
}

@Then("^User selects Static template$")
public void StaticTemplateSelect(){
	
}

@Then("^User upload file which have phone no and Message for static template$")
public void PhoneMessageStaticTemp(){
	
}

@Then("^User upload file which have phone no, MessageType and Message for static template$")
public void PhoneMessageTypeStaticTemp(){
	
}

@Then("^User selects Dynamic template$")
public void DynamicTemplateSelect(){
	
}

@Then("^User upload file which have phone no and Message for dynamic template$")
public void PhoneMessageDynamicTemp(){
	
}

@Then("^User upload file which have phone no, MessageType and Message for dynamic template$")
public void PhoneMessageTypeDynamicTemp(){
	
}

@Then("^User upload file which have phone no, MessageType, ButtonURL and Message for dynamic template$")
public void PhoneMessageTypeBtnUrlDynamicTemp(){
	
}

@Then("^User verifies the transaction ID and success message$")
public void SuccessVerify() {
	
}

}