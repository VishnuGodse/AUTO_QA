/**
 * 
 */
package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.EncryptionDecryption;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.GetEncryptDecrypt;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

/**
 * @author Rahul Jain
 *
 */
public class SimpleMessageFlow {
	String balance;

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	SoftAssert sa;
	String prePaidUser = null;
	String prePaidPass = null;
	String fetchlogScript = null;
	String machineIp = null;
	GetEncryptDecrypt encrypt;
	String encryptNo = null;

	public SimpleMessageFlow() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		prePaidUser = env.getEnterprisePrePaidAccUserId();
		prePaidPass = env.getEnterprisePrePaidAccPass();
		fetchlogScript = System.getProperty("user.dir") + "/resources/captureCauseIdwithLogs.sh";
		machineIp = System.getProperty("user.dir") + env.getMachineConfigPath();

	}

	@Then("^Simple Messaging Flow Test Started$")
	public void simple_Messaging_Flow_Test_Started() {
		log.logging("Started the Simple Messaging Flow ", "info");
	}

	@Then("^Simple Messaging Flow Test Ended$")
	public void simple_Messaging_Flow_Test_Ended() {
		log.logging("Ended the Simple Messaging Flow ", "info");

	}

	@Then("^Disable whatsapp tab for prepaidUser$")
	public void disable_whatsapp_tab_for_prepaidUser() throws IOException, InterruptedException {
		log.logging("Disabling the WhatsApp tab", "info");
		Object userId = query.getDBResponse(prePaidUser, "id", "getiingUserId");
		boolean result = query.setDBResponse("disableWhatsAppTab", userId.toString());
	}

	@Then("^Enable the Unicode Flash Tab$")
	public void enable_the_Unicode_Flash_Tab() throws IOException, InterruptedException {
		log.logging("Got User Id " + prePaidUser, "info");
		Object userId = query.getDBResponse(prePaidUser, "id", "getiingUserId");
		query.setDBResponse("enableUnicodeFlash", userId.toString());
	}

	@Then("^Check the initial account Balance$")
	public void check_the_initial_account_Balance() throws InterruptedException {
		/*
		 * driver.findElement(By.xpath("//span[text()='Dashboard']")).click();
		 * log.logging("Going to Dashboard for Getting Balance", "info");
		 * Thread.sleep(2000);
		 */
		log.logging("Fetching Balance from Dashboard Page", "info");

		String balancetmp = driver
				.findElement(By.xpath("//div[@id='accDetails']/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[3]/strong[1]"))
				.getText();
		// String balancetmp =
		// driver.findElement(By.xpath("(//span[@class='strong'])[1]")).getText();
		balance = balancetmp.replaceAll("[^0-9]", "").trim();
		log.logging("Initial Balance is : " + balance, "info");
		log.logging("Clicking on SMSTab", "info");

		driver.findElement(By.xpath("//span[text()='SMS']")).click();
		log.logging("Clicking on Simple Tab", "info");

		driver.findElement(By.linkText("Simple")).click();
	}

	@Then("^Choose MsgType message phoneNo and post the message and check balance$")
	public void choose_MsgType_message_phoneNo_and_post_the_essage_and_check_balance(DataTable msgtypemsg)
			throws Throwable {

		for (Map<String, String> mappingMsg : msgtypemsg.asMaps(String.class, String.class)) {
			int phoneNocnt;
			String response = null;
			String responseExp = null;
			String msg = null;
			String dlt = null;
			String mask = null;
			WebElement useMaskGPS = driver.findElement(By.id("maskList"));

			if (mappingMsg.get("MessageType").equalsIgnoreCase("Text")) {

				driver.findElement(By.id("postTypeHeaderEnglishSmsSpan")).click();
			}
			if (mappingMsg.get("MessageType").equalsIgnoreCase("Unicode_Text")) {

				Thread.sleep(5000);
				driver.findElement(By.id("postTypeHeaderOtherLangSpan")).click();
			}
			if (mappingMsg.get("MessageType").equalsIgnoreCase("Flash")) {
				driver.findElement(By.id("postTypeHeaderFlashSmsSpan")).click();
			}
			if (mappingMsg.get("MessageType").equalsIgnoreCase("Unicode_Flash")) {
				driver.findElement(By.id("postTypeHeaderUnicodeFlashSmsSpan")).click();
			}
			Thread.sleep(5000);
			if (mappingMsg.get("EncryptionFlag") != null && mappingMsg.get("EncryptionFlag").equalsIgnoreCase("true")) {
				String[] phoneArr = phoneNo.split(",");
				phoneNo = phoneArr[0];
				log.logging("Passing the Phone No : " + phoneNo, "info");
				driver.findElement(By.xpath("(//textarea[@id='quickPostNumberBox'])[1]")).sendKeys(phoneNo);
				encryptNo = encrypt.getEncryptText(phoneNo);
			} else {
				log.logging("Passing the Phone No : " + phoneNo, "info");
				driver.findElement(By.xpath("(//textarea[@id='quickPostNumberBox'])[1]")).sendKeys(phoneNo);
			}
			if (mappingMsg.get("Message") != null) {
				msg = mappingMsg.get("Message");
				log.logging("Cleaning the Message Box", "info");
				driver.findElement(By.xpath("(//textarea[@id='quickPostTextArea'])[1]")).clear();
				log.logging("Passing the Message : " + msg, "info");
				driver.findElement(By.xpath("(//textarea[@id='quickPostTextArea'])[1]")).sendKeys(msg);
			} else {
				driver.findElement(By.xpath("(//div[@class='actionLink floatRight'])[2]")).click();
				if (mappingMsg.get("MessageType").equalsIgnoreCase("Text")) {
					msg = driver.findElement(By.cssSelector("div#dltTmplDiv_gupshup_english_1>div>div:nth-of-type(2)"))
							.getText();
					String dbFetchMsg = msg.replaceAll("123", "@__123__@");
					log.logging(dbFetchMsg, "info");
					Object userIdobj = query.getDBResponse(prePaidUser, "id", "getiingUserId");
					String userId = userIdobj.toString();
					Object dltId = query.getDBResponse(dbFetchMsg, userId, "dltTemplateId", "getDLTIdFromTemplate");
					dlt = dltId.toString();
					log.logging("DLT id for the message Selected in DB is : " + dlt, "info");

					driver.findElement(By.cssSelector("div#dltTmplDiv_gupshup_english_1>div>div:nth-of-type(2)>span"))
							.click();
					Thread.sleep(2000);
					driver.findElement(By.cssSelector("div#editDltTemplatesDiv>div>div:nth-of-type(2)>input")).click();
				} else if (mappingMsg.get("MessageType").equalsIgnoreCase("Unicode_Text")) {
					msg = driver
							.findElement(By.cssSelector("div#dltTmplDiv_gupshup_unicode_1>div>div:nth-of-type(2)>span"))
							.getText();

					String dbFetchMsg = msg.replaceAll("123", "@__123__@");
					log.logging(dbFetchMsg, "info");
					Object userIdobj = query.getDBResponse(prePaidUser, "id", "getiingUserId");
					String userId = userIdobj.toString();
					Object dltId = query.getDBResponse(dbFetchMsg, userId, "dltTemplateId", "getDLTIdFromTemplate");
					dlt = dltId.toString();
					log.logging("DLT id for the message Selected in DB is : " + dlt, "info");

					driver.findElement(By.cssSelector("div#dltTmplDiv_gupshup_unicode_1>div>div:nth-of-type(2)>span"))
							.click();
					Thread.sleep(2000);
					driver.findElement(By.cssSelector("div#editDltTemplatesDiv>div>div:nth-of-type(2)>input")).click();
				}

			}
			if (mappingMsg.get("Mask") != null) {
				new Select(useMaskGPS).selectByValue(mappingMsg.get("Mask"));
				mask = mappingMsg.get("Mask");
				log.logging("Select Mask as : " + mask, "info");
			}

			// response = driver.findElement(By.id("notification")).getText();
			driver.findElement(By.xpath("(//input[@class='facebookStyleButton'])[1]")).click();
			log.logging("Submitting the Message ", "info");
			Thread.sleep(3000);

			response = driver.findElement(By.xpath("//div[@classname='notification notificationGreen']//div[1]"))
					.getText();

			log.logging("Checking response after submitting ", "info");
			if (phoneNo.contains(",")) {
				String[] phoneArr = phoneNo.split(",");
				phoneNocnt = phoneArr.length;
				// responseExp driver.findElement(By.xpath("//div[@classname='notification
				// notificationGreen']//div[1]")).getText();
				responseExp = "Your messages will be sent shortly subject to Current Status of your account.Messages sent to "
						+ phoneNocnt + " phone numbers.";
			} else {
				phoneNocnt = 1;
				responseExp = "Your messages will be sent shortly subject to Current Status of your account.";

			}
			sa.assertEquals(response, responseExp);
			if (mappingMsg.get("DLTTemplateId") != null) {
				String causeId = null;
				String expdltTempId = mappingMsg.get("DLTTemplateId");
				if (expdltTempId.equalsIgnoreCase("DB")) {
					expdltTempId = dlt;
				}
				if (mappingMsg.get("EncryptionFlag") != null
						&& mappingMsg.get("EncryptionFlag").equalsIgnoreCase("true")) {
					if (mappingMsg.get("MessageType").equalsIgnoreCase("Text")) {
						causeId = gu.getCauseIdFromLogs(fetchlogScript, msg, prePaidUser, machineIp, "Text",encryptNo);
					} else {
						causeId = gu.getCauseIdFromLogs(fetchlogScript, msg, prePaidUser, machineIp, "Unicode_Text",encryptNo);
					}
				} else {
					if (mappingMsg.get("MessageType").equalsIgnoreCase("Text")) {
						causeId = gu.getCauseIdFromLogs(fetchlogScript, msg, prePaidUser, machineIp, "Text","success");
					} else {
						causeId = gu.getCauseIdFromLogs(fetchlogScript, msg, prePaidUser, machineIp, "Unicode_Text","success");
					}
				}
				log.logging("Got CauseId from Logs : " + causeId, "info");
				Object metadata = query.getDBResponse(causeId, "metadata", "gettingMsgLog");
				if (mappingMsg.get("Mask") != null) {
					Object masklog = query.getDBResponse(causeId, "mask", "gettingMsgLog");
					log.logging("Verifying Mask from MsgLog from what we sent from UI : " + mask, "info");
					log.logging("Mask from MsgLog we get in MsgLog DB : " + masklog.toString(), "info");
					sa.assertEquals(masklog.toString(), mask);
				}
				if (mappingMsg.get("EncryptionFlag") != null
						&& mappingMsg.get("EncryptionFlag").equalsIgnoreCase("true")) {
					log.logging("Encryption phone No checking at MsgLog", "info");
					Object sender = query.getDBResponse(causeId, "sender", "gettingMsgLog");
					log.logging("Got from MsgLog : " + sender.toString() + "Expected : " + encryptNo, "info");
					Assert.assertEquals(sender.toString(), encryptNo);

				}
				log.logging("Checking dltTempId Recieved should Match : " + expdltTempId, "info");
				sa.assertEquals(String.valueOf(metadata).contains("dltid=" + expdltTempId), true);
				log.logging("Getting Peid From  EntuserAttribute ", "info");
				Object userId = query.getDBResponse(prePaidUser, "id", "getiingUserId");
				Object peid = query.getDBResponse(userId.toString(), "value", "getPeidFromAttribute");
				log.logging("Peid is  from EntuserAttribute : " + peid.toString(), "info");
				sa.assertEquals(String.valueOf(metadata).contains("peid=" + peid), true);
				log.logging("DLTTemplateId and Peid is Verified from MsgLog MetaData :  " + metadata.toString(),
						"info");
				log.logging("Peid is  from EntuserAttribute : " + peid.toString(), "info");

			}

			// su.refreshPage();
			driver.findElement(By.xpath("//span[text()='Dashboard']")).click();
			log.logging("Going to Dashboard for Getting Balance", "info");
			Thread.sleep(5000);
			String balancetmp = driver
					.findElement(
							By.xpath("//div[@id='accDetails']/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[3]/strong[1]"))
					.getText();
			Thread.sleep(2000);
			/*
			 * String balancetmp =
			 * driver.findElement(By.xpath("(//span[@class='strong'])[1]")).getText();
			 */
			String newbalance = balancetmp.replaceAll("[^0-9]", "").trim();
			log.logging("Checking new  balance : " + newbalance + " and old balance : " + balance, "info");
			int newbalanceint = Integer.parseInt(newbalance);
			newbalanceint = (Integer.parseInt(balance) - newbalanceint);
			log.logging("New Balance : " +newbalanceint ,"info");
			sa.assertEquals(newbalanceint, phoneNocnt);
			balance = newbalance;
			driver.findElement(By.xpath("//span[text()='SMS']")).click();
			Thread.sleep(2000);

			log.logging("Clicking on Simple Tab", "info");
			sa.assertAll();
		}

	}

	@Then("^User put Prepaid username and password$")
	public void user_put_Prepaid_username_and_password() throws InterruptedException {
		log.logging("Putting Prepaid UserName and Password : " + prePaidUser, "info");
		driver.findElement(By.id("phoneId")).clear();
		Thread.sleep(2000);
		driver.findElement(By.id("phoneId")).sendKeys(prePaidUser);
		driver.findElement(By.id("passwordId")).clear();
		Thread.sleep(2000);
		driver.findElement(By.id("passwordId")).sendKeys(prePaidPass);
	}

	@Then("^Check popup and Click Ok on Balance Popup$")
	public void check_popup_and_Click_Ok_on_Balance_Popup() {
		boolean popUpCheck = driver.findElement(By.xpath("(//div[@class='popupHeader'])[5]")).isDisplayed();
		log.logging(String.valueOf(popUpCheck) + "PopUp Found", "info");

		if (popUpCheck == true) {
			String accountExp = driver.findElement(By.xpath("//div[text()='Account Expiry Notification']")).getText();
			Assert.assertEquals(accountExp, "Account Expiry Notification");
			driver.findElement(By.xpath("//div[@id='expiryId']//input[1]")).click();
		} else
			log.logging("No PopUp is Shown", "info");

	}

}
