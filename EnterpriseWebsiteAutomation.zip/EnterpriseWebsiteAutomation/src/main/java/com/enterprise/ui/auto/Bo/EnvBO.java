package com.enterprise.ui.auto.Bo;

import java.io.IOException;

import com.enterprise.ui.auto.utility.ExcelReaderUtility;
import com.enterprise.ui.auto.utility.PropRead;

public class EnvBO {
	PropRead pr = new PropRead();
	public String env;

	public String enterpriseUrl;
	public String enterpriseUsername;
	public String enterprisePassword;
	public String enterpriseAccountId;
	public String enterpriseAccIdPass;
	public String v3Url;
	public String v3ApiKey;
	public String v3BotKey;
	public String v3Optin;
	public String v3Optout;
	public String enterprisePrePaidAccUserId;
	public String enterprisePrePaidAccPass;
	public String enterpriseWhatsAppAccUserId;
	public String enterpriseWhatsAppAccPass;
	public String machineConfigPath;
	public String otpPhoneNo;
	public String otpEmailId;


	public String getOtpPhoneNo() {
		return otpPhoneNo;
	}

	public String getOtpEmailId() {
		return otpEmailId;
	}

	public String getEnterpriseWhatsAppAccUserId() {
		return enterpriseWhatsAppAccUserId;
	}

	public String getEnterpriseWhatsAppAccPass() {
		return enterpriseWhatsAppAccPass;
	}

	public String getEnterprisePrePaidAccUserId() {
		return enterprisePrePaidAccUserId;
	}

	public String getEnterprisePrePaidAccPass() {
		return enterprisePrePaidAccPass;
	}

	public String getEnv() {
		return env;
	}

	public String getEnterpriseUrl() {
		return enterpriseUrl;
	}

	public String getEnterpriseUsername() {
		return enterpriseUsername;
	}

	public String getEnterprisePassword() {
		return enterprisePassword;
	}

	public String getEnterpriseAccountId() {
		return enterpriseAccountId;
	}

	public String getEnterprisePass() {
		return enterprisePassword;
	}

	public String getV3Url() {
		return v3Url;
	}

	public String getV3ApiKey() {
		return v3ApiKey;
	}

	public String getV3BotKey() {
		return v3BotKey;
	}

	public String getV3Optin() {
		return v3Optin;
	}

	public String getV3Optout() {
		return v3Optout;
	}
	public String getMachineConfigPath() {
		return machineConfigPath;
	}

	public EnvBO() throws IOException {
		env = System.getProperty("env");
		String env_path_config = "resources/project_env.properties";
		String testDataSheet = pr.readConfig("TestDataExcel", "resources/config.properties");

		ExcelReaderUtility er = new ExcelReaderUtility(testDataSheet);

		enterpriseUrl = (pr.readConfig(env + "_Enterprise-Url", env_path_config));
		enterpriseUsername = (pr.readConfig(env + "_Enterprise-username", env_path_config));
		enterprisePassword = (pr.readConfig(env + "_Enterprise-Password", env_path_config));
		enterpriseAccountId = (pr.readConfig(env + "_Enterprise-username", env_path_config));
		v3Url = (pr.readConfig(env + "_V3_Api_URL", env_path_config));
		v3ApiKey = (pr.readConfig(env + "_API_Key", env_path_config));
		v3BotKey = (pr.readConfig(env + "_Bot_Key", env_path_config));
		v3Optin = (pr.readConfig(env + "_V3_OptIn_No", env_path_config));
		v3Optout = (pr.readConfig(env + "_V3_OptOut_No", env_path_config));
		enterprisePrePaidAccUserId=(pr.readConfig(env + "_Enterprise_Prepaid_Acc", env_path_config));
		enterprisePrePaidAccPass=(pr.readConfig(env + "_Enterprise_Prepaid_Pass", env_path_config));
		enterpriseWhatsAppAccUserId=(pr.readConfig(env + "_Enterprise_WhatsApp_Acc", env_path_config));
		enterpriseWhatsAppAccPass=(pr.readConfig(env + "_Enterprise_WhatsApp_Pass", env_path_config));
		machineConfigPath=(pr.readConfig(env + "_GAPI_CONFIGFile", env_path_config));
		otpPhoneNo=(pr.readConfig(env + "_OTP_Number", env_path_config));
		otpEmailId=(pr.readConfig(env + "_OTP_EmailId", env_path_config));


	}

	

}
