/**
 * 
 */
package com.enterprise.ui.auto.Bo;

import java.io.IOException;

import com.enterprise.ui.auto.utility.PropRead;

/**
 * @author Rahul Jain
 *
 */
public class ConfigServerBO {
	public String host;
	public String port;
	public String pass;
	public String username;

	public String env;

	public ConfigServerBO() throws IOException {
		PropRead pr = new PropRead();
		env = System.getProperty("env");
		String configServer_path_config = "resources/configserver.properties";
		host = (pr.readConfig(env + "_ConfigServer_Host", configServer_path_config));
		port = (pr.readConfig(env + "_ConfigServer_Port", configServer_path_config));
		username = (pr.readConfig(env + "_ConfigServer_UserName", configServer_path_config));
		pass = (pr.readConfig(env + "_ConfigServer_Password", configServer_path_config));
		
	}

	public String getHost() {
		return host;
	}

	public String getPort() {
		return port;
	}

	public String getPass() {
		return pass;
	}

	public String getUsername() {
		return username;
	}

	public String getEnv() {
		return env;
	}

	
}
