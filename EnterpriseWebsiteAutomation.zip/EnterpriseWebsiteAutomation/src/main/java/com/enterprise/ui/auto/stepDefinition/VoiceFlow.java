package com.enterprise.ui.auto.stepDefinition;

import java.io.File;
import java.io.IOException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.TemporaryFilesystem;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.FileDownloader;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class VoiceFlow {
	

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	String userid;
	int i;

	public VoiceFlow() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		userid = env.getEnterpriseUsername();
	}
	
	@Then("^Check Dail Numbers and Call numbers tab if present$")
	public void check_Dail_Numbers_and_Call_numbers_tab_if_present() throws InterruptedException {
		
		Boolean tab1 = driver.findElement(By.xpath("//*[@id=\"anch1\"]")).isDisplayed();
		Boolean tab2 = driver.findElement(By.xpath("//*[@id=\"anch2\"]")).isDisplayed();
		Boolean tab3 = driver.findElement(By.xpath("//*[@id=\"wrapper\"]/div[1]/div[2]/div/a[1]")).isDisplayed();
		
		Assert.assertEquals(tab1, true);
		Assert.assertEquals(tab2, true);
		Assert.assertEquals(tab3, true);
		
	}
	
	@Then("^Check text box to enter comma serprated 100 numbers$")
	public void check_text_box_to_enter_comma_serprated_100_numbers() throws InterruptedException {
		
		Boolean tab1 = driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).isDisplayed();
		Assert.assertEquals(tab1, true);
		
		for(i=0;i<=99;i++) {
			Random random = new Random();
			int x = random.nextInt(9000000) + 10000000;
			Integer y = new Integer(x);
			String phoneNo = "98" + y.toString();	
			
			driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys(phoneNo+",");

		}
		Thread.sleep(2000);
		
	}
	
	@Then("^Check text box to enter only numbers and not characters$")
	public void check_text_box_to_enter_only_numbers_and_not_characters(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		
		Boolean tab1 = driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).isDisplayed();
		Assert.assertEquals(tab1, true);
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("InvalidInput");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	@Then("^Check error message when the user enters multiple numbers with separator other than comma$")
	public void check_error_message_when_the_user_enters_multiple_numbers_with_separator_other_than_comma(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		
		Boolean tab1 = driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).isDisplayed();
		Assert.assertEquals(tab1, true);
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470;9875463212");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	@Then("^Check Campaign Name field if present$")
	public void check_Campaign_Name_field_if_present() throws InterruptedException {
		
		Boolean campaignName = driver.findElement(By.xpath("//*[@id=\"campaignNameUploadList\"]")).isDisplayed();
		Assert.assertEquals(true,campaignName);
		
	}
	
	
	@Then("^Check Campaign Name field is mandatory or not$")
	public void check_Campaign_Name_field_is_mandatory_or_not(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		
		Boolean tab1 = driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).isDisplayed();
		Assert.assertEquals(tab1, true);
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
//			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
//			
//			Assert.assertEquals("Interested in Call Forwarding? Missed Call Alerts? Outbound Dialling? - Click here to know more",successMessage);
			
			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();

			String[] trimmedText = successMessage.split(":");
			
			String transactionId = trimmedText[1];
			Assert.assertEquals("Campaign posted successfully. Your Transaction ID is ",trimmedText[0]);
		}
		
	}
	
	
	@Then("^Check Upload File and Give a Link and My Uploaded Files if present below the Campaign Name field or not$")
	public void Check_Upload_File_and_Give_a_Link_and_My_Uploaded_Files_if_present_below_the_Campaign_Name_field_or_not() throws InterruptedException {
		
		Boolean uploadFile = driver.findElement(By.xpath("//*[@id=\"anchs1div1\"]")).isDisplayed();
		Boolean giveaLink = driver.findElement(By.xpath("//*[@id=\"anchs2div1\"]")).isDisplayed();
		Boolean  myUploadedFiles = driver.findElement(By.xpath("//*[@id=\"anchs3div1\"]")).isDisplayed();
		
		Assert.assertEquals(true,uploadFile);
		Assert.assertEquals(true,giveaLink);
		Assert.assertEquals(true,myUploadedFiles);
		
	}
	
	
	@Then("^Check choose file upload button should be present under Upload File$")
	public void check_choose_file_upload_button_should_be_present_under_Upload_File() throws InterruptedException {
		
		Boolean chooseFileButton = driver.findElement(By.xpath("//*[@id=\"audioFile\"]")).isDisplayed();
		Assert.assertEquals(true,chooseFileButton);
		
	}
	
	
	@Then("^Check textbox under Give a Link tab and user should able to enter link address$")
	public void check_textbox_under_Give_a_Link_tab_and_user_should_able_to_enter_link_address() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"anchs2div1\"]")).click();
		
		Boolean linkTextBox = driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).isDisplayed();
		Assert.assertEquals(true,linkTextBox);
		driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).sendKeys("http://www.mydomain.com");
		
		driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
		Thread.sleep(2000);
//		String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
//		Assert.assertEquals("Interested in Call Forwarding? Missed Call Alerts? Outbound Dialling? - Click here to know more",successMessage);
		
		String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();

		String[] trimmedText = successMessage.split(":");
		
		String transactionId = trimmedText[1];
		Assert.assertEquals("Campaign posted successfully. Your Transaction ID is ",trimmedText[0]);
		
	}
	
	
	@Then("^Check  scrollbar is appearing or not when we enter multiple mobile numbers$")
	public void check_scrollbar_is_appearing_or_not_when_we_enter_multiple_mobile_numbers() throws InterruptedException {
		
		for(i=0;i<=99;i++) {
			Random random = new Random();
			int x = random.nextInt(9000000) + 10000000;
			Integer y = new Integer(x);
			String phoneNo = "98" + y.toString();	
			
			driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys(phoneNo+",");
		}
		Thread.sleep(2000);
		String JS_ELEMENT_IS_SCROLLABLE = "return arguments[0].scrollHeight > arguments[0].offsetHeight;";

			JavascriptExecutor jse = (JavascriptExecutor)driver;
			WebElement container = driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]"));
			Boolean isScrollable = (Boolean)jse.executeScript(JS_ELEMENT_IS_SCROLLABLE, container);
			
			Assert.assertEquals(true, isScrollable);
	}
	
	
	@Then("^Check Send Now and Schedule radio buttons present below the Choose file upload button$")
	public void check_Send_Now_and_Schedule_radio_buttons_present_below_the_Choose_file_upload_button() throws InterruptedException {
		
		Boolean sendNow = driver.findElement(By.xpath("//*[@id=\"quickPostSendNowOptionRadio\"]")).isDisplayed();
		Boolean schedule = driver.findElement(By.xpath("//*[@id=\"quickPostScheduleOptionRadio\"]")).isDisplayed();
		
		Assert.assertEquals(true,sendNow);
		Assert.assertEquals(true,schedule);
		
	}
	
	
	@Then("^Check Call button present below the Send Now radio button$")
	public void check_Call_button_present_below_the_Send_Now_radio_button() throws InterruptedException {
		
		Boolean callButton = driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).isDisplayed();
		
		Assert.assertEquals(true,callButton);
		
	}
	
	
	@Then("^Check Voice call should be sent to the numbers which are entered in the number field$")
	public void check_Voice_call_should_be_sent_to_the_numbers_which_are_entered_in_the_number_field(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
		
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
//			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
//			
//			Assert.assertEquals("Interested in Call Forwarding? Missed Call Alerts? Outbound Dialling? - Click here to know more",successMessage);
			
			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();

			String[] trimmedText = successMessage.split(":");
			
			String transactionId = trimmedText[1];
			Assert.assertEquals("Campaign posted successfully. Your Transaction ID is ",trimmedText[0]);
		}
		
	}
	
	
	@Then("^Check Voice call should be sent to 100 numbers which are entered in the number field$")
	public void check_Voice_call_should_be_sent_to_100_numbers_which_are_entered_in_the_number_field(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
		
			for(i=0;i<=99;i++) {
				Random random = new Random();
				int x = random.nextInt(9000000) + 10000000;
				Integer y = new Integer(x);
				String phoneNo = "98" + y.toString();	
				
				driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys(phoneNo+",");
			}
		
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
//			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
//			
//			Assert.assertEquals("Interested in Call Forwarding? Missed Call Alerts? Outbound Dialling? - Click here to know more",successMessage);
			
			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();

			String[] trimmedText = successMessage.split(":");
			
			String transactionId = trimmedText[1];
			Assert.assertEquals("Campaign posted successfully. Your Transaction ID is ",trimmedText[0]);
		}
		
	}
	
	
	@Then("^Check the call functionality for 101 comma separated numbers$")
	public void check_the_call_functionality_for_101_comma_separated_numbers(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
		
			for(i=0;i<=100;i++) {
				Random random = new Random();
				int x = random.nextInt(9000000) + 10000000;
				Integer y = new Integer(x);
				String phoneNo = "98" + y.toString();	
				
				driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys(phoneNo+",");
			}
		
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	@Then("^Check error message when number field is blank and user upload the file and click call$")
	public void check_error_message_when_number_field_is_blank_and_user_upload_the_file_and_click_call(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	@Then("^Check error message when user enter invalid mobile number in the field and select the voice file and click Call button$")
	public void check_error_message_when_user_enter_invalid_mobile_number_in_the_field_and_select_the_voice_file_and_click_Call_button(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9*#%98516");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	@Then("^Check error message when user enter alphabets in the mobile number field and select the voice file and click Call button$")
	public void check_error_message_when_user_enter_alphabets_in_the_mobile_number_field_and_select_the_voice_file_and_click_Call_button(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("InvalidNumber");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	@Then("^Check error message when user enter special characters in the mobile number field and select the voice file and click Call button$")
	public void check_error_message_when_user_enter_special_characters_in_the_mobile_number_field_and_select_the_voice_file_and_click_Call_button(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("@$!%&%$#@*");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	@Then("^Check error message when user enter international number without 00 in the mobile number field and select the voice file and click Call button$")
	public void check_error_message_when_user_enter_international_number_without_00_in_the_mobile_number_field_and_select_the_voice_file_and_click_Call_button(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("+447911123456");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	
	@Then("^Check error message when user enter numbers in the field and dont select the voice file and click Call button$")
	public void check_error_message_when_user_enter_numbers_in_the_field_and_dont_select_the_voice_file_and_click_Call_button() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
		Thread.sleep(5000);
		
		String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
		
		Assert.assertEquals("voice.str.select.mp3",validationMessage);	
		
	}
	
	
	@Then("^Check error message when user select the other than mp3 file$")
	public void check_error_message_when_user_select_the_other_than_mp3_file(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
			
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("6219359495");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("voice.str.invalid.audio",validationMessage);
		}
		
	}
	
	
	@Then("^Check enter 101 numbers and upload the mp3 file and check message$")
	public void check_enter_101_numbers_and_upload_the_mp3_file_and_check_message(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
		
			for(i=0;i<=101;i++) {
				Random random = new Random();
				int x = random.nextInt(9000000) + 10000000;
				Integer y = new Integer(x);
				String phoneNo = "98" + y.toString();	
				
				driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys(phoneNo+",");
			}
		
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
			
			Assert.assertEquals("One or more phone numbers are incorrectly entered. Please enter in this format. 9898989898,9797979797...",validationMessage);
		}
		
	}
	
	
	@Then("^Check enter duplidate numbers and upload the mp3 file and check message$")
	public void check_enter_duplidate_numbers_and_upload_the_mp3_file_and_check_message(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
		
			
			driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9876543210,9876543210,9685743210,9685743210");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();

			String[] trimmedText = successMessage.split(":");
			
			String transactionId = trimmedText[1];
			Assert.assertEquals("Campaign posted successfully. Your Transaction ID is ",trimmedText[0]);
			
			
		}
		
	}
	
	
	@Then("^Check hint message for Audio conversion to mp3 format should be displayed$")
	public void check_hint_message_for_Audio_conversion_to_mp3_format_should_be_displayed() throws InterruptedException {
		
		Boolean audioConversionMessage = driver.findElement(By.xpath("//*[@id=\"divs1div1\"]/p/a[2]")).isDisplayed();
		Assert.assertEquals(audioConversionMessage, true);
		
		Thread.sleep(2000);
		
	}
	
	
	@Then("^Check file name should be displayed beside the Choose File button$")
	public void check_file_name_should_be_displayed_beside_the_Choose_File_button() throws InterruptedException {
		
		Boolean filename = driver.findElement(By.xpath("//*[@id=\"audioFile\"]")).isDisplayed();
		Assert.assertEquals(filename, true);
		
		Thread.sleep(2000);
		
	}
	
	
	@Then("^Check user should be able to replace the old file with new file$")
	public void check_user_should_be_able_to_replace_the_old_file_with_new_file(DataTable files) throws InterruptedException {
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {

		Boolean tab1 = driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).isDisplayed();
		Assert.assertEquals(tab1, true);
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		
		 log.logging("click on choose file", "info");
			String filename = fileUpload.get("FileName");

			log.logging("Passing the file: " + filename, "info");
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("audioFile")).sendKeys(filename);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
			Thread.sleep(5000);
			
			
//			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
//			
//			Assert.assertEquals("Interested in Call Forwarding? Missed Call Alerts? Outbound Dialling? - Click here to know more",successMessage);
			
			String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();

			String[] trimmedText = successMessage.split(":");
			
			String transactionId = trimmedText[1];
			Assert.assertEquals("Campaign posted successfully. Your Transaction ID is ",trimmedText[0]);
		
	}
		
	}
	
	
	@Then("^Check error message when the link address in the textbox is not in proper format$")
	public void check_error_message_when_the_link_address_in_the_textbox_is_not_in_proper_format() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"anchs2div1\"]")).click();
		
		Boolean linkTextBox = driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).isDisplayed();
		Assert.assertEquals(true,linkTextBox);
		driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).sendKeys("www.abc.com");
		
		driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
		Thread.sleep(2000);
		String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
		Assert.assertEquals("Please enter the URL in the currect format",validationMessage);
		
		
	}
	
	
	@Then("^Check error message when the link address is empty in the textbox$")
	public void check_error_message_when_the_link_address_is_empty_in_the_textbox() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"anchs2div1\"]")).click();
		
		Boolean linkTextBox = driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).isDisplayed();
		Assert.assertEquals(true,linkTextBox);
		driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"audioFileURLList\"]")).sendKeys("");
		
		driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
		Thread.sleep(2000);
		String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
		Assert.assertEquals("Please enter URL for the file to be uploaded",validationMessage);
		
	}
	
	
	
	@Then("^Check success message when user select proper data under my uploaded files and call$")
	public void check_success_message_when_user_select_proper_data_under_my_uploaded_files_and_call() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"anchs3div1\"]")).click();
		
		Select select = new Select(driver.findElement(By.id("libReports")));
		select.selectByVisibleText("DemoFile.mp3");
		
		driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
		Thread.sleep(2000);
//		String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
//		Assert.assertEquals("Please enter the URL in the currect format",validationMessage);
		
		String successMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();

		String[] trimmedText = successMessage.split(":");
		
		String transactionId = trimmedText[1];
		Assert.assertEquals("Campaign posted successfully. Your Transaction ID is ",trimmedText[0]);
		
	}
	
	
	
	@Then("^Check error message when user doesnt select any file name from drop down$")
	public void check_error_message_when_user_doesnt_select_any_file_name_from_drop_down() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"anchs3div1\"]")).click();
		
//		Select select = new Select(driver.findElement(By.id("fileComboBox")));
//		select.selectByVisibleText("DemoFile.mp3");
		
		driver.findElement(By.xpath("//*[@id=\"div1\"]/div/input")).click();
		Thread.sleep(2000);
		String validationMessage = driver.findElement(By.xpath("//*[@id=\"notification\"]/div")).getText();
		Assert.assertEquals("voice.str.select.mp3",validationMessage);
		
		
	}
	
	
	
	@Then("^Check Send On Date and Time dropdown should present under schedule$")
	public void check_Send_On_Date_and_Time_dropdown_should_present_under_schedule() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"contactsListForm\"]")).sendKeys("9836521470,9875463212");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"quickPostScheduleOptionRadio\"]")).click();
		
		Boolean schedule = driver.findElement(By.xpath("//*[@id=\"quickPostScheduleDiv\"]")).isDisplayed();
		
		Assert.assertEquals(schedule, true);
		
		
	}
	
	@And("^Schedule a outbound dialing call$")
	public void schedule_a_outbound_dialing_call() throws Throwable 
	{
	    log.logging("Schedule a outbound dialing call menthod started", "info");
	    
	    su.waitForPageLoadComplete(driver);
	    
	    WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("contactsListForm")));
	    driver.findElement(By.id("contactsListForm")).sendKeys(getRandomPhoneNumber());
	    	    
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.name("audioFile")));
	    String filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "DemoFile.mp3";
		driver.findElement(By.name("audioFile")).sendKeys(filename);
		 
		scheduleCall();
		
		driver.findElement(By.xpath("//input[@value='Call']")).click();
	}
	
	@Then("^Verify close button on notification and call is scheduled in Reports tab$")
	public void verify_close_button_on_notification_and_call_is_scheduled_in_Reports_tab() throws Throwable 
	{
		 log.logging("Verify close button on notification and call scheduled method started", "info");
		 
		 String transactionID, headerLoc, rowLoc;	
		 List<HashMap<String, String>> reportData;
		 headerLoc = "//table[@class='recentUploadsTable']/thead/tr/th";
		 rowLoc = "//table[@class='recentUploadsTable']/tbody/tr";
		
		 WebDriverWait wait = new WebDriverWait(driver,30);
		 wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
		 Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		 
		 transactionID = driver.findElement(By.id("notification")).getText().split(":")[1];
		 System.out.println("Transaction ID:= " + transactionID);
		 
		 // Verify close button working on notification
		 
		 wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div#notification a")));
		 driver.findElement(By.cssSelector("div#notification a")).click();
		 Thread.sleep(2000);
		 Assert.assertEquals(false, driver.findElements(By.cssSelector("div#notification")).size()>0);
		 			
		 // Navigate to Reports tab and Store report data
			
		 wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
		 driver.findElement(By.linkText("Reports")).click();
			
		 reportData = su.getTableData(driver, headerLoc, rowLoc);
			
		 System.out.println("Report Data = " + reportData);
		 Assert.assertEquals(transactionID.trim(), reportData.get(0).get("Transaction ID").trim());			  
		 
	}	

	@Then("^Check user is able to download sample files under call numbers from a file$")
	public void check_user_is_able_to_download_sample_files_under_call_numbers_from_a_file() throws Throwable 
	{
		log.logging("Check user is able to download sample files method started", "info");
		
		if(!new File("C:/Users/SampleFiles").isDirectory())
		FileUtils.forceMkdir(new File("C:/SampleAutoFiles"));	
		
		TemporaryFilesystem.setTemporaryDirectory(new File("C:\\SampleAutoFiles"));
		FileUtils.cleanDirectory(new File("C:\\SampleAutoFiles"));
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
	    driver.findElement(By.linkText("Call Numbers from a File")).click();
	    
	    //Wait until CSV link is clickable
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div.dwnLoad-Section>div:nth-child(2)>a:nth-child(1)")));
	    
	    FileDownloader downloadSampleFile = new FileDownloader("C:\\SampleAutoFiles\\"); 
	    WebElement eleCSV  = driver.findElement(By.cssSelector("div.dwnLoad-Section>div:nth-child(2)>a:nth-child(1)"));
	    String downloadedCSVFileAbsoluteLocation = downloadSampleFile.downloadFile(eleCSV);
	    System.out.println("Downloaded CSV File Absolute Location :" + downloadedCSVFileAbsoluteLocation);
	    
	    Assert.assertEquals(true, new File(downloadedCSVFileAbsoluteLocation).exists());
	    Assert.assertEquals(200, downloadSampleFile.getHTTPStatusOfLastDownloadAttempt());	
	    
	    //Wait until ZIP link is clickable
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div.dwnLoad-Section>div:nth-child(2)>a:nth-child(2)")));
	    WebElement eleZip  = driver.findElement(By.cssSelector("div.dwnLoad-Section>div:nth-child(2)>a:nth-child(2)"));
	    String downloadedZIPFileAbsoluteLocation = downloadSampleFile.downloadFile(eleZip);
	    System.out.println("Downloaded ZIP File Absolute Location :" + downloadedZIPFileAbsoluteLocation);
	    
	    Assert.assertEquals(true, new File(downloadedZIPFileAbsoluteLocation).exists());
	    Assert.assertEquals(200, downloadSampleFile.getHTTPStatusOfLastDownloadAttempt());	
	    
	}
	

	@Then("^Check upload button and file validation for Call Numbers from a File$")
	public void check_upload_button_and_validation_for_upload_without_file_for_Call_Numbers_from_a_File() throws Throwable 
	{
		log.logging("Check upload button and validation for upload without file method started", "info");
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
	    driver.findElement(By.linkText("Call Numbers from a File")).click();
	    
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contactsFile")));
	    Assert.assertEquals(true, driver.findElements(By.id("contactsFile")).size()>0);
	    
	    driver.findElement(By.id("quickPostScheduleOptionRadioFile")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div#div2 input[value='Call']")));
	    driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
	    
	    su.acceptAlert();
	    
	    driver.switchTo().defaultContent();
	    
	    // Check Validation message for upload without a file is displayed
	    
	    Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
	    Thread.sleep(2000);
	    
	    // Verify validation message for invalid extension files
	    
	    String filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "DemoFile.mp3";
		driver.findElement(By.id("contactsFile")).sendKeys(filename);
		driver.findElement(By.id("audioFileFile")).sendKeys(filename);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div#div2 input[value='Call']")));
	    driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
		su.acceptAlert();
		Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		Thread.sleep(2000);
	}
	
	@Then("^Check campaign name is not mandatory and upload history status after campaign post$")
	public void check_campaign_name_is_not_mandatory_and_upload_history_status_after_campaign_post() throws Throwable 
	{
		log.logging("Check campaign name and upload history status method started", "info");
		
		String filename;
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
	    driver.findElement(By.linkText("Call Numbers from a File")).click();
	    
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contactsFile")));
	    filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "sample.csv";
		driver.findElement(By.id("contactsFile")).sendKeys(filename);
		
		driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
		
		Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		Assert.assertEquals(false, driver.findElement(By.id("notification")).getText().toLowerCase().contains("campaign"));
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div#divs1div2>input#audioFileFile")));
		filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "DemoFile.mp3"; 
		driver.findElement(By.cssSelector("div#divs1div2>input#audioFileFile")).sendKeys(filename);
		
		driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("uploadHistoryContainer"))); 
		Assert.assertEquals(false, driver.findElement(By.id("uploadHistoryContainer")).isDisplayed());
	}
	
	@Then("^Check tabs present in voice tab and columns under reports tab$")
	public void check_tabs_present_in_voice_tab_and_columns_under_reports_tab() throws Throwable 
	{
		log.logging("Check tabs present in voice tab and columsn under reports tab method started", "info");
		
		su.waitForPageLoadComplete(driver);
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		Assert.assertEquals(true, driver.findElement(By.linkText("Call Forwarding")).isDisplayed());
		Assert.assertEquals(true, driver.findElement(By.linkText("Missed Calls")).isDisplayed());
		Assert.assertEquals(true, driver.findElement(By.linkText("Reports")).isDisplayed());
		Assert.assertEquals(true, driver.findElement(By.cssSelector("div.voice-link a:nth-child(5)")).getAttribute("href").equals("http://in.smsgupshup.com/entHelloSusieQ"));
		
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
		driver.findElement(By.linkText("Reports")).click();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@class='recentUploadsTable']/thead/tr/th")));
		
		// Verify report table columns
		
		List<String> headerListElement = su.allTableHeaderNames(driver, "//table[@class='recentUploadsTable']/thead/tr/th");
		Assert.assertEquals("Transaction ID", headerListElement.get(0).toString());
		Assert.assertEquals("Upload Date", headerListElement.get(1).toString());
		Assert.assertEquals("Scheduled Date", headerListElement.get(2).toString());
		Assert.assertEquals("Status", headerListElement.get(3).toString());
		Assert.assertEquals("Total", headerListElement.get(4).toString());
		Assert.assertEquals("Dispatched", headerListElement.get(5).toString());
		Assert.assertEquals("Picked Up", headerListElement.get(6).toString());
		Assert.assertEquals("Failed", headerListElement.get(7).toString());
		Assert.assertEquals("NCPR", headerListElement.get(8).toString());
		Assert.assertEquals("Billed Pulse", headerListElement.get(9).toString());
		Assert.assertEquals("Reports", headerListElement.get(10).trim().toString());
	}
	

	@Then("^Verify respective data of posted campaign in reports tab$")
	public void verify_respective_data_of_posted_campaign_in_reports_tab() throws Throwable 
	{
		log.logging("Verify respective data of posted campaign in reports tab method started", "info");
		
		String transactionID, headerLoc, rowLoc;
		
		headerLoc = "//table[@class='recentUploadsTable']/thead/tr/th";
		rowLoc = "//table[@class='recentUploadsTable']/tbody/tr";
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
		Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		
		transactionID = driver.findElement(By.id("notification")).getText().split(":")[1];
		
		System.out.println("Transaction ID:= " + transactionID);
		
		// Navigate to Reports tab and Store report data
		
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
		driver.findElement(By.linkText("Reports")).click();
		
		List<HashMap<String, String>> reportData = su.getTableData(driver, headerLoc, rowLoc);
		
		System.out.println("Report Data = " + reportData);
		Assert.assertEquals(transactionID.trim(), reportData.get(0).get("Transaction ID").trim());
		Assert.assertNotEquals("", reportData.get(0).get("Upload Date"));
		Assert.assertNotEquals("", reportData.get(0).get("Scheduled Date"));
		Assert.assertEquals("SCHEDULED", reportData.get(0).get("Status"));
		Assert.assertNotEquals("", reportData.get(0).get("Total"));
		Assert.assertNotEquals("", reportData.get(0).get("Dispatched"));
		Assert.assertNotEquals("", reportData.get(0).get("Picked Up"));
		Assert.assertNotEquals("", reportData.get(0).get("Failed"));
		Assert.assertNotEquals("", reportData.get(0).get("NCPR"));
		Assert.assertNotEquals("", reportData.get(0).get("Billed Pulse"));
		
	}
	
	@Then("^Verify valid scheduled date and scheduled status after scheduled time$")
	public void verify_valid_scheduled_date_and_scheduled_status_after_scheduled_time() throws Throwable 
	{
		log.logging("Verify valid scheduled date and scheduled status method started", "info");
		
		String transactionID, headerLoc, rowLoc, uploadDate, uploadTimeStamp, twoMinuteTime, threeMinuteTime, scheduledDate;
		String scheduleTimeStamp;
		
		headerLoc = "//table[@class='recentUploadsTable']/thead/tr/th";
		rowLoc = "//table[@class='recentUploadsTable']/tbody/tr";
		List<HashMap<String, String>> reportData;
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
		Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		
		transactionID = driver.findElement(By.id("notification")).getText().split(":")[1];
		
		System.out.println("Transaction ID:= " + transactionID);
		
		// Navigate to Reports tab and Store report data
		
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
		driver.findElement(By.linkText("Reports")).click();
		
		reportData = su.getTableData(driver, headerLoc, rowLoc);
		
		System.out.println("Report Data = " + reportData);
		Assert.assertEquals(transactionID.trim(), reportData.get(0).get("Transaction ID").trim());
		Assert.assertEquals("SCHEDULED", reportData.get(0).get("Status"));
		
		reportData.clear();
		
		
		// Wait till scheduled time is reached
		System.out.println("Waiting till scheduled time is reached");
		TimeUnit.MINUTES.sleep(3); 
		driver.navigate().refresh();
		 
		
        reportData = su.getTableData(driver, headerLoc, rowLoc);		
		System.out.println("Report Data = " + reportData);
		Assert.assertEquals("SUBMITTED", reportData.get(0).get("Status")); 
		
		// Verify valid scheduled date is displayed 
		
		uploadDate = reportData.get(0).get("Upload Date");
		Assert.assertNotEquals("", uploadDate);
		uploadTimeStamp = uploadDate.split(" ")[3];
		System.out.println("Upload Time Stamp = " + uploadTimeStamp);
		DateTimeFormatter df = DateTimeFormatter.ofPattern("HH:mm");		
		LocalTime lt = LocalTime.parse(uploadTimeStamp);
		twoMinuteTime = df.format(lt.plusMinutes(2));
		threeMinuteTime = df.format(lt.plusMinutes(3));
		
		scheduledDate = reportData.get(0).get("Scheduled Date");
		scheduleTimeStamp = scheduledDate.split(" ")[3];
		if(!twoMinuteTime.equals(scheduleTimeStamp))
		{ 
			if(threeMinuteTime.equals(scheduleTimeStamp))
			{
				Assert.assertEquals(true, true);
			}
			else
			{
				Assert.assertEquals(true, false);
			}
		}
		else
		{
			Assert.assertEquals(true, true);
		}
	}
	
	@Then("^Verify report for Rejected and Submitted status in Reports tab$")
	public void verify_report_for_Rejected_and_Submitted_status_in_Reports_tab() throws Throwable 
	{
		log.logging("Verify report for Rejected and Submitted status method started", "info");
		
		String filename, transactionID, headerLoc, rowLoc;
		
		List<HashMap<String, String>> reportData;
		headerLoc = "//table[@class='recentUploadsTable']/thead/tr/th";
		rowLoc = "//table[@class='recentUploadsTable']/tbody/tr";
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
	    driver.findElement(By.linkText("Call Numbers from a File")).click();
	    
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contactsFile")));
	    filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "EmptyCSV_CallFile.csv";
		driver.findElement(By.id("contactsFile")).sendKeys(filename);
	    
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div#divs1div2>input#audioFileFile")));
		filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "DemoFile.mp3"; 
		driver.findElement(By.cssSelector("div#divs1div2>input#audioFileFile")).sendKeys(filename);
		
		driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
		su.waitForPageLoadComplete(driver);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
		Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		transactionID = driver.findElement(By.id("notification")).getText().split(":")[1];
		
		// Navigate to Reports tab and Store report data
		
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
		driver.findElement(By.linkText("Reports")).click();
				
		reportData = su.getTableData(driver, headerLoc, rowLoc);
	    
		System.out.println("Report Data = " + reportData);
		Assert.assertEquals(transactionID.trim(), reportData.get(0).get("Transaction ID").trim());
		Assert.assertEquals("REJECTED", reportData.get(0).get("Status").trim());
		Assert.assertEquals("Report not Generated", reportData.get(0).get("Reports").trim());
		
		// Verify report for submitted status in Reports tab
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Outbound Dialing")));
	    driver.findElement(By.linkText("Outbound Dialing")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
	    driver.findElement(By.linkText("Call Numbers from a File")).click();
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contactsFile")));
	    filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "sample.csv";
		driver.findElement(By.id("contactsFile")).sendKeys(filename);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div#divs1div2>input#audioFileFile")));
		filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "DemoFile.mp3"; 
		driver.findElement(By.cssSelector("div#divs1div2>input#audioFileFile")).sendKeys(filename);
		
		driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
		su.waitForPageLoadComplete(driver);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
		Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		transactionID = driver.findElement(By.id("notification")).getText().split(":")[1];
		
		// Navigate to Reports tab and Store report data
		
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
		driver.findElement(By.linkText("Reports")).click();
		su.waitForPageLoadComplete(driver);
		TimeUnit.SECONDS.sleep(5);
		driver.navigate().refresh();
		
		reportData = su.getTableData(driver, headerLoc, rowLoc);
		System.out.println("Report Data = " + reportData);
		Assert.assertEquals(transactionID.trim(), reportData.get(0).get("Transaction ID").trim());
		Assert.assertEquals("SUBMITTED", reportData.get(0).get("Status").trim());
		Assert.assertNotEquals("Report not Generated", reportData.get(0).get("Reports").trim());	    
	}
	
	@Then("^Verify pagination and export report functionality in Reports tab$")
	public void verify_pagination_and_export_report_functionality_in_Reports_tab() throws Throwable
	{
		log.logging("Verify pagination and export report functionality method started", "info");
		
		verify_report_for_Rejected_and_Submitted_status_in_Reports_tab();
		
		// Verify export report functionality without selecting transaction ID
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("exportReportBtn")));
	    driver.findElement(By.id("exportReportBtn")).click();
		
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
		Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
		
		// Verify pagination
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.pagination")));
		int page_cnt = driver.findElements(By.cssSelector("div.pagination:nth-child(2)>ul>li:nth-child(3)>a")).size();
		if(page_cnt>0)
		{
			// Clicking on second page and verify total record text
			
			driver.findElements(By.cssSelector("div.pagination:nth-child(2)>ul>li:nth-child(3)>a")).get(0).click();
			su.waitForPageLoadComplete(driver);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.msg-cont")));
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText("1")));
			System.out.println("Pagination Message Text = " + driver.findElement(By.cssSelector("div.msg-cont")).getText());
			if(driver.findElement(By.cssSelector("div.msg-cont")).getText().contains("16"))
			Assert.assertEquals(true, true);
			else
			Assert.assertEquals(true, false);
			driver.findElements(By.cssSelector("div.pagination:nth-child(2)>ul>li:nth-child(3)>a")).get(0).click();
			su.waitForPageLoadComplete(driver);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.msg-cont")));
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText("2")));
			System.out.println("Pagination Message Text = " + driver.findElement(By.cssSelector("div.msg-cont")).getText());
			if(driver.findElement(By.cssSelector("div.msg-cont")).getText().contains("15"))
			Assert.assertEquals(true, true);
			else
			Assert.assertEquals(true, false);
		}
		else
		{
			System.out.println("Pagination is not present");
		}
		
	}
	
	@Then("^Check user should be able to see validation message for invalid CSV file$")
	public void check_user_should_be_able_to_see_validation_message_for_invalid_CSV_file(DataTable files) throws Throwable 
	{
		log.logging("Check user should be able to see validation message for invalid CSV file method started", "info");
		
		String filename, headerLoc, rowLoc, transactionID;
		
		List<HashMap<String, String>> reportData;
		headerLoc = "//table[@class='recentUploadsTable']/thead/tr/th";
		rowLoc = "//table[@class='recentUploadsTable']/tbody/tr";
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
	    driver.findElement(By.linkText("Call Numbers from a File")).click();
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) 
		{
			
			System.out.println("File Name := " + fileUpload.get("FileName"));
			
			filename = fileUpload.get("FileName");			
		    
		    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contactsFile")));
		    filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("contactsFile")).sendKeys(filename);
		    
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div#divs1div2>input#audioFileFile")));
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "DemoFile.mp3"; 
			driver.findElement(By.cssSelector("div#divs1div2>input#audioFileFile")).sendKeys(filename);
			
			driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
			su.waitForPageLoadComplete(driver);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
			Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
			transactionID = driver.findElement(By.id("notification")).getText().split(":")[1];
			
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div#notification a")));
			driver.findElement(By.cssSelector("div#notification a")).click();
						
			// Navigate to Reports tab and check status is REJECTED
			
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
			driver.findElement(By.linkText("Reports")).click();
			
			reportData = su.getTableData(driver, headerLoc, rowLoc);
			
			System.out.println("Report Data = " + reportData);
			Assert.assertEquals(transactionID.trim(), reportData.get(0).get("Transaction ID").trim());
			Assert.assertEquals("REJECTED", reportData.get(0).get("Status"));
			
			reportData.clear();
		    
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Outbound Dialing")));
		    driver.findElement(By.linkText("Outbound Dialing")).click();
		    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
		    driver.findElement(By.linkText("Call Numbers from a File")).click();
		    
		    Thread.sleep(2000);
		}
    }
	
	@Then("^Check user should be able to see validation message for invalid ZIP file$")
	public void check_user_should_be_able_to_see_validation_message_for_invalid_ZIP_file(DataTable files) throws Throwable 
	{
		log.logging("Check user should be able to see validation message for invalid ZIP file method started", "info");
		
		String filename, headerLoc, rowLoc, transactionID;
		
		List<HashMap<String, String>> reportData;
		headerLoc = "//table[@class='recentUploadsTable']/thead/tr/th";
		rowLoc = "//table[@class='recentUploadsTable']/tbody/tr";
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
	    driver.findElement(By.linkText("Call Numbers from a File")).click();
		
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) 
		{
			
			System.out.println("File Name := " + fileUpload.get("FileName"));
			
			filename = fileUpload.get("FileName");			
		    
		    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contactsFile")));
		    filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + filename;
			driver.findElement(By.id("contactsFile")).sendKeys(filename);
		    
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div#divs1div2>input#audioFileFile")));
			filename = System.getProperty("user.dir") + "/VoiceUploadFiles/" + "DemoFile.mp3"; 
			driver.findElement(By.cssSelector("div#divs1div2>input#audioFileFile")).sendKeys(filename);
			
			driver.findElement(By.cssSelector("div#div2 input[value='Call']")).click();
			su.waitForPageLoadComplete(driver);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notification")));
			Assert.assertEquals(true, driver.findElement(By.id("notification")).isDisplayed());
			transactionID = driver.findElement(By.id("notification")).getText().split(":")[1];
			
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div#notification a")));
			driver.findElement(By.cssSelector("div#notification a")).click();
						
			// Navigate to Reports tab and check status is REJECTED
			
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
			driver.findElement(By.linkText("Reports")).click();
			
			reportData = su.getTableData(driver, headerLoc, rowLoc);
			
			System.out.println("Report Data = " + reportData);
			Assert.assertEquals(transactionID.trim(), reportData.get(0).get("Transaction ID").trim());
			Assert.assertEquals("REJECTED", reportData.get(0).get("Status"));
			
			reportData.clear();
		    
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Outbound Dialing")));
		    driver.findElement(By.linkText("Outbound Dialing")).click();
		    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Call Numbers from a File")));
		    driver.findElement(By.linkText("Call Numbers from a File")).click();
		    
		    Thread.sleep(2000);
		}
	    
	}
	
	@Then("^Verify mp(\\d+) convert links and my uploaded files$")
	public void verify_mp_convert_links_and_my_uploaded_files(int arg1) throws Throwable 
	{
		log.logging("Verify mp3 convert links and my uploaded files method started", "info");
		
		FileDownloader downloadSampleFile = new FileDownloader(""); 
		
		WebDriverWait wait = new WebDriverWait(driver,30);		
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("media.io")));
	    
	    String mediaLink  = driver.findElement(By.linkText("media.io")).getAttribute("href").toString();
	    String audioOnlineConvertLink = driver.findElement(By.linkText("audio.online-convert")).getAttribute("href").toString();
	    Assert.assertEquals(200, downloadSampleFile.getURLStatusCode(mediaLink));	
	    //Assert.assertEquals(200, downloadSampleFile.getURLStatusCode(audioOnlineConvertLink)); - Commented as giving unknownhost exception due to site not reachable	
	
	    // Verify My Uploaded Files 
	    
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("My Uploaded Files")));
	    driver.findElement(By.linkText("My Uploaded Files")).click();
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("libReports")));
	    System.out.println("My Uploaded Files List Size " + su.getDropDownListSize(driver.findElement(By.id("libReports"))));
	    Assert.assertEquals(true, su.getDropDownListSize(driver.findElement(By.id("libReports")))>1);
	}
	
	public String getRandomPhoneNumber()
	{
		Random random = new Random();
		int x = random.nextInt(9000000) + 10000000;
		Integer y = new Integer(x);
		String phoneNo = "98" + y.toString();
		return phoneNo;
	}
	
	public void scheduleCall()
	{
		WebDriverWait wait = new WebDriverWait(driver,30);
		driver.findElement(By.cssSelector("input#quickPostScheduleOptionRadio")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Call']")));
		String curMinute = su.getDropDownText(driver.findElement(By.id("quickPostScheduleMin")));
		String curHour = su.getDropDownText(driver.findElement(By.id("quickPostScheduleHour")));
		System.out.println("Current Minute= " + curMinute + "Current Hour " + curHour);		
		if(curMinute.equals("58") || curMinute.equals("59"))
		{
			su.setDropDownTextByValue(driver.findElement(By.id("quickPostScheduleMin")),"1");			
			if(curHour.equals("12"))
			su.setDropDownTextByValue(driver.findElement(By.id("quickPostScheduleHour")),"1");
			else
			{
				String newHour = String.valueOf(Integer.parseInt(curHour) + 1);
				su.setDropDownTextByValue(driver.findElement(By.id("quickPostScheduleHour")),newHour);
			}
		}
		else
		{
			String newMinute = String.valueOf(Integer.parseInt(curMinute) + 2);
			su.setDropDownTextByValue(driver.findElement(By.id("quickPostScheduleMin")),newMinute);
		}
	}
	

}
