package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class Whatsup_PostingFlow {
	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	ExecuteQuery query;
	//String enterpriseAccId;
	SoftAssert sa;
	String whatUpUser = null;
	String whatUpPass = null;
	
	static String repoPath = "resources/Locators/Whatsup.properties";
	public static Map<String, By> locator = new HashMap<String, By>();
	
	public Whatsup_PostingFlow() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		query = new ExecuteQuery();
		locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		sa=new SoftAssert();
		whatUpUser = env.getEnterpriseWhatsAppAccUserId();
		whatUpPass = env.getEnterpriseWhatsAppAccPass();

	}
	
	
	
	@Then("^Check the WhatsApp Tab$")
	public void Check_the_WhatsApp_Tab() {
		log.logging("Refreshing the page","info");
		driver.navigate().refresh();
		log.logging("Verifying WhatsApp Tab", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");
	}
	@Then("^Enable the Whatsup tab for the user$")
	
		public void Enable_the_Whatsup_tab_for_the_user() throws IOException, InterruptedException
		{
		log.logging("Enabling the Whatsup tab", "info");
		Object userId = query.getDBResponse(whatUpUser, "id", "getiingUserId");
		
		query.setDBResponse("disableWhatsAppTab", userId.toString());
		Thread.sleep(3000);
		query.setDBResponse("EnableWhatsupTab", userId.toString());
		}
	@Then("^Check the Sub Tab of WhatsApp Tab Simple$")
	public void Check_the_Sub_Tab_of_WhatsApp_Tab_Simple()
	{
		log.logging("Verifying  Sub Tab of WhatsApp Tab Simple", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Simple", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");	
	}
	
	@Then("^Check the Sub Tab of WhatsApp Image")
	public void Check_the_Sub_Tab_of_WhatsApp_Image() throws InterruptedException
	{   Thread.sleep(1000);
		log.logging("Verifying  Sub Tab of WhatsApp Tab Image", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Image", locator);
		driver.findElement(b1).click();
		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");	

	}
	
	@Then("^Check the Sub Tab of WhatsApp Document$")
	public void Check_the_Sub_Tab_of_WhatsApp_Document() throws InterruptedException
	{   Thread.sleep(1000);
		log.logging("Verifying  Sub Tab of WhatsApp Tab Document", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Document", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");	

	}
	
	@Then("^Check the Sub Tab of WhatsApp Video$")
	public void Check_the_Sub_Tab_of_WhatsApp_Video() throws InterruptedException
	{   Thread.sleep(1000);
		log.logging("Verifying  Sub Tab of WhatsApp Tab Video", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Video", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");	

	}

	@Then("^Enter the url$")
	public void Enter_the_url(DataTable files) throws InterruptedException
	{  for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
		log.logging("Entering the URL", "info");
		String Media_URL=fileUpload.get("Media_URL");
		By b1 = PropertiesFileReader.getPropertylocator("repoPath","WhatsApp-URL", locator);
		driver.findElement(b1).sendKeys(Media_URL);

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");	
	}
	}

	@Then("^Select Upload a file link$")
	public void Select_Upload_the_file_link() throws InterruptedException
	{  
		log.logging("Click on Upload a file link", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Upload-File-link", locator);
		driver.findElement(b1).click();

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");	

	}
	@Then("^Upload the file$")
	public void Upload_the_file(DataTable files) throws InterruptedException
	{   
		for (Map<String, String> fileUpload : files.asMaps(String.class, String.class)) {
		Thread.sleep(2000);
	    Thread.sleep(2000);
		Enter_a_Number();
		String TemplateName = fileUpload.get("TemplateName");
	    Select_a_Template(TemplateName);
		String fileName = fileUpload.get("FileName");
		Select_Upload_the_file_link();
		String filewithpath = System.getProperty("user.dir") + "/MediaFiles/" + fileName;
		log.logging("Upload the file", "info");
		log.logging(filewithpath,"info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Choose-File-button", locator);
		log.logging(b1.toString(),"info");
		driver.findElement(b1).sendKeys(filewithpath);
		log.logging("Choose the file", "info");
		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");
		
		Post_the_Template();
		}
		

	}
	
	@Then("^Enter a Number$")
	public void Enter_a_Number() throws InterruptedException
	{    
		Thread.sleep(1000);
		log.logging("Enter a Number", "info");

		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-NumberBox", locator);
		driver.findElement(b1).sendKeys("7769852790");

		Assert.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");	
	}
	@Then("^Select a Template \"(.*)\"$")
	public void Select_a_Template(String Element) throws InterruptedException
	{
		By b1=PropertiesFileReader.getPropertylocator("repoPath",Element, locator);
		Thread.sleep(1000);
    log.logging("Switch to alert pop-up", "info");
	By b2=PropertiesFileReader.getPropertylocator("repoPath","WhatsApp-Click-on-Template", locator);
	Thread.sleep(1000);
	driver.findElement(b2).click();
	driver.findElement(b1).click();
    log.logging("Select a Template", "info");
    driver.findElement(By.xpath("(//input[@name='button'])[1]")).click();
    //driver.findElement(By.xpath("(//input[@id='submitFormButton'])[1]")).click();
    log.logging("click on ok button", "info");

    
	}
	@Then("^User put Whatsup username and password$")
	public void user_put_Whatsup_username_and_password() {
		log.logging("Putting Whatsup UserName and Password : " + whatUpUser, "info");
		driver.findElement(By.id("phoneId")).clear();
		driver.findElement(By.id("phoneId")).sendKeys(whatUpUser);
		driver.findElement(By.id("passwordId")).clear();
		driver.findElement(By.id("passwordId")).sendKeys(whatUpPass);
	}

	
//	@Then("^Check popup and Click Ok on Balance Popup$")
//	public void check_popup_and_Click_Ok_on_Balance_Popup() {
//		boolean popUpCheck = driver.findElement(By.xpath("(//div[@class='popupHeader'])[5]")).isDisplayed();
//		log.logging(String.valueOf(popUpCheck) + "PopUp Found", "info");
//		if (popUpCheck == true) {
//			String accountExp = driver.findElement(By.xpath("//div[text()='Account Expiry Notification']")).getText();
//			Assert.assertEquals(accountExp, "Account Expiry Notification");
//			driver.findElement(By.xpath("//div[@id='expiryId']//input[1]")).click();
//		} else
//			log.logging("No PopUp is Shown", "info");
//	}
	
	@Then("^Post the Template$")
	public void Post_the_Template() throws InterruptedException
	{ 
		try {
			
			String response = null;
			log.logging("Click on Post button", "info");

			By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhtatsApp-PostButton", locator);
			driver.findElement(b1).click();
			Thread.sleep(1000);
			sa.assertEquals(driver.getTitle(), "Gupshup - Simple Messaging");
		    By b2 = PropertiesFileReader.getPropertylocator("repoPath", "WhtatsApp-notification", locator);
		    response=driver.findElement(b2).getText();
		    sa.assertEquals(response,"Your messages will be sent shortly subject to Current Status of your account.");
		    sa.assertAll();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
//	@Then("^Enter value in Latitude \"([^\"]*)\" and Longitude \"([^\"]*)\"$")
//	public void Enter_value_in_Latitude(String latitude,String longitude) throws InterruptedException
//	{
//		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Latitude", locator);
//		driver.findElement(b1).sendKeys(latitude);
//		By b2 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-Longitude", locator);
//		driver.findElement(b1).sendKeys(longitude);
//		log.logging("Entered Latitude,Longitude", "info");
//		
//	}
	
	public String handleWindow()
	{
		String parentHandle = driver.getWindowHandle();
		log.logging("Click on Template selection box", "info");
		By b1 = PropertiesFileReader.getPropertylocator("repoPath", "WhatsApp-TemplateSelectionBox", locator);
		driver.findElement(b1).click();
	 WebDriverWait wait = new WebDriverWait(driver, 10); // Timeout in 10s
	boolean isChildWindowOpen = wait.until(ExpectedConditions.numberOfWindowsToBe(2));
	if (isChildWindowOpen) {
	    Set<String> handles = driver.getWindowHandles();
	    // Switch to child window
	    for (String handle : handles) {
	        driver.switchTo().window(handle);
	        if (!parentHandle.equals(handle)) {
	            break;
	        }
	    }
	    driver.manage().window().maximize();
	}
	return parentHandle; 
	}
	
	
	@Then("^Updating the fallback as optin$")
	
	public void updating_the_fallback_as_optin() throws IOException, InterruptedException
	{
	log.logging("Updating the fallback as optin", "info");
	Object userId = query.getDBResponse(whatUpUser, "id", "getiingUserId");
	
	query.setDBResponse("deleteOptinAtt", userId.toString());
	Thread.sleep(3000);
	query.setDBResponse("setOptinTrue", userId.toString());
	}
	
	
	@Then("^Updating optin as false$")
	
	public void updating_optin_as_false() throws IOException, InterruptedException
	{
	log.logging("Updating optin as false", "info");
	Object userId = query.getDBResponse(whatUpUser, "id", "getiingUserId");
	
	query.setDBResponse("deleteOptinAtt", userId.toString());
	Thread.sleep(3000);
	query.setDBResponse("setOptinFalse", userId.toString());
	}
	
	
	@Then("^Updating data only true$")
	public void updating_data_only_true()throws IOException, InterruptedException
	{
		log.logging("Updating data only true", "info");
		Object userId = query.getDBResponse(whatUpUser, "id", "getiingUserId");
		
		query.setDBResponse("deleteOnlyData", userId.toString());
		Thread.sleep(3000);
		query.setDBResponse("setOnlyDataTrue", userId.toString());
	}
	
	
	@Then("^Check Text tab$")
	public void check_Text_tab() throws Throwable {
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"testTabHeaderSpan\"]")).click();
		
	}

	@Then("^Check Location tab$")
	public void check_Location_tab() throws Throwable {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"locationTabHeaderSpan\"]")).click();
		
		
	}

	@Then("^User Enters geo-location$")
	public void user_Enters_geo_location() throws Throwable {
		
		driver.findElement(By.xpath("//*[@id=\"latitudeInput\"]")).sendKeys("19.108649");
		
		driver.findElement(By.xpath("//*[@id=\"longitudeInput\"]")).sendKeys("72.8300765");
		
		driver.findElement(By.xpath("//*[@id=\"locationName\"]")).sendKeys("Gupshup");
		
		driver.findElement(By.xpath("//*[@id=\"locationAddress\"]")).sendKeys("st. Floor, Silver Metropolis, 101 Western");
		
//		driver.findElement(By.xpath("//*[@id=\"isHsmMsgEmpatyDiv\"]")).click();
//		
//		driver.findElement(By.xpath("//*[@id=\"tmplListContainer\"]/div[1]")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@id=\"editNCPRtemplatesDiv\"]/div[1]/div[2]/input")).click();
		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@id=\"whatsappInputWrapper\"]/div[7]/table/tbody/tr[8]/td/input")).click();
		
	
	
	}
	
	
	@Then("^Updating data only false$")
	public void updating_data_only_false() throws IOException, InterruptedException 
	{
		log.logging("Updating data only false", "info");
		Object userId = query.getDBResponse(whatUpUser, "id", "getiingUserId");
		
		query.setDBResponse("deleteOnlyData", userId.toString());
		Thread.sleep(3000);
		query.setDBResponse("setOnlyDataFalse", userId.toString());
		
	}
	
	
}
	

