package com.enterprise.ui.reporting;

public class HtmlReport {
public String htmlReportbody (int pass, int fail ,int skip, String javaV,String env ,String envUri , String ip , String userName,String os,String chartUrl,String startTime, String endTime ,String totTime,String barChartUrl,
		String jenkinsUrl) {
	String passC= String.valueOf(pass);
	String failC = String.valueOf(fail);
	String skipC = String.valueOf(skip);
	
	String report = "<h2><img src=\"https://www.gupshup.io/developer/resources/img/assets/2019/logo_type4.png\" alt=\"\" width=\"67\" height=\"67\" /></h2>"
			+ "<h2>Enterprise Website Automation Report</h2>\n" + 
			"<table class=\"editorDemoTable 1\" style=\"width: 162px; height: 107px; border-color: #000000;\" border=\"#000000\">\n" + 
			"<tbody>\n" + 
			"<tr style=\"height: 26px;\">\n" + 
			"<td style=\"width: 54px; height: 26px; text-align: center;\"><strong>Status</strong></td>\n" + 
			"<td style=\"width: 90px; height: 26px; text-align: center;\"><strong>Count</strong></td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 35px;\">\n" + 
			"<td style=\"width: 54px; height: 35px; text-align: center;\"><strong>Pass</strong></td>\n" + 
			"<td style=\"width: 90px; height: 35px; text-align: center;\">"+passC+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 39px;\">\n" + 
			"<td style=\"width: 54px; height: 39px; text-align: center;\"><strong>Failed</strong></td>\n" + 
			"<td style=\"width: 90px; height: 39px; text-align: center;\">"+failC+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 27.8438px;\">\n" + 
			"<td style=\"width: 54px; height: 27.8438px; text-align: center;\"><strong>Skipped</strong></td>\n" + 
			"<td style=\"width: 90px; height: 27.8438px; text-align: center;\">"+skipC+"</td>\n" + 
			"</tr>\n" + 
			"</tbody>\n" + 
			"</table>\n" + 
			"<p><img src=\""+ chartUrl +"\" alt=\"\" width=\"355\" height=\"142\" /></p>\n" + 
			"<p>&nbsp;</p>"+
			"<p><img src=\""+ barChartUrl +"\" alt=\"\" width=\"355\" height=\"142\" /></p>\n" + 
			"<table class=\"editorDemoTable 1\" style=\"width: 445px; height: 65px; border-color: #000000;\" border=\"#000000\">\n" + 
			"<tbody>\n" + 
			"<tr style=\"height: 16.2656px;\">\n" + 
			"<td style=\"width: 116px; height: 16.2656px; text-align: center;\"><strong>Start Time</strong></td>\n" + 
			"<td style=\"width: 311px; height: 16.2656px; text-align: center;\">"+startTime+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 18px;\">\n" + 
			"<td style=\"width: 116px; height: 18px; text-align: center;\"><strong>End Time</strong></td>\n" + 
			"<td style=\"width: 311px; height: 18px; text-align: center;\">"+endTime+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 15px;\">\n" + 
			"<td style=\"width: 116px; height: 15px; text-align: center;\"><strong>Total Time</strong></td>\n" + 
			"<td style=\"width: 311px; height: 15px; text-align: center;\">"+totTime+"</td>\n" + 
			"</tr>\n" + 
			"</tbody>\n" + 
			"</table>\n" + 
			"<p>&nbsp;</p>"+
			"<table class=\"editorDemoTable\" style=\"width: 448px; border-color: #000000; float: centre; height: 106px;\" border=\"#000000\">"+
			"<tr style=\"height: 26px;\">\n" + 
			"<td style=\"width: 243px; height: 26px; text-align: center;\"><strong>System Details</strong></td>\n" + 
			"<td style=\"width: 187px; height: 26px; text-align: center;\"><strong>Values</strong></td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 11px;\">\n" + 
			"<td style=\"width: 243px; height: 11px; text-align: center;\"><strong>Environment</strong></td>\n" + 
			"<td style=\"width: 187px; height: 11px; text-align: center;\">"+env+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 16px;\">\n" + 
			"<td style=\"width: 243px; height: 16px; text-align: center;\"><strong>Java Version</strong></td>\n" + 
			"<td style=\"width: 187px; height: 16px; text-align: center;\">"+javaV+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 8px;\">\n" + 
			"<td style=\"width: 243px; height: 8px; text-align: center;\"><strong>Host IP</strong></td>\n" + 
			"<td style=\"width: 187px; height: 8px; text-align: center;\">"+ip+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 5px;\">\n" + 
			"<td style=\"width: 243px; height: 5px; text-align: center;\"><strong>Url</strong></td>\n" + 
			"<td style=\"width: 187px; height: 5px; text-align: center;\">"+envUri+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 15.8438px;\">\n" + 
			"<td style=\"width: 243px; height: 15.8438px; text-align: center;\"><strong>OS</strong></td>\n" + 
			"<td style=\"width: 187px; height: 15.8438px; text-align: center;\">"+os+"</td>\n" + 
			"</tr>\n" + 
			"<tr style=\"height: 15.8438px;\">\n" + 
			"<td style=\"width: 243px; height: 15.8438px; text-align: center;\"><strong>User Name</strong></td>\n" + 
			"<td style=\"width: 187px; height: 15.8438px; text-align: center;\">"+userName+"</td>\n" + 
			"</tr>\n" +
			"</tbody>\n" + 
			"</table>\n" + 
			"<p>&nbsp;</p>\n" + 
			"<p><strong>Jenkin's Url : <a href=\""+jenkinsUrl+"\">Cucumber Advance Report</a></strong></p>"+
			"<p><span style=\"text-decoration: underline;\"><strong>Note: Please find the detailed report attached.</strong></span></p>";

	return report;
}
}
