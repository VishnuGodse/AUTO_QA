package com.enterprise.ui.auto.stepDefinition;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.regex.Pattern;

import com.enterprise.ui.auto.utility.ExcelReaderUtility;
import com.enterprise.ui.auto.utility.ExcelReaderUtilityxls;
import com.enterprise.ui.auto.utility.GeneralUtlities;

public class Dynamic_url extends GeneralUtlities {
	ExcelReaderUtilityxls xls;
	ExcelReaderUtility xlsx;
	public static void main(String[] args) throws IOException {
		String dirName = "C:\\Users\\swapnil.kudalkar\\Downloads\\";
		  File dir = new File(dirName);
		  File[] files = dir.listFiles();
		  String result = null;
			String error = null;
			String errorId = null;
		  
		  try{
			  
	
			  //Pattern p = Pattern.compile(Name);
		        //java.util.regex.Matcher m = p.matcher("Reponse_" +  dtf.format(now) + "_"+".*[^0-9]([0-9]+)\\"+"_"+".*[^0-9]([0-9]+)\\.xls");
		       // java.util.regex.Matcher m = p.matcher("Response_\"+\"([0-9]{4})_([0-9]{2})_([0-9]{2})_([0-9]{2})_([0-9]{2}).xls");
		       
		        
		        //if (m.find()) {
		          //  System.out.println(m.group(1)); //print the number
		      
		        //}
			  
			  
		  		 //sort all files
		        
		        		    File lastModifiedFile = files[0];
		        		    for (int i = 1; i < files.length; i++) {
		        		       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
		        		           lastModifiedFile = files[i];
		        		       }
		        		    }
		        		
		        		    
		  
		         
		         //print the sorted values
		    /*     for (File file : files) {
		             if (file.isFile()) {
		                 System.out.println("File : " + file.getName());
		             } else if (file.isDirectory()) {
		            	 System.out.println("Directory : " + file.getName());
		             } else {
		            	 System.out.println("Unknown : " + file.getName());
		             }
		         }
		  	*/
		      
		  }catch(Exception ex)
		  {
		      System.out.println("Not Found");
		  }
		
		  
		 
	            
		  
		//System.out.println( System.getProperty("user.name") );
	}
}
