package com.enterprise.ui.auto.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;



public class PropertiesFileReader {
	public static Map < String, By > propertiesFileReaderMethod(String rawfilepath) {
		Map < String, By > keyvalue = new HashMap < > ();
		FileInputStream fileInput = null;
		try {
			File file = new File(rawfilepath);
			fileInput = null;
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			System.out.println("Error in loading the file object ");
			e.printStackTrace();
		}
		Properties properties = new Properties();
		try {
			properties.load(fileInput);
		} catch (IOException e) {
			System.out.println("Error in loading the properties file");
			e.printStackTrace();
		}
		Set < String > keys = new HashSet < String > ();
		keys = properties.stringPropertyNames();
		for (String key: keys) {
			try {
				keyvalue.put(key,getBy(key, rawfilepath));
			} catch (Exception e) {
				System.out.println("Error occurred during Key Value pair generation");
			}
		}
		return keyvalue;
	}
	public static By getBy(String key, String path) {
		By by = null;
		String locators[] = getProperty(key, path).split("~");
		String locatorType = locators[0];
		String locator = locators[1];
		switch(locatorType.toLowerCase()) {
		case "xpath":
			by = By.xpath(locator);
			break;
		case "id":
			by = By.id(locator);
			break;
		case "name":
			by = By.name(locator);
			break;
		case "tagname":
			by = By.tagName(locator);
			break;
		case "css":
			by = By.cssSelector(locator);
			break;
		case "linktext":
			by = By.linkText(locator);
			break;
		case "partiallinktext":
			by = By.partialLinkText(locator);
			break;
		default:
			System.out.println("Invalid locator");
		}
		return by;	
	}
	public static String getProperty(String key, String path) {
		String value = null;
		try {
			File file = new File(path);
			FileInputStream fileInput = new FileInputStream(file);
			Properties properties = new Properties();
			properties.load(fileInput);
			fileInput.close();
			value = properties.getProperty(key);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return value;
	}
	public static By getPropertylocator(String rawfilepath,String key,Map<String, By> locator)
	{
		
		return (locator.get(key));
	}
	public void add()
	{
		
	}
}
