package com.enterprise.ui.auto.utility;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONArray;

import com.enterprise.ui.auto.Bo.EnvDatabaseBO;

public class DbConnectionUtility {
	private Connection connect = null;
	private Statement statement = null;
	private ResultSet resultSet = null;
	public JsonUtility rj;
	public  EnvDatabaseBO edb;

	public DbConnectionUtility() {
		rj = new JsonUtility();

	}

	public JSONArray dbReadConnetion(String db, String query, String port) throws IOException {
		JSONArray ja = new JSONArray();
		try {
			edb = new EnvDatabaseBO(db);
			String host = edb.getDbHost();
			String user = edb.getDbUser();
			String passwd = edb.getDbPass();
			if (port.isEmpty()) {
				System.out.println("Port not found so getting it from config");
			} else
				port = edb.getDbPort();
			connect = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + db, user, passwd);
			// jdbc:mysql://10.40.1.72:3306/SMSWEB
			statement = connect.createStatement();
			resultSet = statement.executeQuery(query);
			while (resultSet.next()) {
				ja = rj.getResultSetJson(resultSet);
			
				return ja;
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ja;
	}
	
	public  boolean dbInsertionUpdation(String db, String query, String port ) throws IOException {
		boolean result = true;
		
		try {
		edb = new EnvDatabaseBO(db);
			String host = edb.getDbHost();
			String user = edb.getDbUser();
			String passwd = edb.getDbPass();
			if (port.isEmpty()) {
				System.out.println("Port not found so getting it from config");
			} else
				port = edb.getDbPort();
			connect = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + db, user, passwd);
			// jdbc:mysql://10.40.1.72:3306/SMSWEB
			statement = connect.createStatement();
		 int i =statement.executeUpdate(query);
		 if (i > 0) {
		 result =true;
		 }else 
			 result =false;
		 
		 
				
			}

		 catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

}
