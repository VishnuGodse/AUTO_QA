package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.MessageCheckInFileUtility;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.PropertiesFileReader;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignUp{

public Inititor init;
public EnvBO env;
public SeleniumUtility su;
public WebDriver driver;
String username;
String password;
ReportingLogging log;
PropRead pr;
GeneralUtlities gu;
String groupName = null;
String phoneNo;
ExecuteQuery query;
int phoneNocnt = 0;
String aggrAccId = null;
boolean otherLang = false;
boolean flash = false;
boolean unicodeFlash = false;
SoftAssert sa;
String template_id;
MessageCheckInFileUtility msgcheck;
String userid;
String sName;
String sCompany;
String sEmail;
String sMobile;
String sAddress;
String sCity;
String sState;
String sPincode;
String userPhone;


Boolean name_flag,company_flag,industry_flag,email_flag,mob_flag,com_flag,add_flag,city_flag,state_flag,pin_flag=false;




static String repoPath = "resources/Locators/signup.properties";
public static Map<String, By> locator = new HashMap<String, By>();

public SignUp() throws IOException {
	init = new Inititor();
	env = new EnvBO();
	su = new SeleniumUtility();
	driver = su.getDriver();
	log = new ReportingLogging();
	pr = new PropRead();
	locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
	query = new ExecuteQuery();
	driver.manage().deleteAllCookies();
	sa = new SoftAssert();
}

	
	@Given("^User landed on Signup page$")
	public void user_landed_on_Signup_page()
	{
	
	}
	@Then("^User click on signup link$")
	public void user_click_on_signup_link() throws Exception {
		
        Thread.sleep(5000);
		driver.findElement(By.linkText("Signup")).click();
		
	}
	@Then("^User enter the details$")
	public void user_enter_the_details() throws Exception
	{
		try {
			sName=pr.readConfig("Name",repoPath)+ranNameGen();
			By b1 = PropertiesFileReader.getPropertylocator("repoPath", "name",locator); 
			driver.findElement(b1).sendKeys(sName);
			 
			//****Company Name*****
			sCompany=pr.readConfig("CompanyName",repoPath);
			By b2 = PropertiesFileReader.getPropertylocator("repoPath","companyname",locator); 
			driver.findElement(b2).sendKeys(sCompany);
			
			//****Industry Name*****
					sCompany=pr.readConfig("CompanyName",repoPath);
					By b3 = PropertiesFileReader.getPropertylocator("repoPath", "industry",locator); 
					Select select=new Select(driver.findElement(b3));
					select.selectByIndex(1);
			        Thread.sleep(1000);
			        
	        //****Email*****
			        sCompany=pr.readConfig("Email",repoPath)+ranNameGen()+"@mailinator.com";
					By b4 = PropertiesFileReader.getPropertylocator("repoPath", "email",locator); 
					driver.findElement(b4).sendKeys(sCompany);
			        Thread.sleep(5000); 
			        
		   //****Mobile*****
			        sMobile=ranMobNum();
					By b5 = PropertiesFileReader.getPropertylocator("repoPath", "mobile",locator); 
					driver.findElement(b5).sendKeys(sMobile);
			        Thread.sleep(2000);   	   
			        
		 //****Category of messages*****
			        By b6 = PropertiesFileReader.getPropertylocator("repoPath", "category",locator); 
					Select sel=new Select(driver.findElement(b6));
					sel.selectByIndex(1);
			        Thread.sleep(300);	 	       
			        
					
					  //****Address***** 
			         sAddress=pr.readConfig("Address",repoPath); 
			         By b7 =  PropertiesFileReader.getPropertylocator("repoPath", "address",locator);
					  driver.findElement(b7).sendKeys(sAddress); Thread.sleep(7000);
					  
					  //*****City****** 
					  sCity=pr.readConfig("City",repoPath);
					  By b8 = PropertiesFileReader.getPropertylocator("repoPath", "city",locator);
					  driver.findElement(b8).sendKeys(sCity);
					  
					  //****State***** 
					  sName=pr.readConfig("State",repoPath); 
					  By b9 =PropertiesFileReader.getPropertylocator("repoPath", "state",locator);
					  Select sel1=new Select(driver.findElement(b9)); sel1.selectByValue(sName);
					  Thread.sleep(8000);
					  
					  //****Pincode***** 
					  sPincode=pr.readConfig("Pincode",repoPath); 
					  By b10 =PropertiesFileReader.getPropertylocator("repoPath", "pincode",locator);
					  driver.findElement(b10).sendKeys(sPincode); Thread.sleep(600);
					  
					  JavascriptExecutor jse = (JavascriptExecutor)driver;
					  jse.executeScript("window.scrollBy(0,250)");
					 
	  //Checkbox
					
					By b11 = PropertiesFileReader.getPropertylocator("repoPath", "robot",locator); 
					//driver.findElement(b11).click();
					WebElement captcha=driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']"));
					Thread.sleep(30000); 
					driver.switchTo().frame(captcha);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					
					WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='rc-anchor-center-container']//label[@class='rc-anchor-center-item rc-anchor-checkbox-label']")));
					element.click();
					Thread.sleep(20000);
					
			
					Thread.sleep(8000);
					//driver.switchTo().alert().accept();
					Thread.sleep(10000);
					driver.switchTo().parentFrame();
					//driver.switchTo().defaultContent();
					
					 //****Name*****
					 
					
					
					By b12 = PropertiesFileReader.getPropertylocator("repoPath", "terms",locator); 
					driver.findElement(b12).click();
					Thread.sleep(10000);
					
					By b13 = PropertiesFileReader.getPropertylocator("repoPath", "create",locator); 
					driver.findElement(b13).click();
					Thread.sleep(10000);
					
					

		}
		 
		catch(Exception e )
		{
			System.out.println("Captcha cannot be bypassed");
			log.logging("Captcha cannot be bypassed", "info");
			Assert.fail("Captcha cannot be bypassed");
		}
			/////////	
	}
	@Then("^User continues on Activation page$")
	public void user_continues_on_Activation_page() throws Throwable {
		
		By c = PropertiesFileReader.getPropertylocator("repoPath","userPhone",locator); 
		String ph=driver.findElement(c).getText();
		String phone="-"+ph;
		Object guser=query.getDBResponse(phone,"globalUserId","getGlobalUser");
		String global_user = guser.toString();
		Object ver=query.getDBResponse(global_user,"verificationKey","getVerificationKey");
		String ver_key = ver.toString();
		By c1 = PropertiesFileReader.getPropertylocator("repoPath", "active",locator); 
		driver.findElement(c1).sendKeys(ver_key);
		Thread.sleep(10000);
		By c2 = PropertiesFileReader.getPropertylocator("repoPath", "actbutton",locator); 
		driver.findElement(c2).click();
	    
	}

	@Then("^User continues to KYC$")
	public void user_continues_to_KYC() throws Throwable {
		By d = PropertiesFileReader.getPropertylocator("repoPath","kyccheck",locator); 
	    driver.findElement(d).click();
	    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	    String pan=pr.readConfig("PAN",repoPath);
	    By d1 = PropertiesFileReader.getPropertylocator("repoPath","pan",locator); 
	    driver.findElement(d1).sendKeys(pan);
	    
	    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	    String gstin=pr.readConfig("GSTIN",repoPath);
	    By d2 = PropertiesFileReader.getPropertylocator("repoPath","gstin",locator); 
	    driver.findElement(d2).sendKeys(gstin);
	    
	    By d3 = PropertiesFileReader.getPropertylocator("repoPath", "reg",locator); 
		Select sel=new Select(driver.findElement(d3));
		sel.selectByIndex(1);
        Thread.sleep(300);	 	   
	    
        By d4 = PropertiesFileReader.getPropertylocator("repoPath", "cust",locator); 
		Select sel1=new Select(driver.findElement(d3));
		sel1.selectByIndex(1);
        Thread.sleep(300);	
	    
	   
	}
	
	@Then("^User keeps the name field blank$")
	public void user_keeps_the_name_field_blank() throws Throwable {
	 name_flag=true;   
	}

	@Then("^User enter the other details$")
	public void user_enter_the_other_details() throws Throwable {
		
		try {
			if(name_flag=true)
			{
				System.out.println("Name field blank");
			}
			else
			{
				sName=pr.readConfig("Name",repoPath)+ranNameGen();
				By b1 = PropertiesFileReader.getPropertylocator("repoPath", "name",locator); 
				driver.findElement(b1).sendKeys(sName);
			}
			 
			//****Company Name*****
			if(company_flag=true)
			{
				System.out.println("Company field blank");
			}
			else
			{
				sCompany=pr.readConfig("CompanyName",repoPath);
				By b2 = PropertiesFileReader.getPropertylocator("repoPath","companyname",locator); 
				driver.findElement(b2).sendKeys(sCompany);
				
			}
			
			//****Industry Name*****
			if(industry_flag=true)
			{
				System.out.println("Industry field blank");
			}
			else
			{
				sCompany=pr.readConfig("CompanyName",repoPath);
				By b3 = PropertiesFileReader.getPropertylocator("repoPath", "industry",locator); 
				Select select=new Select(driver.findElement(b3));
				select.selectByIndex(1);
		        Thread.sleep(1000);	
			}
					
			        
	        //****Email*****
			if(email_flag=true)
			{
				System.out.println("Email field blank");
			}
			else
			{
				sCompany=pr.readConfig("Email",repoPath)+ranNameGen()+"@mailinator.com";
				By b4 = PropertiesFileReader.getPropertylocator("repoPath", "email",locator); 
				driver.findElement(b4).sendKeys(sCompany);
		        Thread.sleep(5000); 	
			}
			        
			        
		   //****Mobile*****
			if(mob_flag=true)
			{
				System.out.println("Mobile field blank");
			}
			else
			{
				sMobile=ranMobNum();
				By b5 = PropertiesFileReader.getPropertylocator("repoPath", "mobile",locator); 
				driver.findElement(b5).sendKeys(sMobile);
		        Thread.sleep(2000);	
			}
			           	   
			        
		 //****Category of messages*****
			if(com_flag=true)
			{
				System.out.println("Category of message field blank");
			}
			else
				
			{
				By b6 = PropertiesFileReader.getPropertylocator("repoPath", "category",locator); 
				Select sel=new Select(driver.findElement(b6));
				sel.selectByIndex(1);
		        Thread.sleep(300);	 	
			}
				    	       
			if(add_flag=true)
			{
				System.out.println("Address field blank");
			}
			else
			{
				 //****Address***** 
		         sAddress=pr.readConfig("Address",repoPath); 
		         By b7 =  PropertiesFileReader.getPropertylocator("repoPath", "address",locator);
				  driver.findElement(b7).sendKeys(sAddress); Thread.sleep(7000);
			}
					 
					  
			if(city_flag=true)	
			{
				System.out.println("City field blank");
			}
			else
			{
				//*****City****** 
				  sCity=pr.readConfig("City",repoPath);
				  By b8 = PropertiesFileReader.getPropertylocator("repoPath", "city",locator);
				  driver.findElement(b8).sendKeys(sCity);
			}
			
			if(state_flag=true)		
			{
				System.out.println("State field blank");
			}
			else
			{
				//****State***** 
				  sName=pr.readConfig("State",repoPath); 
				  By b9 =PropertiesFileReader.getPropertylocator("repoPath", "state",locator);
				  Select sel1=new Select(driver.findElement(b9)); sel1.selectByValue(sName);
				  Thread.sleep(8000);	
			}
				
			if(pin_flag=true)
			{
				System.out.println("Pincode field blank");
			}
			else
			{
				  //****Pincode***** 
				  sPincode=pr.readConfig("Pincode",repoPath); 
				  By b10 =PropertiesFileReader.getPropertylocator("repoPath", "pincode",locator);
				  driver.findElement(b10).sendKeys(sPincode); Thread.sleep(600);
			}
					  
									  
					  JavascriptExecutor jse = (JavascriptExecutor)driver;
					  jse.executeScript("window.scrollBy(0,250)");
					 
	  //Checkbox
					
					By b11 = PropertiesFileReader.getPropertylocator("repoPath", "robot",locator); 
					//driver.findElement(b11).click();
					WebElement captcha=driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']"));
					Thread.sleep(30000); 
					driver.switchTo().frame(captcha);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					
					WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='rc-anchor-center-container']//label[@class='rc-anchor-center-item rc-anchor-checkbox-label']")));
					element.click();
					Thread.sleep(20000);
					
			
					Thread.sleep(8000);
					//driver.switchTo().alert().accept();
					Thread.sleep(10000);
					driver.switchTo().parentFrame();
					//driver.switchTo().defaultContent();
					
					 //****Name*****
					 
					

		}
		 
		catch(Exception e )
		{
			System.out.println("Captcha cannot be bypassed");
			log.logging("Captcha cannot be bypassed", "info");
			Assert.fail("Captcha cannot be bypassed");
		}
	   
	}

	@When("^User submits the form$")
	public void user_submits_the_form() throws Throwable {
		By b12 = PropertiesFileReader.getPropertylocator("repoPath", "terms",locator); 
		driver.findElement(b12).click();
		Thread.sleep(10000);
		
		By b13 = PropertiesFileReader.getPropertylocator("repoPath", "create",locator); 
		driver.findElement(b13).click();
		Thread.sleep(10000);
	}

	@Then("^Check the validation$")
	public void check_the_validation() throws Throwable 
	{
	    if(name_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='contactPersonNameTextboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"This information is mandatory.");
			log.logging("This information is mandatory.", "info");
	    }
	    if(com_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='companyNameTextboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"This information is mandatory.");
			log.logging("This information is mandatory.", "info");	
	    }
	    if(industry_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='userIndustryComboboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"Please select a industry.");
			log.logging("Please select a industry.", "info");	
	    }
	    if(email_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='contactPersonEmailTextboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"This information is mandatory.");
			log.logging("This information is mandatory.", "info");		
	    }
	    if(com_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='businessTypeComboboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"Please select a Category of messages");
			log.logging("Please select a Category of messages", "info");	
	    }
	    if(mob_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='contactPersonMobileTextboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"This information is mandatory.");
			log.logging("This information is mandatory.", "info");
	    }
	    if(add_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='addressTextAreaErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"This information is mandatory.");
			log.logging("This information is mandatory.", "info");
	    }
	    
	    if(city_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='cityTextboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"This information is mandatory.");
			log.logging("This information is mandatory.", "info");
	    }
	    
	    if(state_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='stateComboboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"Please select a state.");
			log.logging("Please select a state.", "info");
	    }
	    if(pin_flag=true)
	    {
	    	String err_m1=driver.findElement(By.xpath("//span[@id='pincodeTextboxErrorEle']")).getText();
	    	sa.assertEquals(err_m1,"This information is mandatory.");
			log.logging("This information is mandatory.", "info");
	    }
	    
	    String err=driver.findElement(By.xpath("//div[@id='submitButtonErrorEle']")).getText();
	    sa.assertEquals(err,"One or more fields have errors marked in red. Please correct those errors and submit again.");
		log.logging("TOne or more fields have errors marked in red. Please correct those errors and submit again.", "info");
	}

	@Then("^User keeps the company name field blank$")
	public void user_keeps_the_company_name_field_blank() throws Throwable {
	    company_flag=true;
	}

	@Then("^User keeps the industry name field blank$")
	public void user_keeps_the_industry_name_field_blank() throws Throwable {
	    industry_flag=true;
	}

	@Then("^User keeps the email field blank$")
	public void user_keeps_the_email_field_blank() throws Throwable {
	    email_flag=true;
	}

	@Then("^User keeps the mobile field blank$")
	public void user_keeps_the_mobile_field_blank() throws Throwable {
	   mob_flag=true;
	}

	@Then("^User keeps the Category of messages field blank$")
	public void user_keeps_the_Category_of_messages_field_blank() throws Throwable {
	   com_flag=true;
	}

	@Then("^User keeps the Address field blank$")
	public void user_keeps_the_Address_field_blank() throws Throwable {
	    add_flag=true;
	}

	@Then("^User keeps the City field blank$")
	public void user_keeps_the_City_field_blank() throws Throwable {
	    city_flag=true;
	}

	@Then("^User keeps the State field blank$")
	public void user_keeps_the_State_field_blank() throws Throwable {
	   state_flag=true;
	}

	@Then("^User keeps the Pincode field blank$")
	public void user_keeps_the_Pincode_field_blank() throws Throwable {
	  pin_flag=true;
	}


	@Then("^User logs out$")
	public void user_logs_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User logs in again$")
	public void user_logs_in_again() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	
	public String ranNameGen(){
	    int leftLimit = 97; // letter 'a'
	    int rightLimit = 122; // letter 'z'
	    int targetStringLength =3;
	    Random random = new Random();

	    String generatedString = random.ints(leftLimit, rightLimit + 1)
	      .limit(targetStringLength)
	      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	      .toString();

	    System.out.println(generatedString);
		return generatedString;
	}
	
	public String ranMobNum()
	{
		Random random = new Random();
		int x = random.nextInt(9000000) + 10000000;
		Integer y = new Integer(x);
		String phoneNo = "98" + y.toString();
		return phoneNo;
	}
	
	}


