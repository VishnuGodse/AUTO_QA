package com.enterprise.ui.auto.utility;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.mysql.cj.xdevapi.JsonArray;

public class JsonUtility {
	JSONArray jsonArray = new JSONArray();

	public JSONArray getResultSetJson(ResultSet resultSet) throws JSONException, SQLException {
		int total_rows = resultSet.getMetaData().getColumnCount();
		for (int i = 0; i < total_rows; i++) {
			JSONObject obj = new JSONObject();

			int type = resultSet.getMetaData().getColumnType(i + 1);
			// Varbinary need String Object
			//Refer https://www.tutorialspoint.com/java-resultsetmetadata-getcolumntype-method-with-example
			if (type == -3) {
				obj.put(resultSet.getMetaData().getColumnLabel(i + 1), resultSet.getString((i + 1)));
			} else
				obj.put(resultSet.getMetaData().getColumnLabel(i + 1), resultSet.getObject((i + 1)));
			jsonArray.put(obj);
		}
		return jsonArray;

	}

	public Object getKey(JSONArray array, String key) {
		Object value = null;
		for (int i = 0; i < array.length(); i++) {
			JSONObject item = array.getJSONObject(i);
			if (item.keySet().contains(key)) {
				value = item.get(key);
				break;
			}
		}

		return value;

	}
}
