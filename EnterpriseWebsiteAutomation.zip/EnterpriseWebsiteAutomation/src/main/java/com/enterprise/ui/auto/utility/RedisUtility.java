/**
 * 
 */
package com.enterprise.ui.auto.utility;

import com.lambdaworks.redis.RedisClient;
import com.lambdaworks.redis.RedisConnection;
import com.lambdaworks.redis.RedisURI;
import com.mysql.cj.x.protobuf.MysqlxCursor.Open;

/**
 * @author Rahul Jain
 *
 */
public class RedisUtility {
	public String getDatafromRedis(String ip, String port, String opretions, String key, String mapkey,String password) {
		RedisClient redisClient = new RedisClient(RedisURI.create("redis://" + ip + ":" + port));
		RedisConnection<String, String> connection = redisClient.connect();
		try {
			connection.auth(password);
			
		} catch (Exception e) {
			e.getMessage();
					}
		String value = null;
		if (opretions.equalsIgnoreCase("get")) {
			value = connection.get(key);
		}
		if (opretions.equalsIgnoreCase("hget")) {
			value = connection.hget(key, mapkey);
		}
		connection.close();
		redisClient.shutdown();
		System.out.println(value);
		return value;
	}
}
