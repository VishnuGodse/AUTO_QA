package com.enterprise.ui.auto.utility;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
//import SevenZip.Compression.LZMA.*;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.SendKeysAction;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.stepDefinition.Inititor;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.MessageCheckInFileUtility;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;
import com.opencsv.CSVWriter;

import SevenZip.Compression.LZMA.Encoder;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class DLTDBbtoExcelUtility {

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	String template_id;
	MessageCheckInFileUtility msgcheck;
	String userid;
	Map<String, String> hm;
	List<String> columnName ;
	List<String> columnValue ;
	Map<String,String> dbmethodcaller;
	Encoder encoder;
	
	

	public DLTDBbtoExcelUtility() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		// locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		msgcheck = new MessageCheckInFileUtility();
		userid = env.getEnterpriseUsername();
		hm = new HashMap<String, String>();
		dbmethodcaller = new HashMap<String, String>();
		columnName = new ArrayList<>();
		columnValue = new ArrayList<>();
		encoder = new Encoder();
		
		

	}

	public Map<String, String> user_gets_db_data(String header,String type) throws Exception {
		
		try {
			log.logging("Got user id" + userid, "info");
			Object userId = query.getDBResponse(userid, "id", "getiingUserId");
			
			
			  if(header.equalsIgnoreCase("template")&&type.equalsIgnoreCase("text"))
					  {
				          Object tempdata=query.getDBResponse(userId.toString(),
						  "template","GetValueDLT"); 
				          String tdata = tempdata.toString();
//						  System.out.println("Template name"+tdata);
						  hm.put("message", tdata);
					  }
			
			  if(header.equalsIgnoreCase("templateid")&&type.equalsIgnoreCase("text"))
			  {
			  Object tempdata1=query.getDBResponse(userId.toString(),
			  "dltTemplateId","GetValueDLT");
			  String tdata1 = tempdata1.toString();
//			  System.out.println("Template name"+tdata1);
			  hm.put("templateid", tdata1);
			  }
			
			  if(header.equalsIgnoreCase("template")&&type.equalsIgnoreCase("unicode"))
			  {
			  Object tempudata=query.getDBResponse(userId.toString(), "template","GetUniValueDLT");
			  String tudata = tempudata.toString();
//			  System.out.println("Template name"+tudata);
			  hm.put("Template", tudata);
			  
			  }
			
			  if(header.equalsIgnoreCase("templateid")&&type.equalsIgnoreCase("unicode"))
			  {
			   Object tempudata1=query.getDBResponse(userId.toString(), "dltTemplateId","GetUniValueDLT");
			   String tudata1 = tempudata1.toString();
//			   System.out.println("Template ID "+tudata1);
			   hm.put("templateid", tudata1);
			  }
			  

			  if(header.equalsIgnoreCase("mask")&&type.equalsIgnoreCase("text"))
			  {
				  Object mask=query.getDBResponse(userId.toString(), "defaultMask","GetMaskValue");
				   String maskd = mask.toString();
				   System.out.println("Mask name"+maskd);
				   hm.put("mask",maskd);
			  }
			  if(header.equalsIgnoreCase("mask")&&type.equalsIgnoreCase("unicode"))
			  {
				  Object mask1=query.getDBResponse(userId.toString(), "defaultMask","GetUniMaskValue");
				   String maskd1 = mask1.toString();
				   System.out.println("Mask name"+maskd1);
				   hm.put("mask",maskd1);
			  }
			  
			  for(Map.Entry entry : hm.entrySet())
				{
				    System.out.println("key: " + entry.getKey() + "; value: " + entry.getValue());
				    System.out.println("Size of HasMap ");
				    System.out.println(hm.size());
				}
			
			}
		catch(Exception e )
		{
			log.logging("Exception encountered : " + e, "info");
		}
		
		return hm;
		
	}
	
	//********************ExcelWriteCode**********************************************************
	
//	@Then("^Write database values in excel$")
	public void Write_database_values_in_excel(DataTable data) throws Exception  {
		
			
			//***************DbUtility***********************************************************************
			try {
				//############################################### XLSX FIle Creation ############################################################
				
				String filePath_xlsx =System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_xlsx.xlsx";
				File file_xlsx = new File(filePath_xlsx);
				file_xlsx.createNewFile();
				
				FileInputStream fis = new FileInputStream(filePath_xlsx);
				XSSFWorkbook	wb = new XSSFWorkbook(fis);
				XSSFSheet	sheet = wb.getSheetAt(0);
				XSSFRow	row = sheet.getRow(0);
				
				//############################################### XLS FIle Creation ############################################################
				
				String filePath_xls =System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_xls.xls";
				File file_xls = new File(filePath_xls);
				file_xls.createNewFile();
				FileInputStream fis_xls = new FileInputStream(filePath_xls);
				HSSFWorkbook	wb_xls = new HSSFWorkbook(fis_xls);
				HSSFSheet	sheet_xls = wb_xls.getSheetAt(0);
				HSSFRow	row_xls = sheet_xls.getRow(0);
				
				//############################################### CSV FIle Creation ############################################################
				String filePath_csv =System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_csv.csv";
				File file_csv = new File(filePath_csv);
				file_csv.createNewFile();
				FileWriter writer_CSV = new FileWriter(file_csv,false);
				
				//############################################### TXT FIle Creation ############################################################
				String filePath_txt =System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_txt.txt";
				File file_txt = new File(filePath_txt);
				file_txt.createNewFile();
				FileWriter writer_txt = new FileWriter(file_txt,false);
				
				
				Random random = new Random();
				int x = random.nextInt(9000000) + 10000000;
				Integer y = new Integer(x);
				String phoneNo = "98" + y.toString();
				
				for (Map<String, String> dataMap : data.asMaps(String.class, String.class)) {
					String columnHeader = dataMap.get("Headers");
					String msgType = dataMap.get("MsgType");
					System.out.println("columnHeader Contains -");
					System.out.println(columnHeader);
					
				DLTDBbtoExcelUtility db = new DLTDBbtoExcelUtility();
				dbmethodcaller = db.user_gets_db_data(columnHeader,msgType);
				
				for (Map.Entry entry : dbmethodcaller.entrySet())
				{
				    System.out.println("key: " + entry.getKey() + "; value: " + entry.getValue());
				    
				    String cname = entry.getKey().toString();
				    columnName.add(cname);
				   
				    
				    String cValue = entry.getValue().toString();
				    columnValue.add(cValue);
				    String records = (cname + "" + cValue);
				   
				    
				    
				    System.out.print("columnName.add(cname)");
				    System.out.println(cname);
				
				}
				
				
				}
				
				
				//############################################### Write Excel FIle ####################################################################################
				
					try
					{
						int rowID = 0;
						row = sheet.createRow(rowID);
						row_xls = sheet_xls.createRow(rowID);
						int columnNameSize = columnName.size();
						System.out.println("columnNameSize is");
						System.out.println(columnNameSize);
						
						// for each loop
				        for (int i = 0; i<columnNameSize;i++)
				        {
				        	
				        	row.createCell(0).setCellValue("Phone no.");
				        	row.createCell(i+1).setCellValue(columnName.get(i));
				        	
				        	row_xls.createCell(0).setCellValue("Phone no.");
				        	row_xls.createCell(i+1).setCellValue(columnName.get(i));
				           
				        }
				        row = sheet.createRow(rowID+1);
				        row_xls = sheet_xls.createRow(rowID+1);
				        int columnValueSize = columnValue.size();
				        
				        System.out.println("columnValueSize is");
						System.out.println(columnValueSize);
						
				        for (int j = 0; j<columnValueSize;j++)
				        {
				        	row.createCell(0).setCellValue(phoneNo);
				        	row.createCell(j+1).setCellValue(columnValue.get(j));
				            
				        	row_xls.createCell(0).setCellValue(phoneNo);
				        	row_xls.createCell(j+1).setCellValue(columnValue.get(j));
				        }
						
						FileOutputStream fos = new  FileOutputStream(filePath_xlsx);
						wb.write(fos);
						fos.close();
						
						FileOutputStream fos_xls = new  FileOutputStream(filePath_xls);
						wb_xls.write(fos_xls);
						fos_xls.close();
						}
						catch(Exception ex)
						{
							ex.printStackTrace();
							
						}
							
					
					String collect = columnName.stream().collect(Collectors.joining(";"));
					collect = collect.trim();
					String collect1 = columnValue.stream().collect(Collectors.joining(";"));
					collect1 = collect1.trim();	
					
					String collectTxt = columnName.stream().collect(Collectors.joining("	"));
					collect = collect.trim();
					String collect1Txt = columnValue.stream().collect(Collectors.joining("	"));
					collect1 = collect1.trim();	
					
					//############################################# Write CSV FIle ##################################################################
					writer_CSV.write("Phone no."+";"+collect);
					writer_CSV.write("\n");
					writer_CSV.write(phoneNo+";"+collect1);					
					writer_CSV.flush();
					writer_CSV.close();
					
					//################################### write and close txt file ###################################################################
					writer_txt.write("Phone no."+"	"+collectTxt);
					writer_txt.write("\n");
					writer_txt.write(phoneNo+"	"+collect1Txt);					
					writer_txt.flush();
					writer_txt.close();
					
					//############################################################  ZIP File Code ####################################################
					
					String zipfileName_xlsx = file_xlsx.getName().concat(".zip");
					String zipfileName_xls = file_xls.getName().concat(".zip");
					String zipfileName_txt = file_txt.getName().concat(".zip");
					String zipfileName_csv = file_csv.getName().concat(".zip");
					
					
					FileOutputStream fos_xlsx = new FileOutputStream(zipfileName_xlsx);
					FileOutputStream fos_xls = new FileOutputStream(zipfileName_xls);
					FileOutputStream fos_txt = new FileOutputStream(zipfileName_txt);
					FileOutputStream fos_csv = new FileOutputStream(zipfileName_csv);
					
					ZipOutputStream zos_xlsx = new ZipOutputStream(fos_xlsx);
					zos_xlsx.putNextEntry(new ZipEntry(file_xlsx.getName()));					
					
					byte[] bytes_xlsx = Files.readAllBytes(Paths.get(filePath_xlsx));
					zos_xlsx.write(bytes_xlsx,0,bytes_xlsx.length);
					zos_xlsx.closeEntry();
					zos_xlsx.close();
					
					
					ZipOutputStream zos_xls = new ZipOutputStream(fos_xls);
					zos_xls.putNextEntry(new ZipEntry(file_xls.getName()));
					byte[] bytes_xls = Files.readAllBytes(Paths.get(filePath_xls));
					zos_xls.write(bytes_xls,0,bytes_xls.length);
					zos_xls.closeEntry();
					zos_xls.close();
					
					
					ZipOutputStream zos_txt = new ZipOutputStream(fos_txt);
					zos_txt.putNextEntry(new ZipEntry(file_txt.getName()));
					byte[] bytes_txt = Files.readAllBytes(Paths.get(filePath_txt));
					zos_txt.write(bytes_txt,0,bytes_txt.length);
					zos_txt.closeEntry();
					zos_txt.close();
					
					ZipOutputStream zos_csv = new ZipOutputStream(fos_csv);
					zos_csv.putNextEntry(new ZipEntry(file_csv.getName()));
					byte[] bytes_csv = Files.readAllBytes(Paths.get(filePath_csv));
					zos_csv.write(bytes_csv,0,bytes_csv.length);
					zos_csv.closeEntry();
					zos_csv.close();
				
					Files.move( Paths.get(System.getProperty("user.dir")+"TestData_xls.xls.zip"), Paths.get(System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_xls.xls.zip"), StandardCopyOption.REPLACE_EXISTING);
					Files.move( Paths.get(System.getProperty("user.dir")+"TestData_xlsx.xlsx.zip"), Paths.get(System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_xlsx.xlsx.zip"),StandardCopyOption.REPLACE_EXISTING);
					Files.move( Paths.get(System.getProperty("user.dir")+"TestData_txt.txt.zip"), Paths.get(System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_txt.txt.zip"),StandardCopyOption.REPLACE_EXISTING);
					Files.move( Paths.get(System.getProperty("user.dir")+"TestData_csv.csv.zip"), Paths.get(System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_csv.csv.zip"),StandardCopyOption.REPLACE_EXISTING);
					
					
					
					//************************************7Z Code********************************************************************************
					/* Read the input file to be compressed */
					File inputToCompress = new File(System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_xls.xls");
					BufferedInputStream inStream  = new BufferedInputStream(new java.io.FileInputStream(inputToCompress));
					/* Create output file 7z File */
					File compressedOutput = new File(System.getProperty("user.dir")+"BulkUploadFilesDLT/TestData_xls.xls.7z");
					BufferedOutputStream outStream = new BufferedOutputStream(new java.io.FileOutputStream(compressedOutput));
					
					
					/* Create LZMA Encoder Object / Write Header Information */
					
					encoder.SetAlgorithm(2);
					encoder.SetDictionarySize(8388608);
					encoder.SetNumFastBytes(128);
					encoder.SetMatchFinder(1);
					encoder.SetLcLpPb(3,0,2);
					encoder.SetEndMarkerMode(false);
					encoder.WriteCoderProperties(outStream);
					long fileSize;
					fileSize = inputToCompress.length();
					for (int i = 0; i < 8; i++)                                     
					{
					        outStream.write((int)(fileSize >>> (8 * i)) & 0xFF);
					}                               
					
					
					/* Close Output Streams*/
					outStream.flush();
					outStream.close();
					inStream.close();
					
					
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			//***********************************************************************************************
			
		
	}

//	@SuppressWarnings("unused")
//	private static void addToArchiveCompression(String fileName) throws IOException
//	{
//		String name = dir + File.separator + file.getName();
//		
//		SevenZOutputFile out = new SevenZOutputFile (new File(fileName));
//		
//	
//			SevenZArchiveEntry entry = out.createArchiveEntry(null, fileName);
//			out.putArchiveEntry(entry);
//			FileInputStream in = new FileInputStream(file);
//			byte[] b = new byte[1024];
//			int count =0;
//			while ((count = in.read(b))> 0)
//			{
//				out.write(b,0,count);
//				
//			}
//			out.closeArchiveEntry();
//			
//			
//		
//		
//	}

}
