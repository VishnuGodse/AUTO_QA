package com.enterprise.ui.auto.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropRead {
	public String readConfig(String key,String path) throws IOException {
Properties prop = new  Properties();
FileInputStream fi = new FileInputStream(path);
prop.load(fi);
return prop.getProperty(key);
}
}
