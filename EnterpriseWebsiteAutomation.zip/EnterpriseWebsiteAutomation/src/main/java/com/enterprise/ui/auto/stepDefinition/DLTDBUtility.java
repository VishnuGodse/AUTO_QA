package com.enterprise.ui.auto.stepDefinition;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.stepDefinition.Inititor;
import com.enterprise.ui.auto.utility.ExecuteQuery;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.MessageCheckInFileUtility;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.auto.utility.SeleniumUtility;

import cucumber.api.java.en.Then;





public class DLTDBUtility {

	public Inititor init;
	public EnvBO env;
	public SeleniumUtility su;
	public WebDriver driver;
	ReportingLogging log;
	PropRead pr;
	GeneralUtlities gu;
	String groupName = null;
	String phoneNo;
	ExecuteQuery query;
	int phoneNocnt = 0;
	String aggrAccId = null;
	boolean otherLang = false;
	boolean flash = false;
	boolean unicodeFlash = false;
	SoftAssert sa;
	String template_id;
	MessageCheckInFileUtility msgcheck;
	String userid;
	Map<String, String> hm;

	public DLTDBUtility() throws IOException {
		init = new Inititor();
		env = new EnvBO();
		su = new SeleniumUtility();
		driver = su.getDriver();
		log = new ReportingLogging();
		pr = new PropRead();
		phoneNo = pr.readConfig("TestPhoneNo", "resources/project_env.properties");
		gu = new GeneralUtlities();
		query = new ExecuteQuery();
		sa = new SoftAssert();
		// locator = PropertiesFileReader.propertiesFileReaderMethod(repoPath);
		msgcheck = new MessageCheckInFileUtility();
		userid = env.getEnterpriseUsername();
		hm = new HashMap<String, String>();

	}

	

	@Then("^User gets db data$")
	public Map<String, String> user_gets_db_data(String header,String type) throws Exception {
		
		try {
			log.logging("Got user id" + userid, "info");
			Object userId = query.getDBResponse(userid, "id", "getiingUserId");
			
			
			  if(header.equalsIgnoreCase("template")&&type.equalsIgnoreCase("text"))
					  {
				          Object tempdata=query.getDBResponse(userId.toString(),
						  "template","GetValueDLT"); 
				          String tdata = tempdata.toString();
						  System.out.println("Template name"+tdata);
						  hm.put("message", tdata);
					  }
			
			  if(header.equalsIgnoreCase("templateid")&&type.equalsIgnoreCase("text"))
			  {
			  Object tempdata1=query.getDBResponse(userId.toString(),
			  "dltTemplateId","GetValueDLT");
			  String tdata1 = tempdata1.toString();
			  System.out.println("Template name"+tdata1);
			  hm.put("templateid", tdata1);
			  }
			
			  if(header.equalsIgnoreCase("template")&&type.equalsIgnoreCase("unicode"))
			  {
			  Object tempudata=query.getDBResponse(userId.toString(), "template","GetUniValueDLT");
			  String tudata = tempudata.toString();
			  System.out.println("Template name"+tudata);
			  hm.put("message", tudata);
			  
			  }
			
			  if(header.equalsIgnoreCase("templateid")&&type.equalsIgnoreCase("unicode"))
			  {
			   Object tempudata1=query.getDBResponse(userId.toString(), "dltTemplateId","GetUniValueDLT");
			   String tudata1 = tempudata1.toString();
			   System.out.println("Template name"+tudata1);
			   hm.put("templateid", tudata1);
			  }
			
			  if(header.equalsIgnoreCase("mask")&&type.equalsIgnoreCase("text"))
			  {
				  Object mask=query.getDBResponse(userId.toString(), "defaultMask","GetMaskValue");
				   String maskd = mask.toString();
				   System.out.println("Mask name"+maskd);
				   hm.put("mask",maskd);
			  }
			  if(header.equalsIgnoreCase("mask")&&type.equalsIgnoreCase("unicode"))
			  {
				  Object mask1=query.getDBResponse(userId.toString(), "defaultMask","GetUniMaskValue");
				   String maskd1 = mask1.toString();
				   System.out.println("Mask name"+maskd1);
				   hm.put("mask",maskd1);
			  }
			  
			  for(Map.Entry entry : hm.entrySet())
				{
				    System.out.println("key: " + entry.getKey() + "; value: " + entry.getValue());
				}
			
			}
		catch(Exception e )
		{
			log.logging("Exception encountered : " + e, "info");
		}
		
		return hm;
		
	}

}
