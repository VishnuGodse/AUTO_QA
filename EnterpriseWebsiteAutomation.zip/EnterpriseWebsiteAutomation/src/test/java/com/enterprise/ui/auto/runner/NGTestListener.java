package com.enterprise.ui.auto.runner;

import java.io.IOException;

import javax.security.auth.login.LoginContext;

import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.gherkin.model.Feature;
import com.enterprise.ui.reporting.ExtentReporting;
import com.enterprise.ui.auto.utility.Screenshot;

public class NGTestListener implements ITestListener{
ExtentReporting   exReporting = new ExtentReporting();
	public void onTestStart(ITestResult iTestResult) 
	{
		exReporting.ExtentReports();
		exReporting.features =  exReporting.extent.createTest(Feature.class, "/src/main/java/com/enterprise/ui/auto/feature/");
		
	}
	public void onTestSuccess(ITestResult iTestResult){
		System.out.println("Pass");
	}
public void onTestFailure(ITestResult iTestResult){
	System.out.println("Fail");
	try {
		exReporting.getScreenShot();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}
}
