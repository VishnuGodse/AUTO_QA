package com.enterprise.ui.auto.runner;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cucumber.listener.Reporter;
import com.enterprise.ui.auto.Bo.EnvBO;
import com.enterprise.ui.auto.utility.GeneralUtlities;
import com.enterprise.ui.auto.utility.PropRead;
import com.enterprise.ui.auto.utility.ReadJsonReport;
import com.enterprise.ui.auto.utility.ReportingLogging;
import com.enterprise.ui.reporting.HtmlReport;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;


@CucumberOptions(features = "src/main/java/com/enterprise/ui/auto/feature/", glue = {
"com/enterprise/ui/auto/stepDefinition" }, monochrome = true, plugin = {
		"json:target/cucumber-reports/CucumberTestReport.json",
		"com.cucumber.listener.ExtentCucumberFormatter:Reports/EnterpriseAutomation.html", "pretty",
		"html:target/cucumber-reports/cucumber-preety/report.html",
		"json:target/cucumber-reports/CucumberTestReport.json", "rerun:target/cucumber-reports/rerun.txt",
		"usage:target/cucumber-reports/CucumberTestReportusage.json" }, dryRun =false)
//tags= {"@Sign"}

public class TestRunner {
	private TestNGCucumberRunner testNGCucumberRunner;
	ReadJsonReport report;
	GeneralUtlities gu;
	EnvBO ev;
	HtmlReport hr = new HtmlReport();
	String cc;
	String date;
	String sub;
	String attachPath;
	String to;
	String body;
	PropRead pr = new PropRead();
	String startTime = null;
	ReportingLogging log;

	public TestRunner() throws IOException {
		log = new ReportingLogging();
	}

	@BeforeSuite(alwaysRun = true)
	public void startTime() {
		gu = new GeneralUtlities();
		startTime = gu.getSpecificDateFormatForReport();
		try {
			log.logging("Cleaning Report Directory", "info");
			gu.cleanDir(System.getProperty("user.dir") + "/Reports");
			log.logging("Cleaning Sceenshot", "info");
			gu.cleanDir("./Reports/Screenshots");
			log.logging("Deleting old Zip Report", "info");
			gu.delFile(System.getProperty("user.dir") + "/Reports.zip");

			gu.cleanDir(System.getProperty("user.dir") + "/Reports");
		} catch (NullPointerException e) {
			gu.createReportDir(System.getProperty("user.dir") + "/Reports");
			gu.createReportDir(System.getProperty("user.dir") + "/Reports/Screenshots");
		}
	}

	@BeforeClass(alwaysRun = true)
	public void setUpCucumber() {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature) {

		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());

	}

	@DataProvider
	public Object[][] features() {

		return testNGCucumberRunner.provideFeatures();
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		gu = new GeneralUtlities();
		ev = new EnvBO();

		Reporter.loadXMLConfig(pr.readConfig("ExtentConfig", "resources/config.properties"));
		Reporter.setSystemInfo("User Name", gu.getSysDetail("hostname"));
		Reporter.setSystemInfo("OS", gu.getSysDetail("os"));
		Reporter.setSystemInfo("Machine IP", gu.getSysDetail("ip"));
		Reporter.setSystemInfo("Envoirnment", System.getProperty("env"));
		//Reporter.setSystemInfo("Envoirnment Url", ev.getShewtAggrigatorUrl());
		Reporter.setSystemInfo("Java Version", gu.getSysDetail("javaVersion"));
		testNGCucumberRunner.finish();
		mailingReporting();
		
		
	

	}

	public void mailingReporting() throws IOException {
		gu = new GeneralUtlities();
		ev = new EnvBO();
		String envornment = System.getProperty("env");
		String os = null;
		String ip = null;
		String javaV = null;
		String envUrl = null;
		String userName = null;
		String graphUrl = null;
		String endTime = null;
		String sendMail = null;
		String jenkinsUrl = null;

		int pass = 0;
		int fail = 0;
		int skip = 0;
		int total = 0;

		String totTime = null;
		String barCharturl = null;
		try {
			os = gu.getSysDetail("os");
			userName = gu.getSysDetail("hostname");
			ip = gu.getSysDetail("ip");
			javaV = gu.getSysDetail("javaVersion");
			// envUrl = ev.getShewtAggrigatorUrl();
			endTime = gu.getSpecificDateFormatForReport();
			totTime = gu.timeDiff(startTime, endTime);
			report = new ReadJsonReport();
			pass = report.getStatusCount("target/cucumber-reports/CucumberTestReport.json", "Pass");
			fail = report.getStatusCount("target/cucumber-reports/CucumberTestReport.json", "Fail");
			skip = report.getStatusCount("target/cucumber-reports/CucumberTestReport.json", "Skip");
			total = report.getStatusCount("target/cucumber-reports/CucumberTestReport.json", "Total");
			graphUrl = gu.genGraph(pass, fail, skip, total);
			barCharturl = gu.genBarGraph(pass, fail, skip);
			envUrl = ev.getEnterpriseUrl();
			jenkinsUrl = System.getProperty("jurl");
		} catch (IOException e) {
			e.printStackTrace();
		}
		FileWriter fw;
		try {
			fw = new FileWriter(System.getProperty("user.dir") + "/Temp/html_mail_body.html");
			fw.write(hr.htmlReportbody(pass, fail, skip, javaV, envornment, envUrl, ip, userName, os, graphUrl,
					startTime, endTime, totTime, barCharturl, jenkinsUrl));
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		date = gu.getCurrDate();
		sub = "Enterprise Website Automation" + date;
		File file = new File("target/cucumber-reports");
		File mailfile = new File("./Reports/");

		try {
			sendMail = System.getProperty("mailers");
			if (sendMail.equalsIgnoreCase("true")) {
				to = System.getProperty("mailTO");

				if (to == null) {
					log.logging("Mail send to not mentioned in System Variable taking it from Config.", "info");

					to = pr.readConfig("ReportMailTo", "resources/project_env.properties");
				}
				cc = System.getProperty("mailCC");
				if (cc == null) {
					log.logging("Mail send cc not mentioned in System Variable taking it from Config.", "info");

					cc = pr.readConfig("ReportMailCc", "resources/project_env.properties");
				}
				body = new String(
						Files.readAllBytes(Paths.get(System.getProperty("user.dir") + "/Temp/html_mail_body.html")));
				// gu.zipDirectory(file, "AdvanceReports.zip");

				log.logging("Mailing the Reports", "info");
				log.logoUpdate("." + pr.readConfig("ReportPath", "resources/config.properties"));
				gu.zipDirectory(mailfile, "Reports.zip");
				attachPath = "Reports.zip";

				// attachPath = System.getProperty("user.dir") + "/Temp/html_mail_body.html";
				gu.sendMail(to, cc, sub, body, attachPath);
			} else {
				log.logging("Not Mailing as Report Not Required", "info");
			}
		} catch (IOException e) {
			e.fillInStackTrace();
		}
	}
}
